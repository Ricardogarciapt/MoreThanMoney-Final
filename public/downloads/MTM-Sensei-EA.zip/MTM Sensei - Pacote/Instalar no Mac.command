#!/bin/zsh
# Copia o pacote para a pasta de dados do MetaTrader 5 (versao Mac/Wine).
cd "$(dirname "$0")"
BASE="$HOME/Library/Application Support/net.metaquotes.wine.metatrader5/drive_c/Program Files/MetaTrader 5"
COMMON="$HOME/Library/Application Support/net.metaquotes.wine.metatrader5/drive_c/users/$(whoami)/AppData/Roaming/MetaQuotes/Terminal/Common"
if [ ! -d "$BASE" ]; then echo "Nao encontrei o MetaTrader 5 instalado."; read -k1; exit 1; fi
mkdir -p "$COMMON/Files"
cp -R MQL5/. "$BASE/MQL5/" && echo "MQL5 copiado."
cp -R Common/Files/. "$COMMON/Files/" && echo "Ficheiro de noticias copiado."
echo
echo "Feito. Abre o MetaTrader, compila no MetaEditor (F7) e corre o script MTM_Setup."
read -k1 "?Carrega numa tecla para fechar."
