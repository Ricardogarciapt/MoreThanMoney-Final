//+------------------------------------------------------------------+
//|                                             MTM_Sensei_Core.mq5  |
//|  Este software e codigo sao parte integrante da propriedade       |
//|  intelectual de RicardoGarciaPT e da sua empresa MoreThanMoney    |
//|                                                                  |
//|  Port MQL5 do indicador Pine v6 "MTM Sensei v3"                  |
//|  (auditoria de sinais 2026-08-03)                                |
//+------------------------------------------------------------------+
#property copyright "RicardoGarciaPT - MoreThanMoney"
#property link      "https://morethanmoney.pt"
#property version   "3.00"
#property description "MTM Sensei v3 CORE - motor sem inputs visuais, para o EA (iCustom)"
#property indicator_chart_window
#property indicator_buffers 33
#property indicator_plots   18

//--- 1 DEMA 15
#property indicator_label1  "DEMA 15"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDodgerBlue
#property indicator_width1  1
//--- 2 DEMA 50
#property indicator_label2  "DEMA 50"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrMediumSeaGreen
#property indicator_width2  1
//--- 3 DEMA 238
#property indicator_label3  "DEMA 238"
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrOrange
#property indicator_width3  2
//--- 4 POC
#property indicator_label4  "POC"
#property indicator_type4   DRAW_LINE
#property indicator_color4  clrDarkOrange
#property indicator_style4  STYLE_DOT
#property indicator_width4  1
//--- 5 Banda superior
#property indicator_label5  "Sensei U1"
#property indicator_type5   DRAW_LINE
#property indicator_color5  clrBlueViolet
#property indicator_width5  1
//--- 6 Banda inferior
#property indicator_label6  "Sensei L1"
#property indicator_type6   DRAW_LINE
#property indicator_color6  clrBlueViolet
#property indicator_width6  1
//--- 7 Cloud rapida
#property indicator_label7  "Cloud F"
#property indicator_type7   DRAW_LINE
#property indicator_color7  clrMediumPurple
#property indicator_width7  1
//--- 8 Cloud lenta
#property indicator_label8  "Cloud S"
#property indicator_type8   DRAW_LINE
#property indicator_color8  clrSlateGray
#property indicator_width8  1
//--- 9 Preenchimento da cloud (bull / bear)
#property indicator_label9  "Cloud"
#property indicator_type9   DRAW_FILLING
#property indicator_color9  clrBlueViolet,clrDimGray
//--- 10 Seta de compra
#property indicator_label10 "BUY"
#property indicator_type10  DRAW_ARROW
#property indicator_color10 clrLime
#property indicator_width10 3
//--- 11 Seta de venda
#property indicator_label11 "SELL"
#property indicator_type11  DRAW_ARROW
#property indicator_color11 clrRed
#property indicator_width11 3
//--- 12 Momentum buy
#property indicator_label12 "Momentum Buy"
#property indicator_type12  DRAW_ARROW
#property indicator_color12 clrTeal
#property indicator_width12 1
//--- 13 Momentum sell
#property indicator_label13 "Momentum Sell"
#property indicator_type13  DRAW_ARROW
#property indicator_color13 clrTomato
#property indicator_width13 1
//--- 14 Exaustao buy
#property indicator_label14 "Exaustao Buy"
#property indicator_type14  DRAW_ARROW
#property indicator_color14 clrTeal
#property indicator_width14 2
//--- 15 Exaustao sell
#property indicator_label15 "Exaustao Sell"
#property indicator_type15  DRAW_ARROW
#property indicator_color15 clrTomato
#property indicator_width15 2
//--- 16 Swing high
#property indicator_label16 "Swing High"
#property indicator_type16  DRAW_ARROW
#property indicator_color16 clrTomato
#property indicator_width16 1
//--- 17 Swing low
#property indicator_label17 "Swing Low"
#property indicator_type17  DRAW_ARROW
#property indicator_color17 clrTeal
#property indicator_width17 1
//--- 18 Vela do sinal (recolorida)
#property indicator_label18 "Vela de sinal"
#property indicator_type18  DRAW_COLOR_CANDLES
#property indicator_color18 clrLime,clrRed
#property indicator_width18 1

//--- sem MTM_VISUAL: so os 44 inputs de logica
#include <MTM/MTM_Sensei_Engine.mqh>
//+------------------------------------------------------------------+
