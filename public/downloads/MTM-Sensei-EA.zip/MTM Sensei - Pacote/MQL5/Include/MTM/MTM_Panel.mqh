//+------------------------------------------------------------------+
//|                                              MTM_Panel.mqh       |
//|  Painel de controlo do MTM Sensei — V2                            |
//|  Propriedade de RicardoGarciaPT / MoreThanMoney.                  |
//|                                                                  |
//|  O painel nao tem logica de trading: mexe em variaveis de estado  |
//|  que o EA le. Assim o comportamento e sempre o mesmo, venha a     |
//|  ordem dos inputs, do preset ou de um clique.                     |
//+------------------------------------------------------------------+
#ifndef MTM_PANEL_MQH
#define MTM_PANEL_MQH

//====================================================================
//  ESTADO EM TEMPO REAL  (arranca dos inputs, muda com os botoes)
//====================================================================
bool   g_uiAuto      = true;    // execucao automatica ligada
int    g_uiLotMode   = 0;       // 0 = risco %, 1 = lotes fixos
double g_uiRisk      = 1.0;     // % de risco ou lotes, conforme o modo
double g_uiPartial   = 25.0;    // % a fechar no botao de parcial
int    g_uiTrailMode = 0;       // 0 = off, 1 = ATR, 2 = pontos fixos
int    g_uiView      = 0;       // 0 = grafico, 1 = so plots, 2 = dashboard
int    g_uiLang      = 0;       // 0 = portugues, 1 = ingles

//--- todo o texto visivel passa por aqui: PT primeiro, EN depois
string T(const string pt,const string en){ return(g_uiLang==1?en:pt); }
int    g_uiStyle     = 1;       // estilo de trading em uso
bool   g_uiReady     = false;

//--- nomes dos objectos
#define PN "MTMUI_"

string StyleName(const int s)
  {
   switch(s)
     {
      case 0: return(T("Agressivo","Aggressive"));
      case 1: return("Scalp");
      case 2: return("Intraday");
      case 3: return("Swing");
      case 4: return(T("Conservador","Conservative"));
     }
   return(T("Personalizado","Custom"));
  }

//====================================================================
//  PRIMITIVAS DE DESENHO
//====================================================================
void UiRect(const string n,const int x,const int y,const int w,const int h,
            const color bg,const color border)
  {
   if(ObjectFind(0,n)<0)
     {
      ObjectCreate(0,n,OBJ_RECTANGLE_LABEL,0,0,0);
      ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,n,OBJPROP_BORDER_TYPE,BORDER_FLAT);
      ObjectSetInteger(0,n,OBJPROP_BACK,false);
      ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,n,OBJPROP_HIDDEN,true);
     }
   ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x);  ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,n,OBJPROP_XSIZE,w);      ObjectSetInteger(0,n,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,n,OBJPROP_BGCOLOR,bg);   ObjectSetInteger(0,n,OBJPROP_COLOR,border);
  }

void UiText(const string n,const int x,const int y,const string t,
            const color c,const int size=8,const string font="Segoe UI")
  {
   if(ObjectFind(0,n)<0)
     {
      ObjectCreate(0,n,OBJ_LABEL,0,0,0);
      ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,n,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,n,OBJPROP_HIDDEN,true);
     }
   ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x); ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
   ObjectSetString (0,n,OBJPROP_TEXT,t);      ObjectSetInteger(0,n,OBJPROP_COLOR,c);
   ObjectSetInteger(0,n,OBJPROP_FONTSIZE,size); ObjectSetString(0,n,OBJPROP_FONT,font);
  }

void UiBtn(const string n,const int x,const int y,const int w,const int h,
           const string t,const color bg,const color fg,const int size=8)
  {
   if(ObjectFind(0,n)<0)
     {
      ObjectCreate(0,n,OBJ_BUTTON,0,0,0);
      ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,n,OBJPROP_BORDER_COLOR,clrDimGray);
      ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,n,OBJPROP_HIDDEN,true);
      ObjectSetString (0,n,OBJPROP_FONT,"Segoe UI Semibold");
     }
   ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x); ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,n,OBJPROP_XSIZE,w);     ObjectSetInteger(0,n,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,n,OBJPROP_BGCOLOR,bg);  ObjectSetInteger(0,n,OBJPROP_COLOR,fg);
   ObjectSetInteger(0,n,OBJPROP_FONTSIZE,size);
   ObjectSetInteger(0,n,OBJPROP_STATE,false);
   ObjectSetString (0,n,OBJPROP_TEXT,t);
  }

void UiEdit(const string n,const int x,const int y,const int w,const string val)
  {
   if(ObjectFind(0,n)<0)
     {
      ObjectCreate(0,n,OBJ_EDIT,0,0,0);
      ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,n,OBJPROP_YSIZE,20);
      ObjectSetInteger(0,n,OBJPROP_BGCOLOR,C'28,28,42');
      ObjectSetInteger(0,n,OBJPROP_BORDER_COLOR,clrDimGray);
      ObjectSetInteger(0,n,OBJPROP_COLOR,clrWhite);
      ObjectSetInteger(0,n,OBJPROP_ALIGN,ALIGN_CENTER);
      ObjectSetInteger(0,n,OBJPROP_FONTSIZE,9);
      ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,n,OBJPROP_HIDDEN,true);
     }
   ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x); ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,n,OBJPROP_XSIZE,w);
   ObjectSetString (0,n,OBJPROP_TEXT,val);
  }


//====================================================================
//  LAYOUT
//====================================================================
int g_panX=14, g_panY=70;      // origem do painel de controlo (arrastavel)
int g_dashX=14,g_dashY=318;    // origem da coluna do dashboard (arrastavel)
#define UIW 268

int  g_uiRow=0;
void PanelBuild()
  {
   int x=g_panX, y=g_panY, w=UIW;
   UiRect(PN"bg",x-4,y-4,w+8,238,C'16,17,28',C'124,58,237');
   UiRect(PN"hd",x-4,y-4,w+8,26, C'124,58,237',C'124,58,237');
   UiText(PN"ttl",x+6,y+1,"MTM SENSEI",clrWhite,9,"Segoe UI Semibold");
   UiText(PN"st", x+96,y+1,"",clrWhite,9,"Segoe UI Semibold");
   UiBtn (PN"lang", x+172,y-1,30,20,"PT",C'55,48,90',clrWhite,8);
   UiBtn (PN"clean",x+206,y-1,68,20,"GRAFICO",C'88,28,135',clrWhite,7);

   int r=y+30;
   UiBtn(PN"auto", x,     r, 128,24,"AUTO: ON", C'21,128,61',clrWhite,9);
   UiBtn(PN"stylL",x+134, r,  20,24,"<",        C'45,45,62',clrWhite,9);
   UiText(PN"styl",x+158, r+4,"",               clrWhite,8);
   UiBtn(PN"stylR",x+248, r,  20,24,">",        C'45,45,62',clrWhite,9);

   r+=30;
   UiBtn(PN"buy",  x,     r, 130,28,T("COMPRAR","BUY"),C'21,128,61',clrWhite,10);
   UiBtn(PN"sell", x+138, r, 130,28,T("VENDER","SELL"),C'153,27,27',clrWhite,10);

   r+=34;
   UiText(PN"lblR",x,     r+3,T("Risco","Risk"),C'148,163,184',8);
   UiEdit(PN"risk",x+48,  r,   62,"1.0");
   UiBtn (PN"mode",x+116, r,   72,20,"%",       C'45,45,62',clrWhite,8);
   UiBtn (PN"trail",x+194,r,   74,20,"TRAIL OFF",C'55,65,81',clrWhite,8);

   r+=28;
   UiText(PN"lblP",x,     r+3,T("Parcial","Partial"),C'148,163,184',8);
   UiEdit(PN"part",x+48,  r,   50,"25");
   UiText(PN"pct", x+102, r+3,"%",              C'148,163,184',8);
   UiBtn (PN"dopart",x+118,r,  70,20,T("FECHAR","CLOSE"),C'180,83,9',clrWhite,8);
   UiBtn (PN"closeall",x+194,r,74,20,T("TUDO","ALL"),C'153,27,27',clrWhite,8);

   r+=30;
   UiRect(PN"sep",x,r,w,1,C'55,65,81',C'55,65,81');
   r+=6;
   UiText(PN"i1",x,r,   "",clrSilver,8); r+=16;
   UiText(PN"i2",x,r,   "",clrSilver,8); r+=16;
   UiText(PN"i3",x,r,   "",clrSilver,8); r+=16;
   UiText(PN"i4",x,r,   "",C'148,163,184',8);
   g_uiReady=true;
  }

void PanelDestroy(){ ObjectsDeleteAll(0,PN); g_uiReady=false; }

//====================================================================
//  ACTUALIZACAO (estado + numeros)
//====================================================================
void PanelRefresh(const bool canTrade,const string motivo,const int score,
                  const int posicoes,const double flutuante,
                  const string linhaRisco,const string linhaNoticias)
  {
   if(!g_uiReady) return;
   ObjectSetString (0,PN"st",OBJPROP_TEXT, canTrade?T("A OPERAR","RUNNING"):T("PARADO","STOPPED"));
   ObjectSetString (0,PN"lang",OBJPROP_TEXT, g_uiLang==1?"EN":"PT");
   ObjectSetInteger(0,PN"st",OBJPROP_COLOR,canTrade?C'134,239,172':C'254,202,202');

   ObjectSetString (0,PN"auto",OBJPROP_TEXT, g_uiAuto?"AUTO: ON":"AUTO: OFF");
   ObjectSetInteger(0,PN"auto",OBJPROP_BGCOLOR, g_uiAuto?C'21,128,61':C'55,65,81');

   ObjectSetString (0,PN"styl",OBJPROP_TEXT, StyleName(g_uiStyle));
   ObjectSetString (0,PN"mode",OBJPROP_TEXT, g_uiLotMode==0?"%":T("LOTE","LOT"));
   string tm = (g_uiTrailMode==1)?"TRAIL ATR":(g_uiTrailMode==2)?"TRAIL PTS":"TRAIL OFF";
   ObjectSetString (0,PN"trail",OBJPROP_TEXT, tm);
   ObjectSetInteger(0,PN"trail",OBJPROP_BGCOLOR, g_uiTrailMode>0?C'21,128,61':C'55,65,81');
   string vw = (g_uiView==2)?"DASH":((g_uiView==1)?T("PLOTS","PLOTS"):T("GRAFICO","CHART"));
   ObjectSetString (0,PN"clean",OBJPROP_TEXT, vw);
   ObjectSetInteger(0,PN"clean",OBJPROP_BGCOLOR,
                    (g_uiView==2)?C'147,51,234':((g_uiView==1)?C'124,58,237':C'88,28,135'));

   UiText(PN"i1",g_panX,(int)ObjectGetInteger(0,PN"i1",OBJPROP_YDISTANCE),
          StringFormat(T("Posicoes %d      Flutuante %+.2f","Positions %d      Floating %+.2f"),posicoes,flutuante),
          flutuante<0?C'248,113,113':C'134,239,172',8);
   UiText(PN"i2",g_panX,(int)ObjectGetInteger(0,PN"i2",OBJPROP_YDISTANCE),
          StringFormat(T("Score actual %d/20","Current score %d/20"),score),C'245,158,11',8);
   UiText(PN"i3",g_panX,(int)ObjectGetInteger(0,PN"i3",OBJPROP_YDISTANCE),
          linhaRisco,clrSilver,8);
   UiText(PN"i4",g_panX,(int)ObjectGetInteger(0,PN"i4",OBJPROP_YDISTANCE),
          canTrade?linhaNoticias:(T("parado: ","stopped: ")+motivo),
          canTrade?C'148,163,184':C'248,113,113',8);
  }


//====================================================================
//  VISTA DASHBOARD — fundo de marca sobre o grafico + confirmacoes
//  Um rectangulo opaco a tapar tudo, e a leitura do Sensei por cima.
//====================================================================
#define DB "MTMDB_"

string DotBar(const int n)      // 0..5 -> barra de blocos
  {
   string s="";
   for(int i=0;i<5;i++) s+=(i<n)?"█":"░";
   return(s);
  }
color  DotCol(const int n)
  { return(n>=4?C'52,211,153':(n>=3?C'251,191,36':C'248,113,113')); }

void DashDestroy(){ ObjectsDeleteAll(0,DB); }

//--- desloca todos os objectos de um prefixo (usado no arrasto)
void UiShift(const string pref,const int dx,const int dy)
  {
   for(int i=ObjectsTotal(0,-1,-1)-1;i>=0;i--)
     {
      string n=ObjectName(0,i,-1,-1);
      if(StringFind(n,pref)!=0) continue;
      if(pref==DB && (n==DB"top" || n==DB"acc" || n==DB"logo" ||
                      n==DB"br1" || n==DB"br2" || n==DB"ft")) continue;  // a faixa fica
      ObjectSetInteger(0,n,OBJPROP_XDISTANCE,(int)ObjectGetInteger(0,n,OBJPROP_XDISTANCE)+dx);
      ObjectSetInteger(0,n,OBJPROP_YDISTANCE,(int)ObjectGetInteger(0,n,OBJPROP_YDISTANCE)+dy);
     }
  }

void DashBuild()
  {
   int W=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);
   int H=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS);
   if(W<420||H<300) return;
   int RW=284, RX=g_dashX, y=g_dashY;

   UiRect(DB"top",0,0,W,52,C'20,16,42',C'20,16,42');
   UiRect(DB"acc",0,52,W,2,C'124,58,237',C'124,58,237');
   if(ObjectFind(0,DB"logo")<0)
      if(ObjectCreate(0,DB"logo",OBJ_BITMAP_LABEL,0,0,0))
        {
         ObjectSetString (0,DB"logo",OBJPROP_BMPFILE,"\\Images\\mtm_logo.bmp");
         ObjectSetInteger(0,DB"logo",OBJPROP_SELECTABLE,false);
         ObjectSetInteger(0,DB"logo",OBJPROP_HIDDEN,true);
        }
   ObjectSetInteger(0,DB"logo",OBJPROP_XDISTANCE,W-90);
   ObjectSetInteger(0,DB"logo",OBJPROP_YDISTANCE,4);
   UiText(DB"br1",22,10,"MoreThanMoney",C'196,181,253',13,"Segoe UI Light");
   UiText(DB"br2",22,31,T("MTM SENSEI  ·  leitura em tempo real",
                          "MTM SENSEI  ·  live reading"),C'129,140,248',8);

   UiRect(DB"hd",RX,y-22,RW,22,C'55,48,90',C'55,48,90');
   UiText(DB"hdt",RX+9,y-20,T("LEITURA SENSEI  ·  arrasta aqui",
                              "SENSEI READOUT  ·  drag here"),C'196,181,253',8);

   UiRect(DB"c1",RX,y,RW,84,C'18,20,32',C'55,48,90');
   UiText(DB"lb1",RX+12,y+8,T("LEITURA ACTUAL","CURRENT READING"),C'148,163,184',8);
   UiText(DB"dir",RX+12,y+24,"-",clrWhite,13,"Segoe UI Semibold");
   UiText(DB"sc", RX+12,y+46,"-",C'245,158,11',10);
   UiText(DB"tp", RX+12,y+64,"-",C'148,163,184',8);

   y+=92;
   UiRect(DB"c2",RX,y,RW,112,C'18,20,32',C'55,48,90');
   UiText(DB"lb2",RX+12,y+8,T("CONFIRMACOES  (20)","CONFIRMATIONS  (20)"),C'148,163,184',8);
   string nm[4];
   nm[0]=T("Tendencia DEMA","DEMA trend");
   nm[1]="Momentum / Flow";
   nm[2]=T("SMC / Estrutura","SMC / Structure");
   nm[3]=T("Sensei / Fase","Sensei / Phase");
   for(int i=0;i<4;i++)
     {
      UiText(DB"gn"+IntegerToString(i),RX+12,y+26+i*20,nm[i],C'203,213,225',8);
      UiText(DB"gv"+IntegerToString(i),RX+RW-88,y+26+i*20,"-",clrWhite,9,"Consolas");
     }

   y+=120;
   UiRect(DB"c3",RX,y,RW,98,C'18,20,32',C'55,48,90');
   UiText(DB"lb3",RX+12,y+8,T("FILTROS","FILTERS"),C'148,163,184',8);
   for(int i=0;i<4;i++) UiText(DB"f"+IntegerToString(i),RX+12,y+26+i*18,"-",C'203,213,225',8);

   y+=106;
   UiRect(DB"c4",RX,y,RW,130,C'18,20,32',C'55,48,90');
   UiText(DB"lb4",RX+12,y+8,T("TRADE ACTIVA","ACTIVE TRADE"),C'148,163,184',8);
   for(int i=0;i<6;i++) UiText(DB"t"+IntegerToString(i),RX+12,y+26+i*16,"-",C'203,213,225',8,"Consolas");

   UiText(DB"ft",22,H-22,"",C'100,116,139',8);
  }

void DashRefresh(const int bull,const int bear,const int gA,const int gB,const int gC,const int gD,
                 const int pos,const double entry,const double sl,
                 const double t1,const double t2,const double t3,const double t4,
                 const bool h1,const bool h2,const bool h3,const bool h4,const bool beOn,
                 const double adx,const double rsi,const bool ofUp,const bool ofDn,
                 const bool htfOK,const bool sess,const bool chop,const bool cool,
                 const string rodape,const int digits)
  {
   if(ObjectFind(0,DB"c1")<0) return;
   bool bull_bias=(bull>=bear);
   int  sc = pos>0?bull : (pos<0?bear : MathMax(bull,bear));
   string dir = pos>0?T("COMPRA ACTIVA","LONG ACTIVE")
              : (pos<0?T("VENDA ACTIVA","SHORT ACTIVE")
              : (bull_bias?T("vies de compra","bullish bias"):T("vies de venda","bearish bias")));
   ObjectSetString (0,DB"dir",OBJPROP_TEXT,dir);
   ObjectSetInteger(0,DB"dir",OBJPROP_COLOR,pos>0?C'52,211,153':(pos<0?C'248,113,113':C'148,163,184'));
   ObjectSetString (0,DB"sc",OBJPROP_TEXT,StringFormat(T("%d / 20 confirmacoes","%d / 20 confirmations"),sc));
   ObjectSetString (0,DB"tp",OBJPROP_TEXT,StringFormat("ADX %.1f    RSI %.1f    Flow %s",
                    adx,rsi,ofUp?T("comprador","buying"):(ofDn?T("vendedor","selling"):T("neutro","neutral"))));

   int g[4]; g[0]=gA; g[1]=gB; g[2]=gC; g[3]=gD;
   for(int i=0;i<4;i++)
     {
      ObjectSetString (0,DB"gv"+IntegerToString(i),OBJPROP_TEXT,DotBar(g[i])+"  "+IntegerToString(g[i])+"/5");
      ObjectSetInteger(0,DB"gv"+IntegerToString(i),OBJPROP_COLOR,DotCol(g[i]));
     }
   string f[4];
   f[0]=(htfOK?"[x] ":"[ ] ")+T("Tendencia maior (HTF)","Higher timeframe trend");
   f[1]=(sess ?"[x] ":"[ ] ")+T("Dentro da sessao","Inside session");
   f[2]=(chop ?"[x] ":"[ ] ")+T("Mercado com direccao (ADX)","Trending market (ADX)");
   f[3]=(cool ?"[x] ":"[ ] ")+T("Cooldown livre","Cooldown clear");
   bool fb[4]; fb[0]=htfOK; fb[1]=sess; fb[2]=chop; fb[3]=cool;
   for(int i=0;i<4;i++)
     {
      ObjectSetString (0,DB"f"+IntegerToString(i),OBJPROP_TEXT,f[i]);
      ObjectSetInteger(0,DB"f"+IntegerToString(i),OBJPROP_COLOR,fb[i]?C'52,211,153':C'100,116,139');
     }

   string L[6];
   if(pos!=0 && entry>0)
     {
      L[0]=StringFormat("%-10s%s",T("ENTRADA","ENTRY"),DoubleToString(entry,digits));
      L[1]=StringFormat("%s        %s",(beOn?"BREAKEVEN":"STOP LOSS"),DoubleToString(sl,digits));
      L[2]=StringFormat("EXIT 1    %s   %s",DoubleToString(t1,digits),h1?T("atingido","hit"):"");
      L[3]=StringFormat("EXIT 2    %s   %s",DoubleToString(t2,digits),h2?T("atingido","hit"):"");
      L[4]=StringFormat("EXIT 3    %s   %s",DoubleToString(t3,digits),h3?T("atingido","hit"):"");
      L[5]=StringFormat("EXIT 4    %s   %s",DoubleToString(t4,digits),h4?T("atingido","hit"):"");
     }
   else { L[0]=T("sem trade activa","no active trade"); for(int i=1;i<6;i++) L[i]=""; }
   for(int i=0;i<6;i++) ObjectSetString(0,DB"t"+IntegerToString(i),OBJPROP_TEXT,L[i]);
   ObjectSetString(0,DB"ft",OBJPROP_TEXT,rodape);
  }

#endif
