//+------------------------------------------------------------------+
//|                                               MTM_Feed.mqh       |
//|  Propriedade intelectual de RicardoGarciaPT / MoreThanMoney      |
//|                                                                  |
//|  Alimentacao do motor Sensei: espelha as velas do grafico em     |
//|  arrays proprios e chama o MtmEngineCalculate.                   |
//|                                                                  |
//|  Vive num include partilhado, e nao copiado dentro de cada EA,   |
//|  porque ha mais do que um EA a correr o mesmo motor. Duas copias  |
//|  disto divergiam no dia em que uma fosse corrigida — e este       |
//|  ficheiro ja teve um bug que so aparecia quando o historico vinha |
//|  curto (redimensionava antes de saber se a copia tinha corrido    |
//|  bem, e ficava preso num espelho vazio, em silencio).            |
//|                                                                  |
//|  QUEM INCLUI ISTO TEM DE DEFINIR:                                 |
//|    InpEngineBars  — quantas barras o motor analisa                |
//|  e incluir o MTM_Sensei_Engine.mqh ANTES.                        |
//+------------------------------------------------------------------+
#ifndef MTM_FEED_MQH
#define MTM_FEED_MQH

//====================================================================
//  ALIMENTACAO DO MOTOR
//  Espelha as velas do grafico em arrays proprios e chama o motor.
//  A ancora mantem os indices estaveis entre chamadas (o motor guarda
//  estado por barra, por isso os indices NAO podem escorregar).
//====================================================================
datetime EmTime[];
double   EmO[],EmH[],EmL[],EmC[];
long     EmV[];
int      EmSp[];
datetime g_emAnchor=0;
int      g_emPrev=0;

//--- copia as ultimas "count" velas para o fim do espelho.
//    Devolve quantas conseguiu; NAO falha so porque veio menos do que se pediu.
int EmCopyTail(const int total,const int count)
  {
   datetime tt[]; double oo[],hh[],ll[],cc[]; long vv[];
   ArraySetAsSeries(tt,true); ArraySetAsSeries(oo,true); ArraySetAsSeries(hh,true);
   ArraySetAsSeries(ll,true); ArraySetAsSeries(cc,true); ArraySetAsSeries(vv,true);
   int g=CopyTime(_Symbol,_Period,0,count,tt);
   if(g<=0) return(0);
   int g2=CopyOpen (_Symbol,_Period,0,g,oo); if(g2<g) g=g2;
   g2=CopyHigh     (_Symbol,_Period,0,g,hh); if(g2<g) g=g2;
   g2=CopyLow      (_Symbol,_Period,0,g,ll); if(g2<g) g=g2;
   g2=CopyClose    (_Symbol,_Period,0,g,cc); if(g2<g) g=g2;
   g2=CopyTickVolume(_Symbol,_Period,0,g,vv);if(g2<g) g=g2;
   if(g<=0) return(0);
   for(int k=0;k<g;k++)
     {
      int i=total-1-k;
      if(i<0) break;
      EmTime[i]=tt[k]; EmO[i]=oo[k]; EmH[i]=hh[k];
      EmL[i]=ll[k];    EmC[i]=cc[k]; EmV[i]=vv[k]; EmSp[i]=0;
     }
   return(g);
  }

void EmResize(const int n)
  {
   ArrayResize(EmTime,n); ArrayResize(EmO,n); ArrayResize(EmH,n);
   ArrayResize(EmL,n);    ArrayResize(EmC,n); ArrayResize(EmV,n);
   ArrayResize(EmSp,n);
  }

int  g_emFails=0;
bool g_emWarned=false;

int MtmFeed()
  {
   int avail=Bars(_Symbol,_Period);
   if(avail<700) return(0);

   int have =ArraySize(EmTime);
   int total=(g_emAnchor>0)?Bars(_Symbol,_Period,g_emAnchor,TimeCurrent()):0;
   //--- reancorar quando nao ha espelho, quando ele encolheu, ou quando cresceu demais
   bool full=(have==0 || g_emAnchor==0 || total<have || total>InpEngineBars*2);

   if(full)
     {
      int want=MathMin(avail,InpEngineBars);
      EmResize(want);
      int got=EmCopyTail(want,want);
      if(got<650)
        {
         //--- nao consegui historico suficiente: fica com o espelho anterior
         //    e volta a tentar no proximo tick, em vez de morrer em silencio
         g_emFails++;
         if(g_emFails==5 && !g_emWarned)
           {
            g_emWarned=true;
            PrintFormat("MTM Sensei: sem historico suficiente para o motor (pedidas %d velas, vieram %d). "
                        "Reduz InpEngineBars ou espera que o historico carregue.",want,got);
           }
         EmResize(have);
         return(0);
        }
      //--- ficou so com o que veio mesmo
      if(got<want)
        {
         EmResize(got);
         EmCopyTail(got,got);
        }
      g_emFails=0; g_emWarned=false;
      g_emAnchor=EmTime[0];
      g_emPrev=MtmEngineCalculate(ArraySize(EmTime),0,EmTime,EmO,EmH,EmL,EmC,EmV,EmV,EmSp);
      return(ArraySize(EmTime));
     }

   if(total>have)
     {
      EmResize(total);
      int k=total-have+2; if(k>total) k=total;
      if(EmCopyTail(total,k)<=0){ EmResize(have); return(0); }
     }
   else if(EmCopyTail(total,2)<=0) return(0);   // so a vela em formacao mudou

   g_emPrev=MtmEngineCalculate(total,g_emPrev,EmTime,EmO,EmH,EmL,EmC,EmV,EmV,EmSp);
   return(total);
  }

#endif // MTM_FEED_MQH
