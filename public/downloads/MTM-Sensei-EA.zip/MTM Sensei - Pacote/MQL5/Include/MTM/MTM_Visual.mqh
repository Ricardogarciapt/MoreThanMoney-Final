//+------------------------------------------------------------------+
//|                                             MTM_Visual.mqh       |
//|  Propriedade intelectual de RicardoGarciaPT / MoreThanMoney      |
//|                                                                  |
//|  Aplica os plots do Sensei (DEMAs, nuvem, bandas, setas) ao      |
//|  grafico onde o EA esta a correr.                                 |
//|                                                                  |
//|  Partilhado entre EAs: mais do que um corre o mesmo motor e quer  |
//|  a mesma leitura no ecra. Duas copias disto divergiam.            |
//|                                                                  |
//|  QUEM INCLUI TEM DE DEFINIR:  InpDrawPlots (bool)                 |
//+------------------------------------------------------------------+
#ifndef MTM_VISUAL_MQH
#define MTM_VISUAL_MQH

int g_visH=INVALID_HANDLE;   // instancia visual do indicador

//====================================================================
//  PLOTS DO INDICADOR DENTRO DO EA
//  Um EA nao tem buffers, por isso nao consegue desenhar linhas de
//  indicador. A saida honesta e o EA aplicar o proprio indicador ao
//  grafico: sao os mesmos plots, desenhados por quem os sabe desenhar.
//====================================================================
bool VisualAlreadyOnChart()
  {
   int n=ChartIndicatorsTotal(0,0);
   for(int i=0;i<n;i++)
      if(StringFind(ChartIndicatorName(0,0,i),"MTM Sensei")>=0) return(true);
   return(false);
  }

void VisualAttach()
  {
   //--- nenhum caminho sai daqui em silencio: se os plots nao aparecem,
   //    o log tem de dizer porque.
   if(!InpDrawPlots)
     { Print("MTM plots: desligados no input InpDrawPlots"); return; }
   if(MQLInfoInteger(MQL_OPTIMIZATION)!=0) return;              // optimizacao: sem grafico
   if(MQLInfoInteger(MQL_TESTER)!=0 && MQLInfoInteger(MQL_VISUAL_MODE)==0)
     { Print("MTM plots: em backtest sem modo visual nao ha grafico onde os aplicar"); return; }
   if(g_visH!=INVALID_HANDLE)
     { Print("MTM plots: ja aplicados"); return; }
   if(VisualAlreadyOnChart())
     { Print("MTM plots: o indicador ja esta no grafico - nao volto a aplica-lo"); return; }
   Print("MTM plots: a carregar ",MTM_VISUAL_NAME," ...");

   g_visH=iCustom(_Symbol,_Period,MTM_VISUAL_NAME);
   if(g_visH==INVALID_HANDLE)
     {
      PrintFormat("MTM plots: FALHOU a carregar %s (erro %d). "
                  "Aplica o indicador ao grafico a mao se os quiseres.",
                  MTM_VISUAL_NAME,GetLastError());
      return;
     }
   if(ChartIndicatorAdd(0,0,g_visH))
      Print("MTM plots: aplicados ao grafico com sucesso");
   else
     {
      PrintFormat("MTM plots: iCustom carregou mas ChartIndicatorAdd falhou (erro %d)",GetLastError());
      IndicatorRelease(g_visH); g_visH=INVALID_HANDLE;
     }
  }

void VisualDetach()
  {
   if(g_visH==INVALID_HANDLE) return;
   int n=ChartIndicatorsTotal(0,0);
   for(int i=n-1;i>=0;i--)
      if(StringFind(ChartIndicatorName(0,0,i),"MTM Sensei")>=0)
         ChartIndicatorDelete(0,0,ChartIndicatorName(0,0,i));
   IndicatorRelease(g_visH); g_visH=INVALID_HANDLE;
  }

#endif // MTM_VISUAL_MQH
