//+------------------------------------------------------------------+
//|                                           MTM_Sensei_Defs.mqh    |
//|  Este software e codigo sao parte integrante da propriedade       |
//|  intelectual de RicardoGarciaPT e da sua empresa MoreThanMoney    |
//+------------------------------------------------------------------+
#ifndef MTM_SENSEI_DEFS_MQH
#define MTM_SENSEI_DEFS_MQH

//--- Estilos de trading (iguais ao Pine)
enum ENUM_MTM_STYLE
  {
   STYLE_AGRESSIVO    = 0, // Agressivo
   STYLE_SCALP        = 1, // Scalp
   STYLE_INTRADAY     = 2, // Intraday
   STYLE_SWING        = 3, // Swing
   STYLE_CONSERVADOR  = 4, // Conservador
   STYLE_PERSONALIZADO= 5  // Personalizado
  };

enum ENUM_MTM_PHASE
  {
   PHASE_MOMENTUM = 0, // Momentum
   PHASE_EXAUSTAO = 1  // Exaustao
  };

enum ENUM_MTM_RISK
  {
   RISK_ATR     = 0, // ATR
   RISK_PERCENT = 1  // Percentagem
  };

enum ENUM_MTM_TRAIL
  {
   TRAIL_OFF = 0, // Off
   TRAIL_ATR = 1  // ATR
  };

enum ENUM_MTM_BE
  {
   BE_EXIT1  = 0, // Exit 1
   BE_EXIT2  = 1, // Exit 2
   BE_EXIT3  = 2, // Exit 3
   BE_POINTS = 3  // Pontos
  };

enum ENUM_MTM_BAND
  {
   BAND_ACTIVE  = 0, // Active
   BAND_PASSIVE = 1  // Passive
  };

enum ENUM_MTM_ORDER
  {
   MTM_ORDER_MARKET = 0, // MARKET
   MTM_ORDER_LIMIT  = 1  // LIMIT
  };

enum ENUM_MTM_RISKBASE
  {
   RB_BALANCE = 0, // Balance
   RB_EQUITY  = 1  // Equity
  };

enum ENUM_MTM_TRAILSTART
  {
   TS_IMMEDIATE = 0, // Desde a entrada
   TS_AFTER_TP1 = 1, // So depois do Exit 1
   TS_AFTER_TP2 = 2  // So depois do Exit 2
  };


enum ENUM_MTM_THEME
  {
   TH_DARK    = 0, // Dark
   TH_CLASSIC = 1, // Classic
   TH_LIGHT   = 2, // Light
   TH_POP     = 3  // Pop
  };

enum ENUM_MTM_DISPLAY
  {
   DISP_ACTIVE = 0, // Mostrar Ativo
   DISP_ALL    = 1  // Mostrar Tudo
  };

enum ENUM_MTM_NEWSIMP
  {
   NEWS_HIGH     = 0, // So alto impacto
   NEWS_HIGHMED  = 1, // Alto + medio
   NEWS_ALL      = 2  // Todos os eventos
  };

enum ENUM_MTM_NEWSACT
  {
   NEWS_BLOCK_ENTRY = 0, // So bloquear entradas novas
   NEWS_FLAT        = 1, // Bloquear entradas e fechar posicoes
   NEWS_BE          = 2  // Bloquear entradas e proteger em BE
  };

enum ENUM_MTM_DDBASE
  {
   DD_STATIC   = 0, // Estatico (saldo inicial)
   DD_TRAILING = 1  // Trailing (pico de equity)
  };


enum ENUM_MTM_LOTMODE
  {
   LOT_FIXED    = 0, // Lote fixo
   LOT_RISK_PCT = 1, // Risco em % da conta
   LOT_RISK_MNY = 2, // Risco em dinheiro por trade
   LOT_SCALED   = 3  // Lote escalado ao saldo (X lotes por cada Y)
  };

enum ENUM_MTM_DDUNIT
  {
   DDU_PERCENT = 0, // Percentagem
   DDU_MONEY   = 1  // Dinheiro (moeda da conta)
  };

enum ENUM_MTM_ENTRYMODE
  {
   ENT_AUTO    = 0, // Automatico
   ENT_CONFIRM = 1, // Confirmar no grafico (botao)
   ENT_MANUAL  = 2  // Manual (so avisa, nao executa)
  };

enum ENUM_MTM_DAYBASE
  {
   DAYB_BALANCE = 0, // Saldo ao inicio do dia
   DAYB_EQUITY  = 1  // Equity ao inicio do dia
  };

enum ENUM_MTM_NEWSSRC
  {
   SRC_FILE = 0, // Ficheiro CSV
   SRC_URL  = 1, // URL (WebRequest) com cache em CSV
   SRC_BOTH = 2  // URL e, se falhar, o CSV em cache
  };

enum ENUM_MTM_TRAILMODE
  {
   TM_OFF    = 0, // Off
   TM_ATR    = 1, // ATR
   TM_POINTS = 2  // Pontos fixos
  };

enum ENUM_MTM_RUNNER
  {
   RUN_CLOSE_LAST = 0, // Fechar tudo no ultimo Exit
   RUN_LET_RUN    = 1  // Deixar correr no trailing (o ultimo Exit nao fecha)
  };

//--- canal indicador <-> EA para niveis arrastados a mao no grafico
//    nomes tipo  MTMMAN_XAUUSD.s_3600_TP1
string MtmManualGV(const string sym,const int tfsec,const string key)
  {
   return("MTMMAN_"+sym+"_"+IntegerToString(tfsec)+"_"+key);
  }

void MtmManualClear(const string sym,const int tfsec)
  {
   string k[6]={"SL","TP1","TP2","TP3","TP4","STAMP"};
   for(int i=0;i<6;i++) GlobalVariableDel(MtmManualGV(sym,tfsec,k[i]));
  }

double MtmManualGet(const string sym,const int tfsec,const string key)
  {
   string n=MtmManualGV(sym,tfsec,key);
   return(GlobalVariableCheck(n) ? GlobalVariableGet(n) : 0.0);
  }

void MtmManualSet(const string sym,const int tfsec,const string key,const double price)
  {
   GlobalVariableSet(MtmManualGV(sym,tfsec,key),price);
   GlobalVariableSet(MtmManualGV(sym,tfsec,"STAMP"),(double)TimeCurrent());
  }

//--- Indices dos buffers publicados pelo indicador (leitura via iCustom)
//    0-22  = camada visual (linhas, cloud, setas, fases, swings, vela do sinal)
//    23-32 = dados para o EA
#define MTM_BUF_DEMA15    0
#define MTM_BUF_DEMA50    1
#define MTM_BUF_DEMA238   2
#define MTM_BUF_POC       3
#define MTM_BUF_BANDU     4
#define MTM_BUF_BANDL     5
#define MTM_BUF_CLOUDF    6
#define MTM_BUF_CLOUDS    7
#define MTM_BUF_FILLA     8
#define MTM_BUF_FILLB     9
#define MTM_BUF_ARROWUP  10
#define MTM_BUF_ARROWDN  11
#define MTM_BUF_MOMBUY   12
#define MTM_BUF_MOMSELL  13
#define MTM_BUF_EXHBUY   14
#define MTM_BUF_EXHSELL  15
#define MTM_BUF_SWHIGH   16
#define MTM_BUF_SWLOW    17
#define MTM_BUF_SIGO     18
#define MTM_BUF_SIGH     19
#define MTM_BUF_SIGL     20
#define MTM_BUF_SIGC     21
#define MTM_BUF_SIGCOL   22
#define MTM_BUF_SIGNAL   23   // +1 = BUY, -1 = SELL, 0 = sem sinal
#define MTM_BUF_ENTRY    24
#define MTM_BUF_SL       25
#define MTM_BUF_TP1      26
#define MTM_BUF_TP2      27
#define MTM_BUF_TP3      28
#define MTM_BUF_TP4      29
#define MTM_BUF_SCORE    30
#define MTM_BUF_TYPE     31
#define MTM_BUF_ATR      32

//--- o All-in-One traz o motor embutido; isto so serve aos scripts
#define MTM_VISUAL_NAME     "MTM\\MTM_Sensei_v3"
#define MTM_INDICATOR_NAME  MTM_VISUAL_NAME

#endif
