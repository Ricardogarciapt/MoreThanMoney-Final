//+------------------------------------------------------------------+
//|                                             MTM_Update.mqh       |
//|  Propriedade intelectual de RicardoGarciaPT / MoreThanMoney      |
//|                                                                  |
//|  Actualizacoes pelo ar (OTA) - o que o MetaTrader deixa mesmo    |
//|  fazer, e nao o que soa bem numa pagina de vendas.               |
//|                                                                  |
//|  O MQL5 corre numa caixa fechada: so escreve dentro de           |
//|  MQL5\Files (ou Common\Files). NAO consegue escrever por cima do |
//|  proprio .ex5 em MQL5\Experts, nem se recarregar a si mesmo.     |
//|  Quem promete "actualizacao automatica total" num EA ou esta a   |
//|  usar uma DLL - que obriga o cliente a autorizar codigo nativo - |
//|  ou nao esta a dizer a verdade.                                  |
//|                                                                  |
//|  Entao faz-se o que da mesmo:                                    |
//|                                                                  |
//|   1. PARAMETROS pelo ar - de verdade, sem tocar em ficheiros.    |
//|      O servidor manda afinacoes (risco, trailing) e o EA        |
//|      aplica-as na hora. E onde estao 90% das actualizacoes reais,|
//|      e e opt-in: ninguem mexe no risco de ninguem sem autorizar. |
//|   2. AVISO de versao nova, com o que mudou, no grafico e no log. |
//|   3. DESCARGA do novo .ex5 para MQL5\Files, pronto a arrastar -  |
//|      o instalador tambem o apanha dali.                          |
//+------------------------------------------------------------------+
#ifndef MTM_UPDATE_MQH
#define MTM_UPDATE_MQH

//--- versao desta compilacao. Sobe SEMPRE que se publica.
#define MTM_EA_VERSAO "3.1.1"

//--- de quanto em quanto tempo se pergunta ao servidor
#define MTM_UPD_INTERVALO (12*3600)

datetime g_updUltima   = 0;
string   g_updVersao   = "";   // a que o servidor diz ser a mais recente
string   g_updNotas    = "";
bool     g_updHaNova   = false;
bool     g_updBaixada  = false;

//--- afinacoes vindas do servidor. -1 / vazio = o servidor nao mandou nada e
//    manda o que o cliente tem no ecra de parametros. So risco e trailing: sao
//    os dois que se afinam de verdade e os unicos com um numero simples do
//    outro lado. Horarios ficam de fora de proposito - mudar a sessao de
//    alguem a meio de uma posicao aberta e mexer no que ja esta a correr.
double   g_updRisco    = -1;
int      g_updTrail    = -1;   // 0 off, 1 ATR, 2 pontos
string   g_updAviso    = "";   // recado nosso, mostrado no grafico

//+------------------------------------------------------------------+
//| Compara "3.10.2" com "3.9.0" pelos NUMEROS, nao pelo texto.      |
//| Em texto, "3.10" vem antes de "3.9" - e uma versao nova seria    |
//| anunciada como antiga.                                           |
//+------------------------------------------------------------------+
int UpdCmpVersao(const string a,const string b)
  {
   string pa[],pb[];
   int na=StringSplit(a,'.',pa), nb=StringSplit(b,'.',pb);
   int n=(int)MathMax(na,nb);
   for(int i=0;i<n;i++)
     {
      long va=(i<na)?StringToInteger(pa[i]):0;
      long vb=(i<nb)?StringToInteger(pb[i]):0;
      if(va!=vb) return(va>vb?1:-1);
     }
   return(0);
  }

//--- os mesmos leitores de JSON da licenca, com outro nome para nao chocarem
string UpdTexto(const string js,const string campo)
  {
   string alvo="\""+campo+"\"";
   int p=StringFind(js,alvo);
   if(p<0) return("");
   p=StringFind(js,":",p+StringLen(alvo));
   if(p<0) return("");
   int a=StringFind(js,"\"",p);
   int fim=StringFind(js,",",p);
   //--- valor nao textual (numero, null): nao ha aspas antes da virgula
   if(a<0 || (fim>=0 && a>fim)) return("");
   int b=StringFind(js,"\"",a+1);
   if(b<0) return("");
   return(StringSubstr(js,a+1,b-a-1));
  }

double UpdNumero(const string js,const string campo,const double falha)
  {
   string alvo="\""+campo+"\"";
   int p=StringFind(js,alvo);
   if(p<0) return(falha);
   p=StringFind(js,":",p+StringLen(alvo));
   if(p<0) return(falha);
   int i=p+1;
   while(i<StringLen(js) && StringGetCharacter(js,i)==' ') i++;
   int ini=i;
   while(i<StringLen(js))
     {
      ushort c=StringGetCharacter(js,i);
      if((c>='0' && c<='9') || c=='.' || c=='-') i++;
      else break;
     }
   if(i==ini) return(falha);
   return(StringToDouble(StringSubstr(js,ini,i-ini)));
  }

//+------------------------------------------------------------------+
//| Descarrega o .ex5 novo para MQL5\Files.                          |
//|                                                                  |
//| Nao substitui o que esta a correr - nao ha maneira de o fazer de |
//| dentro do MQL5. Fica ali, e o instalador (ou a pessoa) leva-o    |
//| para Experts\MTM. E um passo manual assumido, nao um esquecimento.|
//+------------------------------------------------------------------+
bool UpdBaixarBuild(const string url,const string nomeFicheiro)
  {
   if(url=="" || nomeFicheiro=="") return(false);

   char post[],result[];
   string headers="";
   ResetLastError();
   int code=WebRequest("GET",url,NULL,NULL,30000,post,0,result,headers);
   if(code!=200)
     {
      PrintFormat("MTM Sensei UPDATE: nao consegui descarregar a versao nova (HTTP %d, erro %d).",
                  code,GetLastError());
      return(false);
     }
   //--- 20 KB e menos do que qualquer build nosso: se veio assim, veio uma
   //    pagina de erro disfarcada de ficheiro, e grava-la seria pior que nada.
   if(ArraySize(result)<20000)
     {
      Print("MTM Sensei UPDATE: o ficheiro recebido e pequeno demais para ser um build. Ignorado.");
      return(false);
     }

   int h=FileOpen(nomeFicheiro,FILE_WRITE|FILE_BIN);
   if(h==INVALID_HANDLE)
     {
      PrintFormat("MTM Sensei UPDATE: nao consegui gravar em MQL5\\Files\\%s (erro %d).",
                  nomeFicheiro,GetLastError());
      return(false);
     }
   FileWriteArray(h,result,0,ArraySize(result));
   FileClose(h);

   PrintFormat("MTM Sensei UPDATE: versao %s gravada em MQL5\\Files\\%s. "
               "Fecha o EA, move o ficheiro para MQL5\\Experts\\MTM e volta a por no grafico.",
               g_updVersao,nomeFicheiro);
   return(true);
  }

//+------------------------------------------------------------------+
//| Pergunta ao servidor. `chave` vai junto para sabermos que builds |
//| estao em uso e podermos avisar quem ficou para tras.             |
//+------------------------------------------------------------------+
void UpdVerificar(const string baseUrl,const string chave,const bool baixarAuto)
  {
   if(MQLInfoInteger(MQL_TESTER)) return;
   g_updUltima=TimeCurrent();

   string url=baseUrl+"/api/sensei-ea/versao"
              +"?versao="+MTM_EA_VERSAO
              +"&chave="+chave
              +"&conta="+IntegerToString((int)AccountInfoInteger(ACCOUNT_LOGIN));

   char post[],result[];
   string headers="";
   ResetLastError();
   int code=WebRequest("GET",url,NULL,NULL,8000,post,0,result,headers);
   if(code!=200) return;   // silencioso: nao ter rede nao e um problema do cliente

   string js=CharArrayToString(result,0,WHOLE_ARRAY,CP_UTF8);

   g_updVersao=UpdTexto(js,"versao");
   g_updNotas =UpdTexto(js,"notas");
   g_updAviso =UpdTexto(js,"aviso");

   //--- afinacoes: so se aplicam as que vierem. Um campo em falta deixa o
   //    valor do cliente em paz, em vez de o pisar com um zero.
   g_updRisco  =UpdNumero(js,"risco",-1);
   g_updTrail  =(int)UpdNumero(js,"trail",-1);

   if(g_updVersao!="" && UpdCmpVersao(g_updVersao,MTM_EA_VERSAO)>0)
     {
      if(!g_updHaNova)
        {
         g_updHaNova=true;
         PrintFormat("MTM Sensei UPDATE: existe a versao %s (tens a %s). %s",
                     g_updVersao,MTM_EA_VERSAO,g_updNotas);
        }
      if(baixarAuto && !g_updBaixada)
        {
         string ficheiro=UpdTexto(js,"ficheiro");
         string urlBuild=UpdTexto(js,"url");
         if(ficheiro=="") ficheiro="MTM_Sensei_AllInOne_"+g_updVersao+".ex5";
         g_updBaixada=UpdBaixarBuild(urlBuild,ficheiro);
        }
     }

   if(g_updAviso!="") Print("MTM Sensei: ",g_updAviso);
  }

//+------------------------------------------------------------------+
//| Faixa no grafico a dizer que ha versao nova.                     |
//+------------------------------------------------------------------+
#define MTM_UPD_OBJ "MTMUPD_aviso"

void UpdBanner()
  {
   if(!g_updHaNova){ ObjectDelete(0,MTM_UPD_OBJ); return; }
   if(ObjectFind(0,MTM_UPD_OBJ)<0)
     {
      ObjectCreate(0,MTM_UPD_OBJ,OBJ_LABEL,0,0,0);
      ObjectSetInteger(0,MTM_UPD_OBJ,OBJPROP_CORNER,CORNER_RIGHT_LOWER);
      ObjectSetInteger(0,MTM_UPD_OBJ,OBJPROP_XDISTANCE,14);
      ObjectSetInteger(0,MTM_UPD_OBJ,OBJPROP_YDISTANCE,14);
      ObjectSetInteger(0,MTM_UPD_OBJ,OBJPROP_ANCHOR,ANCHOR_RIGHT_LOWER);
      ObjectSetInteger(0,MTM_UPD_OBJ,OBJPROP_COLOR,clrGold);
      ObjectSetInteger(0,MTM_UPD_OBJ,OBJPROP_FONTSIZE,9);
      ObjectSetString(0,MTM_UPD_OBJ,OBJPROP_FONT,"Arial");
      ObjectSetInteger(0,MTM_UPD_OBJ,OBJPROP_SELECTABLE,false);
     }
   string t="MTM Sensei "+g_updVersao+" disponivel";
   if(g_updBaixada) t+=" - ja em MQL5\\Files";
   ObjectSetString(0,MTM_UPD_OBJ,OBJPROP_TEXT,t);
  }

void UpdInit(const string baseUrl,const string chave,const bool ligado,const bool baixarAuto)
  {
   if(!ligado) return;
   UpdVerificar(baseUrl,chave,baixarAuto);
   UpdBanner();
  }

void UpdTick(const string baseUrl,const string chave,const bool ligado,const bool baixarAuto)
  {
   if(!ligado || MQLInfoInteger(MQL_TESTER)) return;
   if(TimeCurrent()-g_updUltima<MTM_UPD_INTERVALO) return;
   bool antes=g_updHaNova;
   UpdVerificar(baseUrl,chave,baixarAuto);
   if(antes!=g_updHaNova) UpdBanner();
  }

void UpdDeinit()
  {
   ObjectDelete(0,MTM_UPD_OBJ);
  }

#endif // MTM_UPDATE_MQH
