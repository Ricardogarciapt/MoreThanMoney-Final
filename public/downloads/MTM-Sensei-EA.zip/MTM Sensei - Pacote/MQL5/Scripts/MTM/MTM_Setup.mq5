//+------------------------------------------------------------------+
//|                                              MTM_Setup.mq5       |
//|  Configura o MetaTrader para o MTM Sensei e verifica a instalacao.|
//|  Arrasta este script para um grafico e confirma no separador      |
//|  "Especialistas" o relatorio que ele escreve.                     |
//|  Propriedade de RicardoGarciaPT / MoreThanMoney.                  |
//+------------------------------------------------------------------+
#property copyright "RicardoGarciaPT - MoreThanMoney"
#property link      "https://morethanmoney.pt"
#property version   "1.00"
#property script_show_inputs

#include <MTM/MTM_Sensei_Defs.mqh>

enum ENUM_MTM_SKIN { SKIN_WHITE=0, SKIN_DARK=1 };

input ENUM_MTM_SKIN InpSkin        = SKIN_WHITE; // Esquema de cores do grafico
input bool          InpApplyInd    = true;      // Aplicar o indicador ao grafico
input bool          InpSaveTemplate= true;      // Gravar como modelo "MTM Sensei v3"
input bool          InpSetDefault  = true;      // Gravar tambem como Default (graficos novos)
input bool          InpCheckOnly   = false;     // So verificar, sem alterar nada

int    g_ok=0,g_warn=0,g_bad=0;
string g_rep="";

void Line(const string estado,const string txt)
  {
   if(estado=="OK")   g_ok++;
   else if(estado=="!"){ g_warn++; }
   else                 g_bad++;
   string tag=(estado=="OK")?"  [OK]   ":((estado=="!")?"  [aviso]":"  [FALHA] ");
   Print(tag,txt);
   g_rep+=tag+txt+"\n";
  }

//--- o ficheiro existe na pasta partilhada?
bool CommonFileExists(const string name)
  {
   int h=FileOpen(name,FILE_READ|FILE_TXT|FILE_ANSI|FILE_COMMON);
   if(h==INVALID_HANDLE) return(false);
   FileClose(h); return(true);
  }

void ApplySkin()
  {
   ChartSetInteger(0,CHART_MODE,CHART_CANDLES);
   ChartSetInteger(0,CHART_SHOW_GRID,false);
   ChartSetInteger(0,CHART_SHOW_VOLUMES,CHART_VOLUME_HIDE);
   ChartSetInteger(0,CHART_SHOW_PERIOD_SEP,false);
   ChartSetInteger(0,CHART_SHIFT,true);
   ChartSetInteger(0,CHART_AUTOSCROLL,true);
   if(InpSkin==SKIN_WHITE)
     {
      ChartSetInteger(0,CHART_COLOR_BACKGROUND ,clrWhite);
      ChartSetInteger(0,CHART_COLOR_FOREGROUND ,clrBlack);
      ChartSetInteger(0,CHART_COLOR_GRID       ,C'192,192,192');
      ChartSetInteger(0,CHART_COLOR_CHART_UP   ,clrBlack);
      ChartSetInteger(0,CHART_COLOR_CHART_DOWN ,clrBlack);
      ChartSetInteger(0,CHART_COLOR_CHART_LINE ,clrBlack);
      ChartSetInteger(0,CHART_COLOR_CANDLE_BULL,clrWhite);
      ChartSetInteger(0,CHART_COLOR_CANDLE_BEAR,clrBlack);
      ChartSetInteger(0,CHART_COLOR_BID        ,C'192,192,192');
      ChartSetInteger(0,CHART_COLOR_ASK        ,C'192,192,192');
      ChartSetInteger(0,CHART_COLOR_LAST       ,C'192,192,192');
      ChartSetInteger(0,CHART_COLOR_STOP_LEVEL ,C'255,69,0');
     }
   else
     {
      ChartSetInteger(0,CHART_COLOR_BACKGROUND ,C'13,13,26');
      ChartSetInteger(0,CHART_COLOR_FOREGROUND ,clrWhite);
      ChartSetInteger(0,CHART_COLOR_GRID       ,C'30,27,75');
      ChartSetInteger(0,CHART_COLOR_CHART_UP   ,C'34,197,94');
      ChartSetInteger(0,CHART_COLOR_CHART_DOWN ,C'239,68,68');
      ChartSetInteger(0,CHART_COLOR_CHART_LINE ,clrSilver);
      ChartSetInteger(0,CHART_COLOR_CANDLE_BULL,C'34,197,94');
      ChartSetInteger(0,CHART_COLOR_CANDLE_BEAR,C'239,68,68');
      ChartSetInteger(0,CHART_COLOR_BID        ,C'124,58,237');
     }
  }

void OnStart()
  {
   Print("================ MTM SENSEI · INSTALACAO ================");
   PrintFormat("  terminal build %d   ·   %s %s",
               (int)TerminalInfoInteger(TERMINAL_BUILD),
               _Symbol,EnumToString((ENUM_TIMEFRAMES)_Period));

   //---------------- verificacoes ----------------
   int h=iCustom(_Symbol,_Period,MTM_VISUAL_NAME);
   if(h!=INVALID_HANDLE){ Line("OK","indicador MTM_Sensei_v3 encontrado e compilado"); }
   else Line("X","indicador MTM_Sensei_v3 NAO carrega - compila-o no MetaEditor (F7)");

   if(CommonFileExists("mtm_news.csv"))
      Line("OK","mtm_news.csv presente na pasta partilhada (filtro de noticias)");
   else
      Line("!","mtm_news.csv em falta em Common\\Files - o filtro externo fica sem dados");

   if(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
      Line("OK","AutoTrading ligado no terminal");
   else
      Line("!","AutoTrading DESLIGADO - o EA nao vai executar (botao na barra de topo)");

   long mm=AccountInfoInteger(ACCOUNT_MARGIN_MODE);
   if(mm==ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
      Line("OK","conta em modo HEDGING - varias posicoes no mesmo par sao possiveis");
   else
      Line("!","conta em modo NETTING - as entradas fundem-se numa posicao so");

   //--- o "ponto" deste simbolo, que e o que estraga trailings mal calibrados
   int    dg=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   double pt=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   PrintFormat("  [info]  %s tem %d casas decimais · 1 ponto = %s · 1000 pontos = %s",
               _Symbol,dg,DoubleToString(pt,dg),DoubleToString(1000*pt,dg));
   long sp=SymbolInfoInteger(_Symbol,SYMBOL_SPREAD);
   PrintFormat("  [info]  spread actual %d pontos - se usares filtro de spread, poe-o acima de %d",
               (int)sp,(int)(sp*3));

   if(InpCheckOnly)
     {
      Print("  (modo so-verificacao: nada foi alterado)");
     }
   else
     {
      ApplySkin();
      Line("OK",(InpSkin==SKIN_WHITE)?"esquema Color On White aplicado":"esquema escuro MTM aplicado");

      if(InpApplyInd && h!=INVALID_HANDLE)
        {
         if(ChartIndicatorAdd(0,0,h)) Line("OK","indicador aplicado ao grafico");
         else                         Line("!","nao consegui aplicar o indicador (ja la esta?)");
        }
      ChartRedraw(); Sleep(400);

      if(InpSaveTemplate)
        {
         if(ChartSaveTemplate(0,"MTM Sensei v3")) Line("OK","modelo \"MTM Sensei v3\" gravado");
         else Line("X","falha a gravar o modelo");
        }
      if(InpSetDefault)
        {
         if(ChartSaveTemplate(0,"Default")) Line("OK","gravado como Default - graficos novos abrem assim");
         else Line("X","falha a gravar o Default");
        }
     }

   if(h!=INVALID_HANDLE) IndicatorRelease(h);

   PrintFormat("========  %d ok · %d avisos · %d falhas  ========",g_ok,g_warn,g_bad);
   if(g_bad>0)      Print("  Resolve as FALHAS antes de operar.");
   else if(g_warn>0)Print("  Instalacao utilizavel; ve os avisos acima.");
   else             Print("  Tudo pronto. Anexa o MTM_Sensei_AllInOne e carrega o preset do teu par.");

   Comment("MTM SENSEI · instalacao\n"+g_rep+
           StringFormat("\n%d ok · %d avisos · %d falhas",g_ok,g_warn,g_bad));
  }
//+------------------------------------------------------------------+
