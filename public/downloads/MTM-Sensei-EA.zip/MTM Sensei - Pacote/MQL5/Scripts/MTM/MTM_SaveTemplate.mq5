//+------------------------------------------------------------------+
//|                                        MTM_SaveTemplate.mq5      |
//|  Aplica o MTM Sensei v3 ao grafico atual e grava o template.      |
//|  Arrasta este script para um grafico ja configurado como queres.  |
//|  Propriedade de RicardoGarciaPT / MoreThanMoney.                  |
//+------------------------------------------------------------------+
#property copyright "RicardoGarciaPT - MoreThanMoney"
#property link      "https://morethanmoney.pt"
#property version   "1.00"
#property script_show_inputs

#include <MTM/MTM_Sensei_Defs.mqh>

input string InpTemplateName = "MTM Sensei v3"; // Nome do template a gravar
input bool   InpApplyColors  = true;            // Aplicar esquema Color On White
input bool   InpAlsoDefault  = true;            // Gravar TAMBEM como Default (todos os graficos novos)

void OnStart()
  {
   if(InpApplyColors)
     {
      //--- esquema "Color On White" do MetaTrader, valor a valor
      ChartSetInteger(0,CHART_MODE,CHART_CANDLES);
      ChartSetInteger(0,CHART_COLOR_BACKGROUND ,clrWhite);
      ChartSetInteger(0,CHART_COLOR_FOREGROUND ,clrBlack);
      ChartSetInteger(0,CHART_COLOR_GRID       ,C'192,192,192');
      ChartSetInteger(0,CHART_COLOR_CHART_UP   ,clrBlack);
      ChartSetInteger(0,CHART_COLOR_CHART_DOWN ,clrBlack);
      ChartSetInteger(0,CHART_COLOR_CHART_LINE ,clrBlack);
      ChartSetInteger(0,CHART_COLOR_CANDLE_BULL,clrWhite);
      ChartSetInteger(0,CHART_COLOR_CANDLE_BEAR,clrBlack);
      ChartSetInteger(0,CHART_COLOR_VOLUME     ,C'0,128,0');
      ChartSetInteger(0,CHART_COLOR_BID        ,C'192,192,192');
      ChartSetInteger(0,CHART_COLOR_ASK        ,C'192,192,192');
      ChartSetInteger(0,CHART_COLOR_LAST       ,C'192,192,192');
      ChartSetInteger(0,CHART_COLOR_STOP_LEVEL ,C'255,69,0');
      ChartSetInteger(0,CHART_SHOW_GRID,false);
      ChartSetInteger(0,CHART_SHOW_VOLUMES,CHART_VOLUME_HIDE);
      ChartSetInteger(0,CHART_SHOW_PERIOD_SEP,false);
      ChartSetInteger(0,CHART_SHIFT,true);
      ChartSetInteger(0,CHART_AUTOSCROLL,true);
     }

   int h=iCustom(_Symbol,_Period,MTM_VISUAL_NAME);
   if(h==INVALID_HANDLE)
     {
      Print("MTM: nao consegui carregar ",MTM_VISUAL_NAME," - compila primeiro o indicador.");
      return;
     }
   if(!ChartIndicatorAdd(0,0,h))
      Print("MTM: falha a aplicar o indicador, erro ",GetLastError());

   ChartRedraw();
   Sleep(500);

   if(ChartSaveTemplate(0,InpTemplateName))
      Print("MTM: template gravado como \"",InpTemplateName,"\". Ja aparece em Graficos > Modelo.");
   else
      Print("MTM: falha a gravar o template, erro ",GetLastError());

   if(InpAlsoDefault)
     {
      if(ChartSaveTemplate(0,"Default"))
         Print("MTM: gravado tambem como Default - qualquer grafico novo abre assim.");
      else
         Print("MTM: falha a gravar o Default, erro ",GetLastError());
     }
  }
//+------------------------------------------------------------------+
