//+------------------------------------------------------------------+
//|                                            MTM_Preview.mq5       |
//|  Abre um grafico, aplica o template MTM Sensei v3 e grava um PNG  |
//|  em MQL5\Files. Arrasta este script para qualquer grafico.        |
//|  Propriedade de RicardoGarciaPT / MoreThanMoney.                  |
//+------------------------------------------------------------------+
#property copyright "RicardoGarciaPT - MoreThanMoney"
#property link      "https://morethanmoney.pt"
#property version   "1.00"
#property script_show_inputs

input string          InpSymbol   = "XAUUSD";        // Simbolo (deteta sufixo da corretora)
input ENUM_TIMEFRAMES InpPeriod   = PERIOD_H1;       // Timeframe
input string          InpTemplate = "MTM Sensei v3"; // Template a aplicar
input int             InpWidth    = 1800;            // Largura do PNG
input int             InpHeight   = 1000;            // Altura do PNG
input string          InpOutFile  = "MTM_preview.png"; // Ficheiro de saida (MQL5\Files)
input bool            InpCloseAfter = true;          // Fechar o grafico no fim

//--- encontra o simbolo real (XAUUSD.s, XAUUSD.r, GOLD, ...)
string ResolveSymbol(const string want)
  {
   if(want=="") return(_Symbol);
   string w=want; StringToUpper(w);
   if(SymbolInfoInteger(want,SYMBOL_SELECT)) return(want);
   //--- 1a passagem: so os simbolos do Market Watch
   for(int pass=0;pass<2;pass++)
     {
      bool selected=(pass==0);
      int total=SymbolsTotal(selected);
      for(int i=0;i<total;i++)
        {
         string s=SymbolName(i,selected);
         string u=s; StringToUpper(u);
         if(StringFind(u,w)>=0) return(s);
        }
     }
   //--- alternativa para ouro
   if(w=="XAUUSD")
     {
      int total=SymbolsTotal(false);
      for(int i=0;i<total;i++)
        {
         string s=SymbolName(i,false);
         string u=s; StringToUpper(u);
         if(StringFind(u,"GOLD")>=0) return(s);
        }
     }
   return("");
  }

void OnStart()
  {
   string sym=ResolveSymbol(InpSymbol);
   if(sym=="")
     {
      Print("MTM Preview: nao encontrei nenhum simbolo parecido com ",InpSymbol);
      return;
     }
   if(!SymbolInfoInteger(sym,SYMBOL_SELECT)) SymbolSelect(sym,true);
   Print("MTM Preview: simbolo resolvido -> ",sym);

   long cid=ChartOpen(sym,InpPeriod);
   if(cid==0)
     {
      Print("MTM Preview: falha a abrir o grafico, erro ",GetLastError());
      return;
     }
   Sleep(1500);

   //--- garante que ha historico carregado
   int tries=0;
   while(Bars(sym,InpPeriod)<1500 && tries<20){ Sleep(500); tries++; }
   Print("MTM Preview: barras disponiveis = ",Bars(sym,InpPeriod));

   string tpl=InpTemplate;
   if(StringFind(tpl,".tpl")<0) tpl=tpl+".tpl";
   if(!ChartApplyTemplate(cid,tpl))
      Print("MTM Preview: falha a aplicar o template \"",tpl,"\", erro ",GetLastError());
   else
      Print("MTM Preview: template aplicado.");

   ChartSetInteger(cid,CHART_SHIFT,true);
   ChartRedraw(cid);
   Sleep(4000);   // dar tempo ao indicador para calcular a historia toda

   if(ChartScreenShot(cid,InpOutFile,InpWidth,InpHeight,ALIGN_RIGHT))
      Print("MTM Preview: imagem gravada em MQL5\\Files\\",InpOutFile);
   else
      Print("MTM Preview: falha no screenshot, erro ",GetLastError());

   //--- indicadores realmente aplicados, para confirmacao no log
   int n=ChartIndicatorsTotal(cid,0);
   for(int i=0;i<n;i++) Print("MTM Preview: indicador na janela 0 -> ",ChartIndicatorName(cid,0,i));

   if(InpCloseAfter){ Sleep(500); ChartClose(cid); }
  }
//+------------------------------------------------------------------+
