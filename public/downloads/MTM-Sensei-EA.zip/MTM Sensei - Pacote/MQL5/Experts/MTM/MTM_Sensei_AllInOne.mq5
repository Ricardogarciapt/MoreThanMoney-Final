//+------------------------------------------------------------------+
//|                                       MTM_Sensei_AllInOne.mq5    |
//|  Este software e codigo sao parte integrante da propriedade       |
//|  intelectual de RicardoGarciaPT e da sua empresa MoreThanMoney    |
//|                                                                  |
//|  TUDO NUM SO: o motor do indicador corre DENTRO do EA.            |
//|  Nao usa iCustom, nao precisa do indicador instalado, desenha no  |
//|  proprio grafico e executa. Um unico ficheiro a anexar.           |
//+------------------------------------------------------------------+
#property copyright "RicardoGarciaPT - MoreThanMoney"
#property link      "https://morethanmoney.pt"
#property version   "3.11"
#property description "MTM Sensei v3 All-in-One - indicador + execucao no mesmo EA"

#include <Trade/Trade.mqh>

#include <MTM/MTM_Sensei_Defs.mqh>
#include <MTM/MTM_Licenca.mqh>
#include <MTM/MTM_Update.mqh>

//====================================================================
//  INPUTS DE TRADING  (os do Sensei/visual vem a seguir, do motor)
//====================================================================
input group                   "=== LICENCA ==="
input string           InpLicenseKey      = "";        // Licenca (MTM-XXXX-XXXX-XXXX)
input string           InpLicenseUrl      = "https://www.morethanmoney.pt"; // Servidor (permitir em Opcoes > Consultores)

input group                   "=== ACTUALIZACOES ==="
input bool             InpOtaCheck        = true;      // Avisar quando houver versao nova
input bool             InpOtaDownload     = false;     // Descarregar o build novo para a pasta Files
input bool             InpOtaParams       = false;     // Aceitar afinacoes de risco/trailing do servidor

input group                   "=== EXECUCAO ==="
input bool             InpEnableTrading   = true;      // Ligar execucao
input ENUM_MTM_ENTRYMODE InpEntryMode     = ENT_AUTO;  // Tipo de entrada
input int              InpConfirmSeconds  = 120;       // Confirmacao: validade do botao (seg)
input bool             InpSignalAlert     = true;      // Avisar (popup/push) em cada sinal
input string           InpWatchSymbols    = "";        // Garantir no Market Watch (lista por virgulas)
input long             InpMagic           = 20260829;  // Magic number
input string           InpComment         = "MTM Sensei"; // Comentario das ordens
input ENUM_MTM_ORDER   InpOrderType       = MTM_ORDER_MARKET; // Tipo de ordem
input int              InpLimitExpiryBars = 3;         // LIMIT: validade em barras
input int              InpMaxSpreadPoints = 0;         // Spread maximo (pontos, 0=off) -- ver nota no log
input ulong            InpDeviation       = 20;        // Desvio maximo (pontos)
input int              InpMaxPositions    = 0;         // Posicoes simultaneas no mesmo par (0 = 1, maximo 5)
input bool             InpCloseOnOpposite = false;     // Fechar na inversao de sinal
input int              InpMinScoreToTrade = 0;         // Score minimo p/ executar (0 = usa o do indicador)

input group                   "=== MOTOR ==="
input int              InpEngineBars      = 5000;      // Barras que o motor analisa

input group                   "=== RISCO / DIMENSIONAMENTO ==="
input ENUM_MTM_LOTMODE InpLotMode         = LOT_RISK_PCT; // Como calcular o volume
input double           InpFixedLot        = 0.01;      // Lote fixo (modo Lote fixo)
input double           InpRiskPercent     = 1.0;       // Risco por trade (%)
input double           InpRiskMoney       = 100.0;     // Risco por trade em dinheiro
input double           InpScaledLot       = 0.01;      // Lote por cada... (modo escalado)
input double           InpScaledPer       = 1000.0;    // ...N de saldo (modo escalado)
input ENUM_MTM_RISKBASE InpRiskBase       = RB_BALANCE;// Base do risco (saldo / equity)
input double           InpMinLot          = 0.0;       // Lote minimo imposto (0 = o da corretora)
input double           InpMaxLot          = 5.0;       // Lote maximo
input double           InpMaxDailyLossPct = 0.0;       // Guarda simples de perda diaria % (0 = off)

input group                   "=== SAIDAS PARCIAIS ==="
input bool             InpUseTP1          = true;      // Usar Exit 1
input int              InpPct1            = 25;        // % fechada no Exit 1
input bool             InpUseTP2          = true;      // Usar Exit 2
input int              InpPct2            = 25;        // % fechada no Exit 2
input bool             InpUseTP3          = true;      // Usar Exit 3
input int              InpPct3            = 25;        // % fechada no Exit 3
input bool             InpUseTP4          = true;      // Usar Exit 4 (fecha o resto)
input int              InpPct4            = 25;        // % fechada no Exit 4
input bool             InpSetBrokerTP     = true;      // Colocar TP final na corretora

input group                   "=== BREAKEVEN ==="
input ENUM_MTM_BE      InpEaBeMode        = BE_EXIT1;  // Mover SL para BE em
input double           InpEaBePoints      = 10.0;      // Pontos (modo Pontos)
input int              InpBeOffsetPoints  = 2;         // Offset do BE (pontos a favor)

input group                   "=== TRAILING STOP ==="
input ENUM_MTM_TRAILMODE InpEaTrailMode   = TM_POINTS; // Modo do trailing stop
input double           InpEaTrailMult     = 1.5;       // Distancia em ATR (modo ATR)
input int              InpEaTrailPoints   = 1500;      // Distancia em pontos (modo Pontos)
input int              InpEaTrailAtrPer   = 14;        // Periodo ATR do trailing
input ENUM_MTM_TRAILSTART InpTrailStart    = TS_AFTER_TP1; // Trailing arranca
input int              InpTrailStartPts   = 0;         // So arranca com N pontos de lucro (0=off)
input int              InpTrailStepPts    = 200;       // Passo minimo p/ mexer o SL (0 = 10% da distancia)

input group                   "=== TRAILING PROFIT (deixar correr) ==="
input ENUM_MTM_TRAILMODE InpTPTrailMode   = TM_OFF;    // Modo do trailing profit
input int              InpTPTrailTrigPts  = 200;       // Empurra o TP quando o preco fica a N pontos
input int              InpTPTrailStepPts  = 300;       // Quanto empurra o TP (pontos)
input double           InpTPTrailMult     = 1.0;       // Gatilho/passo em ATR (modo ATR)
input double           InpTPTrailMaxR     = 0.0;       // Extensao maxima em R (0 = sem limite)
input ENUM_MTM_RUNNER  InpRunnerMode      = RUN_CLOSE_LAST; // O que faz o ultimo Exit

input group                   "=== PROP FIRM ==="
input bool             InpPropEnable      = false;     // Ligar regras de prop firm (OFF para backtest)
input bool             InpPropIgnoreDD    = false;     // IGNORAR limites de drawdown (diario e total)
input bool             InpPropResetState  = false;     // Limpar estado gravado no arranque (destrava o dia)
input double           InpPropInitBalance = 0.0;       // Saldo inicial (0 = deteta automaticamente)
input ENUM_MTM_DDUNIT  InpPropUnit        = DDU_PERCENT; // Limites em percentagem ou em dinheiro
input ENUM_MTM_DAYBASE InpPropDayBase     = DAYB_BALANCE; // Base do dia (saldo ou equity de abertura)
input double           InpPropDailyLossPct= 4.0;       // Perda diaria maxima (%)
input double           InpPropDailyLossMny= 400.0;     // Perda diaria maxima (dinheiro)
input double           InpPropMaxDDPct    = 8.0;       // Drawdown total maximo (%)
input double           InpPropMaxDDMny    = 800.0;     // Drawdown total maximo (dinheiro)
input ENUM_MTM_DDBASE  InpPropDDBase      = DD_STATIC; // Base do drawdown total
input double           InpPropTargetPct   = 8.0;       // Alvo de lucro (%) - 0 = sem alvo
input double           InpPropTargetMny   = 800.0;     // Alvo de lucro (dinheiro) - 0 = sem alvo
input double           InpPropSafetyPct   = 80.0;      // Agir a X% do limite (margem de seguranca)
input bool             InpPropCloseBreach = true;      // Fechar tudo ao atingir o limite
input double           InpPropMaxRiskPct  = 1.0;       // Risco maximo por trade (%)
input double           InpPropMaxRiskMny  = 0.0;       // Risco maximo por trade (dinheiro, 0=off)
input double           InpPropMaxTotalLot = 0.0;       // Exposicao maxima em lotes (0 = sem limite)
input int              InpPropMaxTrades   = 0;         // Trades por dia (0 = sem limite)
input bool             InpPropFlatWeekend = true;      // Ficar flat ao fim de semana
input bool             InpPropStopOnTarget= true;      // Parar de operar ao atingir o alvo
input bool             InpPropPanel       = true;      // Mostrar painel de controlo no grafico
input bool             InpPanelEnglish    = false;     // Painel em ingles (senao portugues)
input bool             InpDrawPlots       = true;      // Desenhar DEMAs/cloud/bandas (aplica o indicador)


input group                   "=== FILTRO DE NOTICIAS (calendario MT5) ==="
input bool             InpUseNews         = true;      // Ligar filtro de noticias
input ENUM_MTM_NEWSIMP InpNewsImportance  = NEWS_HIGH; // Impacto a considerar
input ENUM_MTM_NEWSACT InpNewsAction      = NEWS_BLOCK_ENTRY; // O que fazer na janela
input int              InpNewsBeforeMin   = 30;        // Minutos ANTES do evento
input int              InpNewsAfterMin    = 30;        // Minutos DEPOIS do evento
input bool             InpNewsSymbolCcy   = true;      // So moedas do simbolo
input string           InpNewsExtraCcy    = "USD";     // Moedas extra (virgulas, vazio = nenhuma)
input bool             InpNewsSkipHoliday = true;      // Ignorar feriados do calendario
input int              InpNewsShiftMin    = 0;         // Correcao de fuso do calendario (min)
input int              InpNewsRefreshMin  = 15;        // Refrescar calendario a cada N minutos

input group                   "=== NOTICIAS: FONTE EXTERNA ==="
input bool             InpExtNews         = false;     // Ligar fonte externa (junta-se a do MT5)
input ENUM_MTM_NEWSSRC InpExtSource       = SRC_BOTH;  // De onde vem
input string           InpExtUrl          = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"; // URL (JSON ForexFactory)
input string           InpExtFile         = "mtm_news.csv"; // Ficheiro CSV
input bool             InpExtCommonFolder = true;      // Usar a pasta Common (o tester tambem le)
input int              InpExtRefreshMin   = 60;        // Refrescar do URL a cada N minutos
input bool             InpExtSaveCache    = true;      // Gravar o que vem do URL para o CSV
input int              InpExtServerGMT    = 999;       // GMT do servidor (999 = automatico)

input group                   "=== HORARIO ==="
input bool             InpEaUseSession    = false;     // Filtro de horario do EA
input string           InpEaSessStart     = "07:00";   // Inicio (hora do servidor)
input string           InpEaSessEnd       = "21:00";   // Fim (hora do servidor)
input bool             InpFridayClose     = false;     // Fechar tudo a sexta
input int              InpFridayHour      = 21;        // Hora do fecho de sexta
input bool             InpCloseEOD        = false;     // Fechar trades no fim do dia (1/0)
input int              InpEODHour         = 23;        // Fim do dia - hora (servidor)
input int              InpEODMinute       = 45;        // Fim do dia - minuto

input group                   "=== PROTECOES DE ENTRADA ==="
input int              InpMaxEntryDrift   = 0;         // Desvio max. preco vs entrada do sinal (pontos, 0=off)
input bool             InpSkipIfPassed    = true;      // Ignorar sinal se o preco ja passou SL ou Exit 1
input bool             InpAdoptOrphans    = true;      // Adoptar posicoes sem estado guardado

input group                   "=== GESTAO MANUAL (linhas do grafico) ==="
input bool             InpUseManualLines  = true;      // Seguir as linhas arrastadas no grafico


//====================================================================
//  MOTOR DO SENSEI  (traz os inputs de sinal e os visuais)
//====================================================================
#define MTM_EMBEDDED
#define MTM_VISUAL
#include <MTM/MTM_Sensei_Engine.mqh>
#include <MTM/MTM_Panel.mqh>

//====================================================================
//  GLOBAIS
//====================================================================
CTrade        trade;
int           g_atrH=INVALID_HANDLE;
int           g_visH=INVALID_HANDLE;   // instancia visual do indicador
datetime      g_lastSignalBar=0;
datetime      g_lastBarTime=0;
double        g_lotStep=0.01,g_lotMin=0.01,g_lotMax=100.0;
int           g_maxPos=1;        // InpMaxPositions ja normalizado (1..5)
int           g_digits=5;
double        g_point=0.00001;
string        g_gvPrefix="";
//--- sinal a espera de confirmacao manual
bool     g_pendActive=false;
int      g_pendDir=0,g_pendScore=0;
double   g_pendEntry=0,g_pendSL=0,g_pendT1=0,g_pendT2=0,g_pendT3=0,g_pendT4=0;
datetime g_pendExpiry=0;

//--- bits do estado
#define F_TP1  1
#define F_TP2  2
#define F_TP3  4
#define F_TP4  8
#define F_BE  16

//====================================================================
//  ESTADO PERSISTENTE POR POSICAO (GlobalVariables do terminal)
//====================================================================
string GVN(const ulong ticket,const string k)
  { return(g_gvPrefix+IntegerToString((long)ticket)+"_"+k); }

void StateSave(const ulong t,const double entry,const double sl,
               const double t1,const double t2,const double t3,const double t4,
               const double vol,const int dir,const int flags)
  {
   GlobalVariableSet(GVN(t,"e"),entry);
   GlobalVariableSet(GVN(t,"s"),sl);
   GlobalVariableSet(GVN(t,"1"),t1);
   GlobalVariableSet(GVN(t,"2"),t2);
   GlobalVariableSet(GVN(t,"3"),t3);
   GlobalVariableSet(GVN(t,"4"),t4);
   GlobalVariableSet(GVN(t,"v"),vol);
   GlobalVariableSet(GVN(t,"d"),(double)dir);
   GlobalVariableSet(GVN(t,"f"),(double)flags);
  }

bool StateLoad(const ulong t,double &entry,double &sl,double &t1,double &t2,
               double &t3,double &t4,double &vol,int &dir,int &flags)
  {
   if(!GlobalVariableCheck(GVN(t,"e"))) return(false);
   entry=GlobalVariableGet(GVN(t,"e"));
   sl   =GlobalVariableGet(GVN(t,"s"));
   t1   =GlobalVariableGet(GVN(t,"1"));
   t2   =GlobalVariableGet(GVN(t,"2"));
   t3   =GlobalVariableGet(GVN(t,"3"));
   t4   =GlobalVariableGet(GVN(t,"4"));
   vol  =GlobalVariableGet(GVN(t,"v"));
   dir  =(int)GlobalVariableGet(GVN(t,"d"));
   flags=(int)GlobalVariableGet(GVN(t,"f"));
   return(true);
  }

void StateFlags(const ulong t,const int flags)
  { GlobalVariableSet(GVN(t,"f"),(double)flags); }

void StateDel(const ulong t)
  {
   string k[9]={"e","s","1","2","3","4","v","d","f"};
   for(int i=0;i<9;i++) GlobalVariableDel(GVN(t,k[i]));
  }

//--- limpa estado de posicoes/ordens que ja nao existem
void StateCleanup()
  {
   int n=GlobalVariablesTotal();
   for(int i=n-1;i>=0;i--)
     {
      string nm=GlobalVariableName(i);
      if(StringFind(nm,g_gvPrefix)!=0) continue;
      string rest=StringSubstr(nm,StringLen(g_gvPrefix));
      int us=StringFind(rest,"_");
      if(us<=0) continue;
      ulong tk=(ulong)StringToInteger(StringSubstr(rest,0,us));
      if(PositionSelectByTicket(tk)) continue;
      if(OrderSelect(tk)) continue;
      GlobalVariableDel(nm);
     }
  }

//====================================================================
//  HELPERS
//====================================================================
int EaParseHM(const string s)
  {
   string p[];
   if(StringSplit(s,':',p)<2) return(0);
   return((int)StringToInteger(p[0])*60+(int)StringToInteger(p[1]));
  }

bool EaSessionOK()
  {
   if(!InpEaUseSession) return(true);
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   int cur=d.hour*60+d.min;
   int a=EaParseHM(InpEaSessStart),b=EaParseHM(InpEaSessEnd);
   if(a==b) return(true);
   if(a<b)  return(cur>=a && cur<b);
   return(cur>=a || cur<b);
  }

double NormLot(double lot)
  {
   if(g_lotStep<=0) g_lotStep=0.01;
   lot=MathFloor(lot/g_lotStep+0.0000001)*g_lotStep;
   double floorLot=MathMax(g_lotMin,InpMinLot);
   if(lot<floorLot) lot=(InpMinLot>0 && floorLot>=g_lotMin)?floorLot:0.0;
   if(lot>g_lotMax) lot=g_lotMax;
   if(lot>InpMaxLot) lot=MathFloor(InpMaxLot/g_lotStep)*g_lotStep;
   return(NormalizeDouble(lot,2));
  }

double CalcLot(const double entry,const double sl)
  {
   double lot=0.0;
   double base=(InpRiskBase==RB_EQUITY)?AccountInfoDouble(ACCOUNT_EQUITY)
                                       :AccountInfoDouble(ACCOUNT_BALANCE);

   //--- o painel manda: modo 1 = lotes fixos, modo 0 = risco %
   if(g_uiLotMode==1) lot=g_uiRisk;
   else if(InpLotMode==LOT_FIXED) lot=InpFixedLot;
   else if(InpLotMode==LOT_SCALED)
     {
      if(InpScaledPer<=0) return(0.0);
      lot=InpScaledLot*(base/InpScaledPer);
     }
   else
     {
      //--- dimensionamento por risco: precisa da distancia ao SL
      double dist=MathAbs(entry-sl);
      if(dist<=0) return(0.0);
      double tickVal=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
      double tickSz =SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
      if(tickSz<=0 || tickVal<=0)
        {
         Print("MTM Sensei: sem tick value/size do simbolo - a usar lote fixo");
         lot=InpFixedLot;
        }
      else
        {
         double lossPerLot=(dist/tickSz)*tickVal;
         if(lossPerLot<=0) return(0.0);
         double riskMoney;
         if(InpLotMode==LOT_RISK_MNY) riskMoney=InpRiskMoney;
         else                         riskMoney=base*PropRiskCapPct(g_uiRisk)/100.0;
         //--- teto de risco da prop firm tambem em dinheiro
         riskMoney=PropRiskCapMoney(riskMoney,base);
         lot=riskMoney/lossPerLot;
        }
     }
   double n=NormLot(lot);
   if(n<=0 && InpMinLot>0) n=NormLot(InpMinLot);
   return(n);
  }

int CountPositions()
  {
   int c=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      c++;
     }
   return(c);
  }

int CountPendings()
  {
   int c=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong tk=OrderGetTicket(i);
      if(tk==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=_Symbol) continue;
      if(OrderGetInteger(ORDER_MAGIC)!=InpMagic) continue;
      c++;
     }
   return(c);
  }

bool SpreadOK()
  {
   if(InpMaxSpreadPoints<=0) return(true);
   long sp=SymbolInfoInteger(_Symbol,SYMBOL_SPREAD);
   return(sp<=InpMaxSpreadPoints);
  }

double MinStopDist()
  {
   long lvl=SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL);
   return((double)lvl*g_point);
  }

//--- guarda de perda diaria
bool DailyLossOK()
  {
   if(InpMaxDailyLossPct<=0.0) return(true);
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   //--- prefixo diferente do estado das posicoes para o StateCleanup nao o apagar
   string key="MTMD"+IntegerToString(InpMagic)+"_"+IntegerToString(d.year*10000+(d.mon*100)+d.day);
   double startBal;
   if(!GlobalVariableCheck(key))
     {
      startBal=AccountInfoDouble(ACCOUNT_BALANCE);
      GlobalVariableSet(key,startBal);
     }
   else startBal=GlobalVariableGet(key);
   if(startBal<=0) return(true);
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   double ddPct=(startBal-eq)/startBal*100.0;
   return(ddPct<InpMaxDailyLossPct);
  }

//--- ultimo Exit ativo (o que fecha o resto da posicao)
int LastActiveTP()
  {
   if(InpUseTP4) return(4);
   if(InpUseTP3) return(3);
   if(InpUseTP2) return(2);
   if(InpUseTP1) return(1);
   return(0);
  }


//====================================================================
//  INPUTS DE EXECUCAO
//====================================================================
//====================================================================
//  ONINIT
//====================================================================
//+------------------------------------------------------------------+
//| Aplica as afinacoes que o servidor mandou.                        |
//|                                                                   |
//| So com InpOtaParams ligado: um servidor que pode mudar o risco de |
//| quem esta a operar e poder a mais para se ter por defeito. E os    |
//| valores sao apertados aqui na mesma - um erro nosso do outro lado  |
//| nao pode chegar a conta de ninguem como "risco 80%".              |
//+------------------------------------------------------------------+
void AplicarOta()
  {
   if(!InpOtaParams) return;

   if(g_updRisco>0 && g_uiLotMode==0)
     {
      double r=MathMin(MathMax(g_updRisco,0.05),5.0);
      if(MathAbs(r-g_uiRisk)>0.001)
        {
         PrintFormat("MTM Sensei: risco afinado pelo servidor: %.2f%% (era %.2f%%)",r,g_uiRisk);
         g_uiRisk=r;
         if(ObjectFind(0,PN"risk")>=0)
            ObjectSetString(0,PN"risk",OBJPROP_TEXT,DoubleToString(g_uiRisk,2));
        }
     }

   if(g_updTrail>=0 && g_updTrail<=2 && g_updTrail!=g_uiTrailMode)
     {
      PrintFormat("MTM Sensei: trailing afinado pelo servidor: %s",
                  (g_updTrail==0?"desligado":(g_updTrail==1?"ATR":"pontos")));
      g_uiTrailMode=g_updTrail;
     }
  }

int OnInit()
  {
   g_digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   g_point =SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   //--- 0 vale 1; acima de 5 fica preso em 5
   g_maxPos=(InpMaxPositions<=0)?1:(int)MathMin(InpMaxPositions,5);
   if(InpMaxPositions>5)
      Print("MTM Sensei: InpMaxPositions acima do maximo - limitado a 5 posicoes.");
   if(g_maxPos>1 &&
      (ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE)!=ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
      Print("MTM Sensei: AVISO - a conta e NETTING. Varias entradas no mesmo par fundem-se ",
            "numa unica posicao (o volume soma), nao ficam separadas. ",
            "Posicoes simultaneas so existem em conta HEDGING.");

   g_lotStep=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   g_lotMin =SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   g_lotMax =SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   if(g_lotStep<=0) g_lotStep=0.01;

   g_gvPrefix="MTMS"+IntegerToString(InpMagic)+"_";
   g_tfsec=PeriodSeconds(_Period);

   //--- no tester os agentes sao reutilizados entre passagens: o estado tem de
   //    comecar limpo, senao o saldo inicial e o "dia travado" da passagem
   //    anterior contaminam a seguinte
   if(MQLInfoInteger(MQL_TESTER))
     {
      GlobalVariablesDeleteAll(g_gvPrefix);
      GlobalVariablesDeleteAll("MTMP"+IntegerToString(InpMagic)+"_");
      GlobalVariablesDeleteAll("MTMD"+IntegerToString(InpMagic)+"_");
      GlobalVariablesDeleteAll("MTMMAN_");
      g_propHalted=false;
     }

   if(InpPct1+InpPct2+InpPct3+InpPct4>100)
      Print("MTM Sensei EA: aviso - a soma das percentagens de saida excede 100%.");
   if(InpRunnerMode==RUN_LET_RUN)
     {
      if(InpPct1+InpPct2+InpPct3+InpPct4>=100)
         Print("MTM Sensei EA: aviso - modo \"deixar correr\" com saidas a somar 100%: ",
               "nao sobra volume para o runner. Baixa as percentagens.");
      if(InpEaTrailMode==TM_OFF)
         Print("MTM Sensei EA: aviso - modo \"deixar correr\" sem trailing stop: ",
               "o resto da posicao fica so com o SL original.");
     }
   if(InpTPTrailMode!=TM_OFF && !InpSetBrokerTP)
      Print("MTM Sensei EA: aviso - trailing profit precisa de \"Colocar TP final na corretora\" ligado.");

   //--- licenca: valida-se antes de tudo o resto para que a razao apareca no
   //    log mesmo que algo a seguir falhe
   LicInit(InpLicenseKey,InpLicenseUrl);

   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpDeviation);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.LogLevel(LOG_LEVEL_ERRORS);

   //--- arranca o motor do Sensei dentro deste EA
   if(MtmEngineInit()!=INIT_SUCCEEDED)
     {
      Print("MTM Sensei All-in-One: falha a iniciar o motor do indicador");
      return(INIT_FAILED);
     }

   g_atrH=iATR(_Symbol,_Period,InpEaTrailAtrPer);
   if(g_atrH==INVALID_HANDLE) return(INIT_FAILED);

   if(InpExtNews && (InpExtSource==SRC_URL || InpExtSource==SRC_BOTH))
      Print("MTM Sensei: fonte externa por URL - o endereco tem de estar em ",
            "Ferramentas > Opcoes > Consultores > permitir WebRequest: ",InpExtUrl);
   //--- estado do painel arranca dos inputs; a partir dai mandam os botoes
   //--- o input decide o estado INICIAL do interruptor; a partir daqui manda o painel
   g_uiAuto    = InpEnableTrading;
   if(!InpEnableTrading)
      Print("MTM Sensei: execucao DESLIGADA nos parametros (InpEnableTrading=false). ",
            "Liga no botao AUTO do painel, ou nas propriedades do EA.");
   g_uiLotMode = (InpLotMode==LOT_FIXED)?1:0;
   g_uiRisk    = (g_uiLotMode==1)?InpFixedLot:InpRiskPercent;
   g_uiTrailMode = (InpEaTrailMode==TM_ATR)?1:((InpEaTrailMode==TM_POINTS)?2:0);
   g_uiPartial = 25.0;
   g_uiStyle   = (int)InpStyle;
   g_uiLang    = InpPanelEnglish?1:0;
   if(InpPropPanel && MQLInfoInteger(MQL_OPTIMIZATION)==0)
     {
      ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,true);
      PanelBuild();
      ObjectSetString(0,PN"risk",OBJPROP_TEXT,DoubleToString(g_uiRisk,2));
      ObjectSetString(0,PN"part",OBJPROP_TEXT,DoubleToString(g_uiPartial,0));
     }

   UpdInit(InpLicenseUrl,InpLicenseKey,InpOtaCheck,InpOtaDownload);
   AplicarOta();

   PropInit();
   NewsRefresh();

   WatchSymbols();
   VisualAttach();

   MtmFeed();
   g_lastBarTime=iTime(_Symbol,_Period,0);
   Print("MTM Sensei EA iniciado | magic=",InpMagic," | trading=",(InpEnableTrading?"ON":"OFF"));
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   MtmDiagPrint();
   LicDeinit();
   UpdDeinit();
   MtmEngineDeinit();
   if(g_atrH!=INVALID_HANDLE) IndicatorRelease(g_atrH);
   VisualDetach();
   ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,false);
   if(g_uiView>=1) ApplyCleanChart(false);
   DashDestroy();
   DeleteEaPanel();
   PanelDestroy();
   PendingClear();
  }

//====================================================================
//  MODIFICAR SL / TP COM SEGURANCA
//====================================================================
bool SafeModify(const ulong ticket,const int dir,double newSL,double newTP,const bool force=false)
  {
   if(!PositionSelectByTicket(ticket)) return(false);
   double curSL=PositionGetDouble(POSITION_SL);
   double curTP=PositionGetDouble(POSITION_TP);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double minD=MinStopDist();

   if(newSL>0)
     {
      newSL=NormalizeDouble(newSL,g_digits);
      if(dir>0 && newSL>bid-minD) return(false);
      if(dir<0 && newSL<ask+minD) return(false);
      //--- so aperta, nunca alarga (excepto quando forcado a mao)
      if(curSL>0 && !force)
        {
         if(dir>0 && newSL<=curSL) newSL=curSL;
         if(dir<0 && newSL>=curSL) newSL=curSL;
        }
     }
   else newSL=curSL;

   if(newTP>0) newTP=NormalizeDouble(newTP,g_digits); else newTP=curTP;

   if(MathAbs(newSL-curSL)<g_point/2.0 && MathAbs(newTP-curTP)<g_point/2.0) return(false);
   return(trade.PositionModify(ticket,newSL,newTP));
  }


//====================================================================
//  DECLARACOES ANTECIPADAS
//====================================================================
void   CloseAllPositions(const string motivo);
void   DeletePendings();
bool   SafeModify(const ulong ticket,const int dir,double newSL,double newTP,const bool force=false);
void   NewsLoadExternal(string &ccy[]);
bool   ExecuteEntry(const int dir,const double entry,const double slp,
                    const double tp1,const double tp2,const double tp3,const double tp4,
                    const int score);
void   PendingCreate(const int dir,const double entry,const double slp,
                     const double tp1,const double tp2,const double tp3,const double tp4,
                     const int score);
void   PendingRefresh();
void   PendingClear();

//====================================================================
//  FILTRO DE NOTICIAS - calendario economico do MT5
//====================================================================
datetime g_newsTimes[];
string   g_newsNames[];
datetime g_newsLastRefresh=0;
bool     g_newsAvailable=true;
string   g_newsCurrent="";
datetime g_newsNext=0;
string   g_newsNextName="";

bool NewsWanted(const ENUM_CALENDAR_EVENT_IMPORTANCE imp)
  {
   if(InpNewsImportance==NEWS_HIGH)    return(imp==CALENDAR_IMPORTANCE_HIGH);
   if(InpNewsImportance==NEWS_HIGHMED) return(imp==CALENDAR_IMPORTANCE_HIGH || imp==CALENDAR_IMPORTANCE_MODERATE);
   return(imp!=CALENDAR_IMPORTANCE_NONE);
  }

void NewsCurrencyList(string &out[])
  {
   string tmp[];
   int n=0;
   ArrayResize(tmp,0);
   if(InpNewsSymbolCcy)
     {
      string b=SymbolInfoString(_Symbol,SYMBOL_CURRENCY_BASE);
      string q=SymbolInfoString(_Symbol,SYMBOL_CURRENCY_PROFIT);
      if(b!=""){ ArrayResize(tmp,++n); tmp[n-1]=b; }
      if(q!="" && q!=b){ ArrayResize(tmp,++n); tmp[n-1]=q; }
     }
   if(StringLen(InpNewsExtraCcy)>0)
     {
      string parts[];
      int c=StringSplit(InpNewsExtraCcy,',',parts);
      for(int i=0;i<c;i++)
        {
         string v=parts[i];
         StringTrimLeft(v); StringTrimRight(v); StringToUpper(v);
         if(v=="") continue;
         bool dup=false;
         for(int k=0;k<n;k++) if(tmp[k]==v) dup=true;
         if(!dup){ ArrayResize(tmp,++n); tmp[n-1]=v; }
        }
     }
   ArrayResize(out,n);
   for(int i=0;i<n;i++) out[i]=tmp[i];
  }

void NewsRefresh()
  {
   if(!InpUseNews && !InpExtNews) return;
   if(g_newsLastRefresh>0 &&
      (long)(TimeCurrent()-g_newsLastRefresh) < (long)InpNewsRefreshMin*60) return;
   g_newsLastRefresh=TimeCurrent();

   string ccy[];
   NewsCurrencyList(ccy);
   ArrayResize(g_newsTimes,0);
   ArrayResize(g_newsNames,0);
   g_extCount=0;

   //---------------- calendario nativo do MT5 ----------------
   if(InpUseNews && ArraySize(ccy)>0)
     {
      datetime from=TimeCurrent()-(datetime)(24*3600);
      datetime to  =TimeCurrent()+(datetime)(72*3600);
      int total=0;
      for(int c=0;c<ArraySize(ccy);c++)
        {
         MqlCalendarValue vals[];
         int n=CalendarValueHistory(vals,from,to,NULL,ccy[c]);
         if(n<=0) continue;
         for(int i=0;i<n;i++)
           {
            MqlCalendarEvent ev;
            if(!CalendarEventById(vals[i].event_id,ev)) continue;
            if(InpNewsSkipHoliday && ev.type==CALENDAR_TYPE_HOLIDAY) continue;
            if(!NewsWanted(ev.importance)) continue;
            datetime t=vals[i].time+(datetime)(InpNewsShiftMin*60);
            NewsAdd(t,ccy[c]+" "+ev.name);
            total++;
           }
        }
      if(total==0 && g_newsAvailable && !MQLInfoInteger(MQL_TESTER))
        {
         MqlCalendarValue probe[];
         if(CalendarValueHistory(probe,from,to,NULL,NULL)<=0)
           {
            g_newsAvailable=false;
            Print("MTM Sensei: calendario nativo indisponivel",
                  (InpExtNews?" - a usar so a fonte externa.":" - filtro de noticias inativo."));
           }
        }
     }

   //---------------- fonte externa (CSV / URL) ----------------
   NewsLoadExternal(ccy);
  }

//====================================================================
//  NOTICIAS - FONTE EXTERNA (CSV e/ou URL)
//--------------------------------------------------------------------
//  Formato do CSV (";" ou "," como separador, "#" comeca comentario):
//     2026-08-29 14:30 ; USD ; HIGH ; Non-Farm Payrolls
//  Data aceite como "AAAA-MM-DD HH:MM" ou "AAAA.MM.DD HH:MM".
//  Impacto aceite como HIGH/MEDIUM/LOW ou 3/2/1.
//====================================================================
datetime g_extLastFetch=0;
bool     g_extLoaded=false;
int      g_extCount=0;

int ImpactFromText(string v)
  {
   StringToUpper(v);
   StringTrimLeft(v); StringTrimRight(v);
   if(v=="3" || StringFind(v,"HIGH")>=0)   return(3);
   if(v=="2" || StringFind(v,"MED")>=0 || StringFind(v,"MOD")>=0) return(2);
   if(v=="1" || StringFind(v,"LOW")>=0)    return(1);
   return(0);
  }

bool ImpactWanted(const int imp)
  {
   if(InpNewsImportance==NEWS_HIGH)    return(imp>=3);
   if(InpNewsImportance==NEWS_HIGHMED) return(imp>=2);
   return(imp>=1);
  }

bool CurrencyWanted(string ccy,string &list[])
  {
   if(ArraySize(list)==0) return(true);
   StringToUpper(ccy);
   StringTrimLeft(ccy); StringTrimRight(ccy);
   for(int i=0;i<ArraySize(list);i++) if(list[i]==ccy) return(true);
   return(false);
  }

void NewsAdd(const datetime t,const string label)
  {
   int n=ArraySize(g_newsTimes);
   ArrayResize(g_newsTimes,n+1);
   ArrayResize(g_newsNames,n+1);
   g_newsTimes[n]=t;
   g_newsNames[n]=label;
   g_extCount++;
  }

//--- desvio do servidor face a GMT, em segundos
int ServerGmtOffset()
  {
   if(InpExtServerGMT!=999) return(InpExtServerGMT*3600);
   long off=(long)TimeTradeServer()-(long)TimeGMT();
   //--- arredonda a meia hora para limar imprecisoes
   long half=1800;
   return((int)(MathRound((double)off/half)*half));
  }

datetime ParseStamp(string v)
  {
   StringTrimLeft(v); StringTrimRight(v);
   StringReplace(v,"-",".");
   StringReplace(v,"T"," ");
   return(StringToTime(v));
  }

//--- le o CSV; devolve quantos eventos aceitou
int NewsLoadCsv(string &ccy[])
  {
   int flags=FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ;
   if(InpExtCommonFolder) flags|=FILE_COMMON;
   int h=FileOpen(InpExtFile,flags);
   if(h==INVALID_HANDLE) return(-1);

   int added=0;
   while(!FileIsEnding(h))
     {
      string line=FileReadString(h);
      StringTrimLeft(line); StringTrimRight(line);
      if(line=="" || StringGetCharacter(line,0)=='#') continue;
      string f[];
      int n=StringSplit(line,';',f);
      if(n<3) n=StringSplit(line,',',f);
      if(n<3) continue;

      datetime t=ParseStamp(f[0]);
      if(t<=0) continue;
      string c=f[1];
      int imp=ImpactFromText(f[2]);
      string nm=(n>3)?f[3]:"evento";
      if(!ImpactWanted(imp)) continue;
      if(!CurrencyWanted(c,ccy)) continue;
      StringToUpper(c);
      NewsAdd(t,c+" "+nm);
      added++;
     }
   FileClose(h);
   return(added);
  }

//--- extrai o valor de "chave":"valor" a partir de uma posicao
string JsonField(const string js,const int from,const int to,const string key)
  {
   string pat="\""+key+"\"";
   int k=StringFind(js,pat,from);
   if(k<0 || (to>0 && k>to)) return("");
   int c=StringFind(js,":",k+StringLen(pat));
   if(c<0) return("");
   int q1=StringFind(js,"\"",c);
   if(q1<0) return("");
   int q2=StringFind(js,"\"",q1+1);
   if(q2<0) return("");
   return(StringSubstr(js,q1+1,q2-q1-1));
  }

//--- "2026-08-29T08:30:00-04:00" -> hora do servidor
datetime ParseIsoWithOffset(const string iso)
  {
   if(StringLen(iso)<19) return(0);
   string base=StringSubstr(iso,0,19);
   datetime local=ParseStamp(base);
   if(local<=0) return(0);
   //--- procura o offset depois da parte da hora
   string tail=StringSubstr(iso,19);
   int sign=0,oh=0,om=0;
   if(StringLen(tail)>0)
     {
      ushort c0=StringGetCharacter(tail,0);
      if(c0=='+') sign=1; else if(c0=='-') sign=-1;
      if(sign!=0 && StringLen(tail)>=6)
        {
         oh=(int)StringToInteger(StringSubstr(tail,1,2));
         om=(int)StringToInteger(StringSubstr(tail,4,2));
        }
     }
   long utc=(long)local-(long)sign*(oh*3600+om*60);
   return((datetime)(utc+ServerGmtOffset()));
  }

//--- descarrega o JSON e converte; devolve quantos aceitou (-1 = falhou)
int NewsLoadUrl(string &ccy[],string &csvOut)
  {
   csvOut="";
   if(MQLInfoInteger(MQL_TESTER)) return(-1);   // WebRequest nao existe no tester
   char post[],result[];
   string headers="";
   ResetLastError();
   int code=WebRequest("GET",InpExtUrl,NULL,NULL,7000,post,0,result,headers);
   if(code!=200)
     {
      PrintFormat("MTM Sensei: WebRequest falhou (codigo %d, erro %d). "
                  "Confirma Ferramentas > Opcoes > Consultores > permitir WebRequest para %s",
                  code,GetLastError(),InpExtUrl);
      return(-1);
     }
   string js=CharArrayToString(result,0,WHOLE_ARRAY,CP_UTF8);
   int added=0,pos=0;
   while(true)
     {
      int t=StringFind(js,"\"title\"",pos);
      if(t<0) break;
      int nxt=StringFind(js,"\"title\"",t+7);
      int lim=(nxt<0)?StringLen(js):nxt;
      string title=JsonField(js,t,lim,"title");
      string country=JsonField(js,t,lim,"country");
      string date=JsonField(js,t,lim,"date");
      string impact=JsonField(js,t,lim,"impact");
      pos=(nxt<0)?StringLen(js):nxt;
      if(title=="" || date=="") continue;

      datetime tt=ParseIsoWithOffset(date);
      if(tt<=0) continue;
      int imp=ImpactFromText(impact);
      //--- linha normalizada para a cache, sem filtro (o filtro e na leitura)
      csvOut+=TimeToString(tt,TIME_DATE|TIME_MINUTES)+";"+country+";"+
              (imp>=3?"HIGH":(imp==2?"MEDIUM":"LOW"))+";"+title+"\r\n";
      if(!ImpactWanted(imp)) continue;
      if(!CurrencyWanted(country,ccy)) continue;
      string c=country; StringToUpper(c);
      NewsAdd(tt,c+" "+title);
      added++;
     }
   return(added);
  }

void SaveCsvCache(const string body)
  {
   if(!InpExtSaveCache || body=="") return;
   int flags=FILE_WRITE|FILE_TXT|FILE_ANSI;
   if(InpExtCommonFolder) flags|=FILE_COMMON;
   int h=FileOpen(InpExtFile,flags);
   if(h==INVALID_HANDLE)
     { Print("MTM Sensei: nao consegui gravar a cache de noticias ",InpExtFile); return; }
   FileWriteString(h,"# MTM Sensei - cache de noticias  ("+TimeToString(TimeCurrent())+")\r\n");
   FileWriteString(h,"# data;moeda;impacto;evento   (horas ja em hora do servidor)\r\n");
   FileWriteString(h,body);
   FileClose(h);
  }

//--- carrega a fonte externa para os arrays partilhados
void NewsLoadExternal(string &ccy[])
  {
   if(!InpExtNews) return;
   int got=-1;
   string csv="";

   if(InpExtSource==SRC_URL || InpExtSource==SRC_BOTH)
     {
      bool due=(g_extLastFetch==0 ||
                (long)(TimeCurrent()-g_extLastFetch)>=(long)InpExtRefreshMin*60);
      if(due)
        {
         got=NewsLoadUrl(ccy,csv);
         if(got>=0){ g_extLastFetch=TimeCurrent(); SaveCsvCache(csv); }
        }
      else got=-2;   // ainda dentro do intervalo: usa o CSV
     }

   //--- ficheiro: fonte unica, ou sempre que nao houve dados frescos do URL
   if(InpExtSource==SRC_FILE || got<0)
     {
      int f=NewsLoadCsv(ccy);
      if(f<0)
        {
         static bool warned=false;
         if(!warned)
           {
            warned=true;
            PrintFormat("MTM Sensei: ficheiro de noticias \"%s\" nao encontrado em %s",
                        InpExtFile,(InpExtCommonFolder?"Common\\Files":"MQL5\\Files"));
           }
        }
      else got=f;
     }

   if(got>0) g_extLoaded=true;
  }

//--- true se estamos dentro da janela de bloqueio
bool NewsBlocked()
  {
   g_newsCurrent="";
   g_newsNext=0; g_newsNextName="";
   if(!InpUseNews && !InpExtNews) return(false);
   if(ArraySize(g_newsTimes)==0)   return(false);
   datetime now=TimeCurrent();
   bool blocked=false;
   for(int i=0;i<ArraySize(g_newsTimes);i++)
     {
      datetime t=g_newsTimes[i];
      if(now>=t-(datetime)(InpNewsBeforeMin*60) && now<=t+(datetime)(InpNewsAfterMin*60))
        { blocked=true; g_newsCurrent=g_newsNames[i]; }
      if(t>now && (g_newsNext==0 || t<g_newsNext))
        { g_newsNext=t; g_newsNextName=g_newsNames[i]; }
     }
   return(blocked);
  }

//--- accao sobre posicoes abertas quando entra a janela de noticias
void NewsEnforce()
  {
   if((!InpUseNews && !InpExtNews) || InpNewsAction==NEWS_BLOCK_ENTRY) return;
   if(!NewsBlocked()) return;
   if(InpNewsAction==NEWS_FLAT)
     {
      if(CountPositions()>0) CloseAllPositions("janela de noticias: "+g_newsCurrent);
      DeletePendings();
      return;
     }
   //--- NEWS_BE : proteger em breakeven
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      long ptype=PositionGetInteger(POSITION_TYPE);
      int  d=(ptype==POSITION_TYPE_BUY)?1:-1;
      double open=PositionGetDouble(POSITION_PRICE_OPEN);
      SafeModify(tk,d,open+d*InpBeOffsetPoints*g_point,0);
     }
  }

//====================================================================
//  MODULO PROP FIRM
//====================================================================
string   g_ppfx="";
double   g_propInit=0.0;
double   g_propDayStart=0.0;
double   g_propPeak=0.0;
string   g_propReason="";
bool     g_propHalted=false;
string   g_propHaltDay="";   // dia em que travou (a trava diaria expira)

string PropDayKey()
  {
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   return(IntegerToString(d.year*10000+d.mon*100+d.day));
  }

void PropInit()
  {
   g_ppfx="MTMP"+IntegerToString(InpMagic)+"_";
   if(InpPropResetState)
     {
      GlobalVariablesDeleteAll(g_ppfx);
      g_propHalted=false;
      Print("MTM Sensei PROP: estado limpo a pedido - saldo inicial, pico e dia travado reiniciados.");
     }
   string kInit=g_ppfx+"init";
   if(InpPropInitBalance>0.0) g_propInit=InpPropInitBalance;
   else
     {
      if(!GlobalVariableCheck(kInit))
         GlobalVariableSet(kInit,AccountInfoDouble(ACCOUNT_BALANCE));
      g_propInit=GlobalVariableGet(kInit);
     }
   if(g_propInit<=0) g_propInit=AccountInfoDouble(ACCOUNT_BALANCE);

   string kPeak=g_ppfx+"peak";
   if(!GlobalVariableCheck(kPeak)) GlobalVariableSet(kPeak,AccountInfoDouble(ACCOUNT_EQUITY));
   g_propPeak=GlobalVariableGet(kPeak);
  }

void PropRefresh()
  {
   if(!InpPropEnable) return;
   //--- a trava e DIARIA: no dia seguinte volta a operar, desde que o
   //    drawdown TOTAL nao esteja em incumprimento (esse sim e definitivo)
   if(g_propHalted && g_propHaltDay!="" && g_propHaltDay!=PropDayKey())
     {
      double tLim=PropTotalLimit();
      if(!(tLim<0 && PropTotalPL()<=tLim))
        {
         g_propHalted=false; g_propHaltDay="";
         Print("MTM Sensei PROP: novo dia - trava diaria levantada.");
        }
     }
   double eq=AccountInfoDouble(ACCOUNT_EQUITY);
   //--- pico de equity (drawdown trailing)
   if(eq>g_propPeak){ g_propPeak=eq; GlobalVariableSet(g_ppfx+"peak",eq); }
   //--- saldo de arranque do dia
   string kDay=g_ppfx+"d"+PropDayKey();
   if(!GlobalVariableCheck(kDay))
      GlobalVariableSet(kDay,(InpPropDayBase==DAYB_EQUITY)?AccountInfoDouble(ACCOUNT_EQUITY)
                                                          :AccountInfoDouble(ACCOUNT_BALANCE));
   g_propDayStart=GlobalVariableGet(kDay);
   if(g_propDayStart<=0) g_propDayStart=AccountInfoDouble(ACCOUNT_BALANCE);
  }

//--- tudo calculado em DINHEIRO; os limites sao convertidos conforme a unidade
double PropDailyPL()  { return(AccountInfoDouble(ACCOUNT_EQUITY)-g_propDayStart); }
double PropDDBase()   { return((InpPropDDBase==DD_TRAILING)?g_propPeak:g_propInit); }
double PropTotalPL()  { return(AccountInfoDouble(ACCOUNT_EQUITY)-PropDDBase()); }
double PropTargetPL() { return(AccountInfoDouble(ACCOUNT_EQUITY)-g_propInit); }

double PropDailyPct() { return(g_propDayStart>0 ? PropDailyPL()/g_propDayStart*100.0 : 0.0); }
double PropTotalPct() { double b=PropDDBase(); return(b>0 ? PropTotalPL()/b*100.0 : 0.0); }
double PropTargetPct(){ return(g_propInit>0 ? PropTargetPL()/g_propInit*100.0 : 0.0); }

//--- limites ja com a margem de seguranca aplicada, sempre em dinheiro e negativos
double PropSafety()   { return(MathMax(0.0,MathMin(100.0,InpPropSafetyPct))/100.0); }

double PropDailyLimit()
  {
   if(InpPropIgnoreDD) return(0.0);
   double lim=(InpPropUnit==DDU_MONEY)? InpPropDailyLossMny
                                      : g_propDayStart*InpPropDailyLossPct/100.0;
   if(lim<=0) return(0.0);
   return(-lim*PropSafety());
  }
double PropTotalLimit()
  {
   if(InpPropIgnoreDD) return(0.0);
   double lim=(InpPropUnit==DDU_MONEY)? InpPropMaxDDMny
                                      : PropDDBase()*InpPropMaxDDPct/100.0;
   if(lim<=0) return(0.0);
   return(-lim*PropSafety());
  }
double PropTargetLimit()
  {
   return((InpPropUnit==DDU_MONEY)? InpPropTargetMny
                                  : g_propInit*InpPropTargetPct/100.0);
  }

//--- texto para o painel, na unidade escolhida
string PropFmt(const double money,const double pct)
  {
   if(InpPropUnit==DDU_MONEY) return(StringFormat("%+.0f",money));
   return(StringFormat("%+.2f%%",pct));
  }
string PropFmtLim(const double money,const double pct)
  {
   if(InpPropUnit==DDU_MONEY) return(StringFormat("%.0f",money));
   return(StringFormat("%.1f%%",pct));
  }

int PropTradesToday()
  {
   string k=g_ppfx+"n"+PropDayKey();
   return(GlobalVariableCheck(k) ? (int)GlobalVariableGet(k) : 0);
  }
void PropCountTrade()
  {
   string k=g_ppfx+"n"+PropDayKey();
   GlobalVariableSet(k,(double)(PropTradesToday()+1));
  }

double PropTotalLots()
  {
   double v=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      v+=PositionGetDouble(POSITION_VOLUME);
     }
   return(v);
  }

//--- limites "duros" atingidos -> fecha e trava o dia
void PropEnforce()
  {
   if(!InpPropEnable) return;
   PropRefresh();

   double dLim=PropDailyLimit();
   double tLim=PropTotalLimit();
   bool breach=false;
   string why="";

   if(dLim<0 && PropDailyPL()<=dLim)
      { breach=true; why=StringFormat("perda diaria %.2f (limite util %.2f)",PropDailyPL(),dLim); }
   if(tLim<0 && PropTotalPL()<=tLim)
      { breach=true; why=StringFormat("drawdown total %.2f (limite util %.2f)",PropTotalPL(),tLim); }

   if(breach)
     {
      if(!g_propHalted)
        {
         g_propHalted=true; g_propHaltDay=PropDayKey();
         PrintFormat("MTM Sensei PROP: LIMITE ATINGIDO - %s. Execucao travada ate ao proximo dia.",why);
         if(InpPropCloseBreach){ CloseAllPositions("limite de prop firm"); DeletePendings(); }
        }
      GlobalVariableSet(g_ppfx+"h"+PropDayKey(),1.0);
     }

   double tgt=PropTargetLimit();
   if(InpPropStopOnTarget && tgt>0 && PropTargetPL()>=tgt && !g_propHalted)
     {
      g_propHalted=true; g_propHaltDay=PropDayKey();
      PrintFormat("MTM Sensei PROP: ALVO ATINGIDO (%.2f). Execucao parada.",PropTargetPL());
     }

   if(InpPropFlatWeekend)
     {
      MqlDateTime d; TimeToStruct(TimeCurrent(),d);
      if(d.day_of_week==5 && d.hour>=InpFridayHour)
        { CloseAllPositions("flat de fim de semana (prop firm)"); DeletePendings(); }
     }
  }

bool PropCanTrade()
  {
   g_propReason="";
   if(!InpPropEnable) return(true);
   if(!InpPropIgnoreDD)
     {
      if(GlobalVariableCheck(g_ppfx+"h"+PropDayKey())){ g_propReason="dia travado (limite de DD atingido)"; return(false); }
      if(g_propHalted){ g_propReason="travado"; return(false); }
     }

   double dLim=PropDailyLimit();
   double tLim=PropTotalLimit();
   double tgt =PropTargetLimit();
   if(dLim<0 && PropDailyPL()<=dLim){ g_propReason="perda diaria"; return(false); }
   if(tLim<0 && PropTotalPL()<=tLim){ g_propReason="drawdown total"; return(false); }
   if(InpPropStopOnTarget && tgt>0 && PropTargetPL()>=tgt){ g_propReason="alvo atingido"; return(false); }
   if(InpPropMaxTrades>0 && PropTradesToday()>=InpPropMaxTrades){ g_propReason="trades do dia"; return(false); }
   if(InpPropMaxTotalLot>0 && PropTotalLots()>=InpPropMaxTotalLot){ g_propReason="exposicao maxima"; return(false); }
   if(InpPropFlatWeekend)
     {
      MqlDateTime d; TimeToStruct(TimeCurrent(),d);
      if(d.day_of_week==5 && d.hour>=InpFridayHour){ g_propReason="fim de semana"; return(false); }
     }
   return(true);
  }

//--- teto de risco por trade imposto pela prop firm
double PropRiskCapPct(const double wanted)
  {
   if(!InpPropEnable || InpPropMaxRiskPct<=0) return(wanted);
   return(MathMin(wanted,InpPropMaxRiskPct));
  }

//--- teto absoluto do risco por trade, em dinheiro
double PropRiskCapMoney(const double wanted,const double base)
  {
   double v=wanted;
   if(InpPropEnable && InpPropMaxRiskMny>0) v=MathMin(v,InpPropMaxRiskMny);
   if(InpPropEnable && InpPropMaxRiskPct>0 && base>0)
      v=MathMin(v,base*InpPropMaxRiskPct/100.0);
   return(v);
  }

//====================================================================
//  PAINEL DE RISCO DO EA
//====================================================================
void EaPanelRow(const string nm,const int y,const string txt,const color clr)
  {
   if(ObjectFind(0,nm)<0)
     {
      ObjectCreate(0,nm,OBJ_LABEL,0,0,0);
      ObjectSetInteger(0,nm,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,nm,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
      ObjectSetString (0,nm,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,8);
      ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,10);
     }
   ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,nm,OBJPROP_COLOR,clr);
   ObjectSetString (0,nm,OBJPROP_TEXT,txt);
  }

void DrawEaPanel()
  {
   if(!InpPropPanel || MQLInfoInteger(MQL_OPTIMIZATION)!=0) return;
   string p="MTMEA_";
   string bg=p+"bg";
   int rows=7, row=15, h=rows*row+12;
   if(ObjectFind(0,bg)<0)
     {
      ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);
      ObjectSetInteger(0,bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,6);
      ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,16);
      ObjectSetInteger(0,bg,OBJPROP_XSIZE,300);
      ObjectSetInteger(0,bg,OBJPROP_YSIZE,h);
      ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,C'18,18,30');
      ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);
      ObjectSetInteger(0,bg,OBJPROP_COLOR,C'124,58,237');
      ObjectSetInteger(0,bg,OBJPROP_BACK,false);
      ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,bg,OBJPROP_HIDDEN,true);
     }
   int y=22;
   bool news=NewsBlocked();
   //--- o botao AutoTrading do terminal e a permissao do proprio EA mandam em tudo:
   //    sem isto o painel dizia "A OPERAR" com o algo trading desligado
   bool algo=(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)!=0) &&
             (MQLInfoInteger(MQL_TRADE_ALLOWED)!=0);
   bool eod =EndOfDayReached();
   bool can =PropCanTrade() && !news && InpEnableTrading && algo && !eod;

   //--- avisar no log sempre que o estado muda (senao parece que "morreu" sem razao)
   static int lastCan=-1;
   if((int)can!=lastCan)
     {
      lastCan=(int)can;
      if(can) Print("MTM Sensei: execucao RETOMADA");
      else
        {
         string why = (!algo) ? "AutoTrading desligado (botao do terminal ou permissao do EA)"
                    : (eod ? "fim do dia" : "")
                    ;
         if(why=="") why = (!InpEnableTrading) ? "execucao desligada nos inputs"
                    : (news ? ("noticias: "+g_newsCurrent)
                    : (g_propReason!="" ? g_propReason : "filtro de horario/spread"));
         Print("MTM Sensei: execucao PARADA - ",why,
               (StringFind(why,"dia travado")>=0
                ? "  |  para destravar liga InpPropResetState ou InpPropIgnoreDD" : ""));
        }
     }
   EaPanelRow(p+"0",y,           StringFormat("%-16s%14s","MTM SENSEI EA",(can?"A OPERAR":"PARADO")),
              can?C'74,222,128':C'248,113,113');
   y+=15;
   if(InpPropEnable)
     {
      double dm=PropDailyPL(), tm=PropTotalPL(), gm=PropTargetPL();
      EaPanelRow(p+"1",y,StringFormat("%-16s%13s","P/L do dia",
                 PropFmt(dm,PropDailyPct())+" / "+
                 PropFmtLim(InpPropDailyLossMny,InpPropDailyLossPct)),
                 dm<0?C'248,113,113':C'74,222,128'); y+=15;
      EaPanelRow(p+"2",y,StringFormat("%-16s%13s",
                 (InpPropDDBase==DD_TRAILING?"DD trailing":"DD total"),
                 PropFmt(tm,PropTotalPct())+" / "+
                 PropFmtLim(InpPropMaxDDMny,InpPropMaxDDPct)),
                 tm<0?C'248,113,113':C'74,222,128'); y+=15;
      EaPanelRow(p+"3",y,StringFormat("%-16s%13s","Alvo",
                 PropFmt(gm,PropTargetPct())+" / "+
                 PropFmtLim(InpPropTargetMny,InpPropTargetPct)),
                 C'245,158,11'); y+=15;
      EaPanelRow(p+"4",y,StringFormat("%-16s%13s","Trades hoje",
                 StringFormat("%d%s",PropTradesToday(),
                 (InpPropMaxTrades>0?" / "+IntegerToString(InpPropMaxTrades):""))),
                 clrSilver); y+=15;
     }
   else { EaPanelRow(p+"1",y,StringFormat("%-16s%13s","Prop firm","desligado"),clrGray); y+=15; }

   int nEv=ArraySize(g_newsTimes);
   string src = (InpUseNews && g_newsAvailable && InpExtNews) ? "MT5+ext"
              : (InpExtNews ? (g_extLoaded?"ext":"ext?")
              : (g_newsAvailable ? "MT5" : "--"));
   string nl = (!InpUseNews && !InpExtNews) ? "filtro off"
             : (nEv==0 ? "sem eventos ("+src+")"
             : (news ? "BLOQUEADO" : TimeToString(g_newsNext,TIME_MINUTES)+" ("+src+")"));
   EaPanelRow(p+"5",y,StringFormat("%-16s%13s","Noticias",nl),
              news?C'248,113,113':clrSilver); y+=15;
   string det = news ? g_newsCurrent : (g_newsNext>0?g_newsNextName:g_propReason);
   if(StringLen(det)>34) det=StringSubstr(det,0,34);
   EaPanelRow(p+"6",y,det,clrGray);
  }

void DeleteEaPanel()
  {
   ObjectsDeleteAll(0,"MTMEA_");
  }

//====================================================================
//  ADOPCAO DE POSICOES ORFAS (estado perdido)
//====================================================================
bool AdoptPosition(const ulong ticket)
  {
   if(!PositionSelectByTicket(ticket)) return(false);
   double entry=PositionGetDouble(POSITION_PRICE_OPEN);
   double slp  =PositionGetDouble(POSITION_SL);
   double vol  =PositionGetDouble(POSITION_VOLUME);
   long   ptype=PositionGetInteger(POSITION_TYPE);
   int    d=(ptype==POSITION_TYPE_BUY)?1:-1;
   if(entry<=0 || slp<=0) return(false);
   double dist=MathAbs(entry-slp);
   if(dist<=0) return(false);
   //--- reconstroi os Exits pelos multiplos R configurados
   double rr[4]; rr[0]=InpTP1RR; rr[1]=InpTP2RR; rr[2]=InpTP3RR; rr[3]=InpTP4RR;
   ArraySort(rr);
   double t1=entry+d*dist*rr[0];
   double t2=entry+d*dist*rr[1];
   double t3=entry+d*dist*rr[2];
   double t4=entry+d*dist*rr[3];
   StateSave(ticket,entry,slp,t1,t2,t3,t4,vol,d,0);
   PrintFormat("MTM Sensei: posicao %I64u adoptada (estado reconstruido a partir do SL atual)",ticket);
   return(true);
  }

//====================================================================
//  GESTAO DAS POSICOES ABERTAS (parciais + BE + trailing)
//====================================================================
void ManagePositions()
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong ticket=PositionGetTicket(i);
      if(ticket==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;

      double entry,sl0,t1,t2,t3,t4,vol0;
      int dir,flags;
      if(!StateLoad(ticket,entry,sl0,t1,t2,t3,t4,vol0,dir,flags))
        {
         if(!InpAdoptOrphans) continue;
         //--- estado perdido (crash / reinstalacao): reconstroi pelos dados da posicao
         if(!AdoptPosition(ticket)) continue;
         if(!StateLoad(ticket,entry,sl0,t1,t2,t3,t4,vol0,dir,flags)) continue;
        }

      long ptype=PositionGetInteger(POSITION_TYPE);
      int  d=(ptype==POSITION_TYPE_BUY)?1:-1;
      double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
      double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double px =(d>0)?bid:ask;

      //---------------- niveis movidos a mao no grafico ----------------
      if(InpUseManualLines)
        {
         double mSL=MtmManualGet(_Symbol,g_tfsec,"SL");
         if(mSL>0)
           {
            double curSL=PositionGetDouble(POSITION_SL);
            if(MathAbs(mSL-curSL)>g_point)
               if(SafeModify(ticket,d,mSL,0,true))
                  PrintFormat("MTM Sensei: SL manual aplicado em %s (pos %I64u)",
                              DoubleToString(mSL,g_digits),ticket);
           }
         double mv[4];
         mv[0]=MtmManualGet(_Symbol,g_tfsec,"TP1"); mv[1]=MtmManualGet(_Symbol,g_tfsec,"TP2");
         mv[2]=MtmManualGet(_Symbol,g_tfsec,"TP3"); mv[3]=MtmManualGet(_Symbol,g_tfsec,"TP4");
         string kk[4]; kk[0]="1"; kk[1]="2"; kk[2]="3"; kk[3]="4";
         double cur[4]; cur[0]=t1; cur[1]=t2; cur[2]=t3; cur[3]=t4;
         for(int m=0;m<4;m++)
            if(mv[m]>0 && MathAbs(mv[m]-cur[m])>g_point)
              {
               GlobalVariableSet(GVN(ticket,kk[m]),mv[m]);
               PrintFormat("MTM Sensei: Exit %d manual -> %s",m+1,DoubleToString(mv[m],g_digits));
               if(m==0) t1=mv[0]; else if(m==1) t2=mv[1];
               else if(m==2) t3=mv[2]; else t4=mv[3];
              }
        }

      //---------------- saidas parciais ----------------
      double tps[4]; tps[0]=t1; tps[1]=t2; tps[2]=t3; tps[3]=t4;
      bool   use[4]; use[0]=InpUseTP1; use[1]=InpUseTP2; use[2]=InpUseTP3; use[3]=InpUseTP4;
      int    pct[4]; pct[0]=InpPct1; pct[1]=InpPct2; pct[2]=InpPct3; pct[3]=InpPct4;
      int    bit[4]; bit[0]=F_TP1;  bit[1]=F_TP2;  bit[2]=F_TP3;  bit[3]=F_TP4;
      int    lastTP=LastActiveTP();
      bool   closedAll=false;

      for(int k=0;k<4;k++)
        {
         if(!use[k] || tps[k]<=0) continue;
         if((flags&bit[k])!=0)    continue;
         bool hit=(d>0)?(px>=tps[k]):(px<=tps[k]);
         if(!hit) continue;

         if(!PositionSelectByTicket(ticket)){ closedAll=true; break; }
         double curVol=PositionGetDouble(POSITION_VOLUME);

         if(k+1==lastTP && InpRunnerMode==RUN_CLOSE_LAST)
           {
            if(trade.PositionClose(ticket,InpDeviation))
              {
               flags|=bit[k]; StateFlags(ticket,flags);
               PrintFormat("MTM Sensei: Exit %d atingido - posicao %I64u fechada por completo",k+1,ticket);
              }
            closedAll=true;
            break;
           }

         double closeVol=NormLot(vol0*pct[k]/100.0);
         if(closeVol<g_lotMin)
           {
            //--- lote demasiado pequeno para fechar parcialmente: marca e segue
            flags|=bit[k]; StateFlags(ticket,flags);
            continue;
           }
         if(curVol-closeVol<g_lotMin-0.0000001) closeVol=curVol;

         bool ok;
         if(closeVol>=curVol-0.0000001) { ok=trade.PositionClose(ticket,InpDeviation); closedAll=ok; }
         else                             ok=trade.PositionClosePartial(ticket,closeVol,InpDeviation);

         if(ok)
           {
            flags|=bit[k]; StateFlags(ticket,flags);
            PrintFormat("MTM Sensei: Exit %d @ %s - fechado %.2f de %.2f (pos %I64u)",
                        k+1,DoubleToString(tps[k],g_digits),closeVol,vol0,ticket);
           }
         else
            PrintFormat("MTM Sensei: falha no Exit %d (pos %I64u) erro %d",k+1,ticket,trade.ResultRetcode());

         if(closedAll) break;
        }

      if(closedAll){ StateDel(ticket); continue; }
      if(!PositionSelectByTicket(ticket)){ StateDel(ticket); continue; }

      //---------------- breakeven ----------------
      if((flags&F_BE)==0)
        {
         double beTarget=0.0;
         switch(InpEaBeMode)
           {
            case BE_EXIT1: beTarget=t1; break;
            case BE_EXIT2: beTarget=t2; break;
            case BE_EXIT3: beTarget=t3; break;
            default:       beTarget=entry+d*InpEaBePoints*g_point; break;
           }
         if(beTarget>0)
           {
            bool hit=(d>0)?(px>=beTarget):(px<=beTarget);
            if(hit)
              {
               double newSL=entry+d*InpBeOffsetPoints*g_point;
               if(SafeModify(ticket,d,newSL,0))
                 {
                  flags|=F_BE; StateFlags(ticket,flags);
                  PrintFormat("MTM Sensei: breakeven aplicado na posicao %I64u (SL %s)",
                              ticket,DoubleToString(newSL,g_digits));
                 }
               else
                 { flags|=F_BE; StateFlags(ticket,flags); }
              }
           }
        }

      //---------------- trailing stop ----------------
      double atrv=0.0;
      if(g_uiTrailMode==1 || InpTPTrailMode==TM_ATR)
        {
         double atr[];
         if(CopyBuffer(g_atrH,0,0,1,atr)==1) atrv=atr[0];
        }
      double openP=PositionGetDouble(POSITION_PRICE_OPEN);
      double profitPts=((d>0)?(bid-openP):(openP-ask))/g_point;

      if(g_uiTrailMode!=0)
        {
         bool allowed=false;
         if(InpTrailStart==TS_IMMEDIATE)                           allowed=true;
         else if(InpTrailStart==TS_AFTER_TP1 && (flags&F_TP1)!=0)  allowed=true;
         else if(InpTrailStart==TS_AFTER_TP2 && (flags&F_TP2)!=0)  allowed=true;
         if(allowed && InpTrailStartPts>0 && profitPts<InpTrailStartPts) allowed=false;

         if(allowed)
           {
            double dist=(g_uiTrailMode==1)? atrv*InpEaTrailMult
                                          : InpEaTrailPoints*g_point;
            if(dist>0)
              {
               double cand=(d>0)? bid-dist : ask+dist;
               double curSL=PositionGetDouble(POSITION_SL);
               //--- passo minimo: em pontos, ou 10% da distancia quando fica a 0
               //    (assim funciona em qualquer simbolo sem saber as casas decimais)
               double stepMin=(InpTrailStepPts>0)? InpTrailStepPts*g_point : dist*0.10;
               bool worth = (curSL<=0) ||
                            ((d>0) ? (cand-curSL >= stepMin)
                                   : (curSL-cand >= stepMin));
               if(worth) SafeModify(ticket,d,cand,0);
              }
           }
        }

      //---------------- trailing profit (empurra o TP para deixar correr) ----------------
      if(InpTPTrailMode!=TM_OFF)
        {
         double curTP=PositionGetDouble(POSITION_TP);
         if(curTP>0)
           {
            double trig=(InpTPTrailMode==TM_ATR)? atrv*InpTPTrailMult
                                                : InpTPTrailTrigPts*g_point;
            double step=(InpTPTrailMode==TM_ATR)? atrv*InpTPTrailMult
                                                : InpTPTrailStepPts*g_point;
            double gap=(d>0)? (curTP-bid) : (ask-curTP);
            if(trig>0 && step>0 && gap<=trig)
              {
               double newTP=curTP+d*step;
               bool ok=true;
               //--- teto opcional em multiplos de R
               if(InpTPTrailMaxR>0)
                 {
                  double riskD=MathAbs(entry-sl0);
                  if(riskD>0)
                    {
                     double maxTP=entry+d*riskD*InpTPTrailMaxR;
                     if((d>0 && newTP>maxTP)||(d<0 && newTP<maxTP)){ newTP=maxTP; ok=(MathAbs(newTP-curTP)>g_point); }
                    }
                 }
               if(ok && SafeModify(ticket,d,0,newTP,true))
                  PrintFormat("MTM Sensei: trailing profit -> TP %s (pos %I64u)",
                              DoubleToString(newTP,g_digits),ticket);
              }
           }
        }
     }
  }

//====================================================================
//  FECHO POR SINAL CONTRARIO / SEXTA-FEIRA
//====================================================================
void CloseAllPositions(const string motivo)
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      if(trade.PositionClose(tk,InpDeviation))
        {
         StateDel(tk);
         PrintFormat("MTM Sensei: posicao %I64u fechada (%s)",tk,motivo);
        }
     }
  }

void CloseOpposite(const int dir)
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      long ptype=PositionGetInteger(POSITION_TYPE);
      int  pd=(ptype==POSITION_TYPE_BUY)?1:-1;
      if(pd==dir) continue;
      if(trade.PositionClose(tk,InpDeviation))
        {
         StateDel(tk);
         PrintFormat("MTM Sensei: posicao %I64u fechada por sinal contrario",tk);
        }
     }
  }

void DeletePendings()
  {
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong tk=OrderGetTicket(i);
      if(tk==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=_Symbol) continue;
      if(OrderGetInteger(ORDER_MAGIC)!=InpMagic) continue;
      datetime exp=(datetime)OrderGetInteger(ORDER_TIME_EXPIRATION);
      if(exp>0 && TimeCurrent()<exp) continue;
      if(exp==0)
        {
         datetime setup=(datetime)OrderGetInteger(ORDER_TIME_SETUP);
         long alive=(long)(TimeCurrent()-setup);
         if(alive < (long)PeriodSeconds(_Period)*InpLimitExpiryBars) continue;
        }
      if(trade.OrderDelete(tk)) StateDel(tk);
     }
  }

//====================================================================
//  ENTRADA
//====================================================================
void CheckForEntry()
  {
   //--- o sinal e lido ANTES das guardas, para que uma rejeicao seja sempre
   //    visivel no log. Rejeitar em silencio custou-nos dias de diagnostico.
   int shift=InpConfirmClose?1:0;
   int n=ArraySize(BufSignal);
   int ix=n-1-shift;
   if(ix<0) return;
   if(BufSignal[ix]==0.0) return;

   datetime bt=iTime(_Symbol,_Period,shift);
   if(bt==g_lastSignalBar) return;
   g_lastSignalBar=bt;

   int    dir  =(BufSignal[ix]>0)?1:-1;
   double entry=BufEntry[ix], slp=BufSL[ix];
   double tp1=BufTP1[ix],tp2=BufTP2[ix],tp3=BufTP3[ix],tp4=BufTP4[ix];
   int    score=(int)MathRound(BufScore[ix]);
   if(entry<=0 || slp<=0) return;

   //--- guardas, cada uma com o seu motivo no log
   string bloq="";
   if(!g_licOk)                                    bloq="licenca: "+g_licMsg;
   else if(!g_uiAuto)                              bloq="automatico desligado";
   else if(EndOfDayReached())                      bloq="passou a hora de fim de dia";
   else if(!EaSessionOK())                         bloq="fora do horario do EA";
   else if(!DailyLossOK())                         bloq="guarda de perda diaria";
   else if(!SpreadOK())
      bloq=StringFormat("spread %d pontos > limite %d (poe InpMaxSpreadPoints=0 para desligar)",
                        (int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD),InpMaxSpreadPoints);
   else if(!PropCanTrade())                        bloq="prop firm: "+g_propReason;
   else if(NewsBlocked())                          bloq="noticias: "+g_newsCurrent;
   else if(InpMinScoreToTrade>0 && score<InpMinScoreToTrade)
      bloq=StringFormat("score %d abaixo do minimo %d",score,InpMinScoreToTrade);

   if(bloq!="")
     {
      PrintFormat("MTM Sensei: SINAL %s %s @ %s IGNORADO - %s",
                  (dir>0?"BUY":"SELL"),_Symbol,DoubleToString(entry,g_digits),bloq);
      return;
     }

   if(InpSignalAlert)
     {
      string msg=StringFormat("MTM Sensei %s %s @ %s | SL %s | score %d/20",
                              (dir>0?"BUY":"SELL"),_Symbol,
                              DoubleToString(entry,g_digits),
                              DoubleToString(slp,g_digits),score);
      Print(msg);
      if(InpEntryMode!=ENT_AUTO){ Alert(msg); SendNotification(msg); }
     }

   if(InpEntryMode==ENT_MANUAL) return;               // so avisa
   if(InpEntryMode==ENT_CONFIRM){ PendingCreate(dir,entry,slp,tp1,tp2,tp3,tp4,score); return; }

   ExecuteEntry(dir,entry,slp,tp1,tp2,tp3,tp4,score);
  }

//====================================================================
//  EXECUCAO DE UMA ENTRADA (usada pelo modo auto e pela confirmacao)
//====================================================================
bool ExecuteEntry(const int dir,const double entry,const double slp,
                  const double tp1,const double tp2,const double tp3,const double tp4,
                  const int score)
  {
   //--- Ultima porta antes de qualquer ordem. Os botoes do painel tambem passam
   //    por aqui, logo a licenca cobre a entrada manual e a automatica.
   //
   //    TODAS as recusas escrevem a razao. A versao anterior tinha quatro que
   //    devolviam false caladas — e o resultado era um EA com "AUTO: ON" no ecra,
   //    o botao COMPRAR a nao fazer nada, e nem uma linha no log a dizer porque.
   //    Ja tinha corrigido isto no CheckForEntry e deixei ficar aqui, que e
   //    precisamente por onde passam os botoes.
   //
   //    E o interruptor lido aqui e o do PAINEL (g_uiAuto), nao o input. O input
   //    so decide o estado INICIAL (ver OnInit). Enquanto isto lia
   //    InpEnableTrading, carregar em AUTO punha "ON" no ecra e nao mudava nada:
   //    o painel mentia, e a entrada manual — que forca g_uiAuto para poder
   //    correr com o automatico desligado — nao tinha efeito nenhum.
   string bloqueio="";
   if(!g_licOk)                                    bloqueio="licenca: "+g_licMsg;
   else if(!g_uiAuto)                              bloqueio="execucao desligada (botao AUTO do painel)";
   else if(EndOfDayReached())                      bloqueio="passou a hora de fim de dia";
   else if(!PropCanTrade())                        bloqueio="prop firm: "+g_propReason;
   else if(!SpreadOK())
      bloqueio=StringFormat("spread %d pontos acima do limite %d (poe InpMaxSpreadPoints=0 para desligar)",
                            (int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD),InpMaxSpreadPoints);

   if(bloqueio!="")
     {
      PrintFormat("MTM Sensei: ORDEM %s NAO ABERTA - %s",(dir>0?"BUY":"SELL"),bloqueio);
      return(false);
     }

   if(InpUseManualLines) MtmManualClear(_Symbol,g_tfsec);
   if(InpCloseOnOpposite) CloseOpposite(dir);
   if(CountPositions()+CountPendings()>=g_maxPos)
     {
      PrintFormat("MTM Sensei: ORDEM %s NAO ABERTA - ja estao %d posicoes/ordens abertas (limite %d)",
                  (dir>0?"BUY":"SELL"),CountPositions()+CountPendings(),g_maxPos);
      return(false);
     }

   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double now=(dir>0)?ask:bid;

   if(InpMaxEntryDrift>0 && MathAbs(now-entry)/g_point>InpMaxEntryDrift)
     {
      PrintFormat("MTM Sensei: entrada abortada - desvio de %.0f pontos face ao sinal",
                  MathAbs(now-entry)/g_point);
      return(false);
     }
   if(InpSkipIfPassed)
     {
      if(dir>0 && (now<=slp || now>=tp1)){ Print("MTM Sensei: entrada abortada - preco fora da zona util"); return(false); }
      if(dir<0 && (now>=slp || now<=tp1)){ Print("MTM Sensei: entrada abortada - preco fora da zona util"); return(false); }
     }

   double lot=CalcLot(entry,slp);
   if(lot<=0.0){ Print("MTM Sensei: lote calculado invalido - entrada ignorada"); return(false); }

   int    lastTP=LastActiveTP();
   double brokerTP=0.0;
   bool   wantBrokerTP = InpSetBrokerTP &&
                         !(InpRunnerMode==RUN_LET_RUN && InpTPTrailMode==TM_OFF);
   if(wantBrokerTP)
     {
      if(lastTP==4) brokerTP=tp4; else if(lastTP==3) brokerTP=tp3;
      else if(lastTP==2) brokerTP=tp2; else if(lastTP==1) brokerTP=tp1;
     }

   double slN=NormalizeDouble(slp,g_digits);
   double tpN=(brokerTP>0)?NormalizeDouble(brokerTP,g_digits):0.0;

   trade.SetDeviationInPoints(InpDeviation);
   bool ok=false;
   if(InpOrderType==MTM_ORDER_MARKET)
      ok=(dir>0)? trade.Buy (lot,_Symbol,0.0,slN,tpN,InpComment)
                : trade.Sell(lot,_Symbol,0.0,slN,tpN,InpComment);
   else
     {
      datetime expTime=(datetime)(TimeCurrent()+PeriodSeconds(_Period)*InpLimitExpiryBars);
      long expMode=SymbolInfoInteger(_Symbol,SYMBOL_EXPIRATION_MODE);
      ENUM_ORDER_TYPE_TIME tt=ORDER_TIME_GTC;
      datetime te=0;
      if((expMode & SYMBOL_EXPIRATION_SPECIFIED)!=0){ tt=ORDER_TIME_SPECIFIED; te=expTime; }
      double pr=NormalizeDouble(entry,g_digits);
      ok=(dir>0)? trade.BuyLimit (lot,pr,_Symbol,slN,tpN,tt,te,InpComment)
                : trade.SellLimit(lot,pr,_Symbol,slN,tpN,tt,te,InpComment);
     }

   if(!ok)
     {
      PrintFormat("MTM Sensei: falha ao abrir %s - retcode %d (%s)",
                  (dir>0?"BUY":"SELL"),trade.ResultRetcode(),trade.ResultRetcodeDescription());
      return(false);
     }

   PropCountTrade();
   ulong tk=trade.ResultOrder();
   if(tk==0) tk=trade.ResultDeal();
   StateSave(tk,entry,slp,tp1,tp2,tp3,tp4,lot,dir,0);
   PrintFormat("MTM Sensei: %s %s %.2f lot | entry %s | SL %s (%.0f pts) | E1 %s E2 %s E3 %s E4 %s | score %d/20 | ticket %I64u",
               (dir>0?"BUY":"SELL"),_Symbol,lot,
               DoubleToString(entry,g_digits),DoubleToString(slp,g_digits),
               MathAbs(entry-slp)/g_point,
               DoubleToString(tp1,g_digits),DoubleToString(tp2,g_digits),
               DoubleToString(tp3,g_digits),DoubleToString(tp4,g_digits),score,tk);
   return(true);
  }

//====================================================================
//  CONFIRMACAO NO GRAFICO (botoes)
//====================================================================
void ConfirmButton(const string nm,const int x,const int y,const int w,
                   const string txt,const color bg)
  {
   if(ObjectFind(0,nm)<0)
     {
      ObjectCreate(0,nm,OBJ_BUTTON,0,0,0);
      ObjectSetInteger(0,nm,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,nm,OBJPROP_XSIZE,w);
      ObjectSetInteger(0,nm,OBJPROP_YSIZE,26);
      ObjectSetInteger(0,nm,OBJPROP_COLOR,clrWhite);
      ObjectSetInteger(0,nm,OBJPROP_BORDER_COLOR,clrWhite);
      ObjectSetString (0,nm,OBJPROP_FONT,"Arial Bold");
      ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,9);
      ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
     }
   ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,nm,OBJPROP_BGCOLOR,bg);
   ObjectSetInteger(0,nm,OBJPROP_STATE,false);
   ObjectSetString (0,nm,OBJPROP_TEXT,txt);
  }

void PendingClear()
  {
   g_pendActive=false;
   ObjectDelete(0,"MTMBTN_GO");
   ObjectDelete(0,"MTMBTN_NO");
   ChartRedraw();
  }

void PendingCreate(const int dir,const double entry,const double slp,
                   const double tp1,const double tp2,const double tp3,const double tp4,
                   const int score)
  {
   g_pendActive=true; g_pendDir=dir; g_pendScore=score;
   g_pendEntry=entry; g_pendSL=slp;
   g_pendT1=tp1; g_pendT2=tp2; g_pendT3=tp3; g_pendT4=tp4;
   g_pendExpiry=TimeCurrent()+InpConfirmSeconds;
   PendingRefresh();
   PrintFormat("MTM Sensei: sinal %s a espera de confirmacao no grafico (%ds)",
               (dir>0?"BUY":"SELL"),InpConfirmSeconds);
  }

void PendingRefresh()
  {
   if(!g_pendActive) return;
   int left=(int)(g_pendExpiry-TimeCurrent());
   if(left<0) left=0;
   ConfirmButton("MTMBTN_GO",10,150,190,
                 StringFormat("ENTRAR %s %s  (%ds)",(g_pendDir>0?"BUY":"SELL"),
                              DoubleToString(g_pendEntry,g_digits),left),
                 (g_pendDir>0)?C'21,128,61':C'153,27,27');
   ConfirmButton("MTMBTN_NO",206,150,100,"IGNORAR",C'55,65,81');
  }

void PendingExpire()
  {
   if(!g_pendActive) return;
   if(TimeCurrent()>=g_pendExpiry)
     {
      Print("MTM Sensei: confirmacao expirou - sinal ignorado");
      PendingClear();
      return;
     }
   PendingRefresh();
  }

void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   //--- o motor precisa dos eventos para as linhas arrastaveis
   MtmEngineChartEvent(id,lparam,dparam,sparam);
   if(id==CHARTEVENT_MOUSE_MOVE)
     { PanelMouse((int)lparam,(int)dparam,(StringToInteger(sparam)&1)!=0); return; }
   if(id==CHARTEVENT_OBJECT_ENDEDIT){ PanelHandleEdit(sparam); return; }
   if(id!=CHARTEVENT_OBJECT_CLICK) return;
   if(PanelHandleClick(sparam)) return;
   if(sparam=="MTMBTN_GO")
     {
      ObjectSetInteger(0,sparam,OBJPROP_STATE,false);
      if(g_pendActive)
        {
         ExecuteEntry(g_pendDir,g_pendEntry,g_pendSL,g_pendT1,g_pendT2,g_pendT3,g_pendT4,g_pendScore);
         PendingClear();
        }
     }
   else if(sparam=="MTMBTN_NO")
     {
      ObjectSetInteger(0,sparam,OBJPROP_STATE,false);
      Print("MTM Sensei: sinal ignorado a mao");
      PendingClear();
     }
  }




//====================================================================
//  FECHO DE FIM DE DIA
//  Evita apanhar o alargamento de spread e o slippage da mudanca de
//  dia (e o swap da noite). Corre uma vez por dia, nao a cada tick.
//====================================================================
int g_eodDay=-1;

bool EndOfDayReached()
  {
   if(!InpCloseEOD) return(false);
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   int cur=d.hour*60+d.min;
   int eod=InpEODHour*60+InpEODMinute;
   if(eod<=0 || eod>=1440) return(false);
   return(cur>=eod);
  }

void EnforceEndOfDay()
  {
   if(!EndOfDayReached()) return;
   MqlDateTime d; TimeToStruct(TimeCurrent(),d);
   int key=d.year*10000+d.mon*100+d.day;
   if(g_eodDay==key) return;              // ja tratado hoje
   g_eodDay=key;
   int n=CountPositions();
   DeletePendings();
   if(n>0)
     {
      PrintFormat("MTM Sensei: fim do dia (%02d:%02d) - a fechar %d posicao(oes) para evitar o spread e o slippage da virada",
                  InpEODHour,InpEODMinute,n);
      CloseAllPositions("fecho de fim de dia");
     }
   else Print("MTM Sensei: fim do dia - sem posicoes abertas, so entradas bloqueadas ate a meia-noite");
  }

//====================================================================
//  ESPECIFICACAO DOS SIMBOLOS
//  Escreve no log o que importa para calibrar pontos/lotes. As
//  distancias em "pontos" mudam com as casas decimais do simbolo,
//  por isso vale a pena confirmar em vez de assumir.
//====================================================================
void LogSymbolSpec(const string sym)
  {
   if(!SymbolInfoInteger(sym,SYMBOL_SELECT))
     {
      if(!SymbolSelect(sym,true))
        { PrintFormat("MTM Sensei: simbolo \"%s\" nao existe nesta corretora",sym); return; }
      PrintFormat("MTM Sensei: \"%s\" adicionado ao Market Watch",sym);
     }
   int    dg =(int)SymbolInfoInteger(sym,SYMBOL_DIGITS);
   double pt =SymbolInfoDouble(sym,SYMBOL_POINT);
   double ts =SymbolInfoDouble(sym,SYMBOL_TRADE_TICK_SIZE);
   double tv =SymbolInfoDouble(sym,SYMBOL_TRADE_TICK_VALUE);
   long   sl =SymbolInfoInteger(sym,SYMBOL_TRADE_STOPS_LEVEL);
   double vmin=SymbolInfoDouble(sym,SYMBOL_VOLUME_MIN);
   double vstp=SymbolInfoDouble(sym,SYMBOL_VOLUME_STEP);
   double cs =SymbolInfoDouble(sym,SYMBOL_TRADE_CONTRACT_SIZE);
   PrintFormat("MTM SPEC %s | digits=%d | point=%s | tick=%s | tickvalue=%.5f | stops=%d | lote min/step=%.2f/%.2f | contrato=%.2f | 1000 pontos=%s",
               sym,dg,DoubleToString(pt,8),DoubleToString(ts,8),tv,(int)sl,vmin,vstp,cs,
               DoubleToString(1000.0*pt,dg));
  }

void WatchSymbols()
  {
   LogSymbolSpec(_Symbol);
   if(StringLen(InpWatchSymbols)==0) return;
   string parts[];
   int n=StringSplit(InpWatchSymbols,',',parts);
   for(int i=0;i<n;i++)
     {
      string v=parts[i];
      StringTrimLeft(v); StringTrimRight(v);
      if(v=="" || v==_Symbol) continue;
      LogSymbolSpec(v);
     }
  }

//====================================================================
//  ALIMENTACAO DO MOTOR
//  Espelha as velas do grafico em arrays proprios e chama o motor.
//  A ancora mantem os indices estaveis entre chamadas (o motor guarda
//  estado por barra, por isso os indices NAO podem escorregar).
//====================================================================
datetime EmTime[];
double   EmO[],EmH[],EmL[],EmC[];
long     EmV[];
int      EmSp[];
datetime g_emAnchor=0;
int      g_emPrev=0;

//--- copia as ultimas "count" velas para o fim do espelho.
//    Devolve quantas conseguiu; NAO falha so porque veio menos do que se pediu.
int EmCopyTail(const int total,const int count)
  {
   datetime tt[]; double oo[],hh[],ll[],cc[]; long vv[];
   ArraySetAsSeries(tt,true); ArraySetAsSeries(oo,true); ArraySetAsSeries(hh,true);
   ArraySetAsSeries(ll,true); ArraySetAsSeries(cc,true); ArraySetAsSeries(vv,true);
   int g=CopyTime(_Symbol,_Period,0,count,tt);
   if(g<=0) return(0);
   int g2=CopyOpen (_Symbol,_Period,0,g,oo); if(g2<g) g=g2;
   g2=CopyHigh     (_Symbol,_Period,0,g,hh); if(g2<g) g=g2;
   g2=CopyLow      (_Symbol,_Period,0,g,ll); if(g2<g) g=g2;
   g2=CopyClose    (_Symbol,_Period,0,g,cc); if(g2<g) g=g2;
   g2=CopyTickVolume(_Symbol,_Period,0,g,vv);if(g2<g) g=g2;
   if(g<=0) return(0);
   for(int k=0;k<g;k++)
     {
      int i=total-1-k;
      if(i<0) break;
      EmTime[i]=tt[k]; EmO[i]=oo[k]; EmH[i]=hh[k];
      EmL[i]=ll[k];    EmC[i]=cc[k]; EmV[i]=vv[k]; EmSp[i]=0;
     }
   return(g);
  }

void EmResize(const int n)
  {
   ArrayResize(EmTime,n); ArrayResize(EmO,n); ArrayResize(EmH,n);
   ArrayResize(EmL,n);    ArrayResize(EmC,n); ArrayResize(EmV,n);
   ArrayResize(EmSp,n);
  }

int  g_emFails=0;
bool g_emWarned=false;

int MtmFeed()
  {
   int avail=Bars(_Symbol,_Period);
   if(avail<700) return(0);

   int have =ArraySize(EmTime);
   int total=(g_emAnchor>0)?Bars(_Symbol,_Period,g_emAnchor,TimeCurrent()):0;
   //--- reancorar quando nao ha espelho, quando ele encolheu, ou quando cresceu demais
   bool full=(have==0 || g_emAnchor==0 || total<have || total>InpEngineBars*2);

   if(full)
     {
      int want=MathMin(avail,InpEngineBars);
      EmResize(want);
      int got=EmCopyTail(want,want);
      if(got<650)
        {
         //--- nao consegui historico suficiente: fica com o espelho anterior
         //    e volta a tentar no proximo tick, em vez de morrer em silencio
         g_emFails++;
         if(g_emFails==5 && !g_emWarned)
           {
            g_emWarned=true;
            PrintFormat("MTM Sensei: sem historico suficiente para o motor (pedidas %d velas, vieram %d). "
                        "Reduz InpEngineBars ou espera que o historico carregue.",want,got);
           }
         EmResize(have);
         return(0);
        }
      //--- ficou so com o que veio mesmo
      if(got<want)
        {
         EmResize(got);
         EmCopyTail(got,got);
        }
      g_emFails=0; g_emWarned=false;
      g_emAnchor=EmTime[0];
      g_emPrev=MtmEngineCalculate(ArraySize(EmTime),0,EmTime,EmO,EmH,EmL,EmC,EmV,EmV,EmSp);
      return(ArraySize(EmTime));
     }

   if(total>have)
     {
      EmResize(total);
      int k=total-have+2; if(k>total) k=total;
      if(EmCopyTail(total,k)<=0){ EmResize(have); return(0); }
     }
   else if(EmCopyTail(total,2)<=0) return(0);   // so a vela em formacao mudou

   g_emPrev=MtmEngineCalculate(total,g_emPrev,EmTime,EmO,EmH,EmL,EmC,EmV,EmV,EmSp);
   return(total);
  }




//====================================================================
//  PLOTS DO INDICADOR DENTRO DO EA
//  Um EA nao tem buffers, por isso nao consegue desenhar linhas de
//  indicador. A saida honesta e o EA aplicar o proprio indicador ao
//  grafico: sao os mesmos plots, desenhados por quem os sabe desenhar.
//====================================================================
bool VisualAlreadyOnChart()
  {
   int n=ChartIndicatorsTotal(0,0);
   for(int i=0;i<n;i++)
      if(StringFind(ChartIndicatorName(0,0,i),"MTM Sensei")>=0) return(true);
   return(false);
  }

void VisualAttach()
  {
   //--- nenhum caminho sai daqui em silencio: se os plots nao aparecem,
   //    o log tem de dizer porque.
   if(!InpDrawPlots)
     { Print("MTM plots: desligados no input InpDrawPlots"); return; }
   if(MQLInfoInteger(MQL_OPTIMIZATION)!=0) return;              // optimizacao: sem grafico
   if(MQLInfoInteger(MQL_TESTER)!=0 && MQLInfoInteger(MQL_VISUAL_MODE)==0)
     { Print("MTM plots: em backtest sem modo visual nao ha grafico onde os aplicar"); return; }
   if(g_visH!=INVALID_HANDLE)
     { Print("MTM plots: ja aplicados"); return; }
   if(VisualAlreadyOnChart())
     { Print("MTM plots: o indicador ja esta no grafico - nao volto a aplica-lo"); return; }
   Print("MTM plots: a carregar ",MTM_VISUAL_NAME," ...");

   g_visH=iCustom(_Symbol,_Period,MTM_VISUAL_NAME);
   if(g_visH==INVALID_HANDLE)
     {
      PrintFormat("MTM plots: FALHOU a carregar %s (erro %d). "
                  "Aplica o indicador ao grafico a mao se os quiseres.",
                  MTM_VISUAL_NAME,GetLastError());
      return;
     }
   if(ChartIndicatorAdd(0,0,g_visH))
      Print("MTM plots: aplicados ao grafico com sucesso");
   else
     {
      PrintFormat("MTM plots: iCustom carregou mas ChartIndicatorAdd falhou (erro %d)",GetLastError());
      IndicatorRelease(g_visH); g_visH=INVALID_HANDLE;
     }
  }

void VisualDetach()
  {
   if(g_visH==INVALID_HANDLE) return;
   int n=ChartIndicatorsTotal(0,0);
   for(int i=n-1;i>=0;i--)
      if(StringFind(ChartIndicatorName(0,0,i),"MTM Sensei")>=0)
         ChartIndicatorDelete(0,0,ChartIndicatorName(0,0,i));
   IndicatorRelease(g_visH); g_visH=INVALID_HANDLE;
  }

//====================================================================
//  ARRASTAR OS PAINEIS
//  O MT5 nao move objectos ancorados ao ecra, por isso fazemo-lo a mao:
//  clicar na barra de titulo e arrastar desloca todos os objectos do
//  painel pelo mesmo delta.
//====================================================================
int  g_dragWhat=0;      // 0 = nada, 1 = painel de controlo, 2 = dashboard
int  g_dragLX=0, g_dragLY=0;

bool InRect(const int mx,const int my,const int x,const int y,const int w,const int h)
  { return(mx>=x && mx<=x+w && my>=y && my<=y+h); }

void PanelMouse(const int mx,const int my,const bool down)
  {
   if(!down){ g_dragWhat=0; return; }

   if(g_dragWhat==0)
     {
      //--- barra de titulo do painel de controlo
      if(InRect(mx,my,g_panX-4,g_panY-4,UIW+8,26)) g_dragWhat=1;
      //--- barra de titulo da coluna do dashboard
      else if(g_uiView==2 && InRect(mx,my,g_dashX,g_dashY-22,284,22)) g_dragWhat=2;
      if(g_dragWhat!=0){ g_dragLX=mx; g_dragLY=my; }
      return;
     }

   int dx=mx-g_dragLX, dy=my-g_dragLY;
   if(dx==0 && dy==0) return;
   g_dragLX=mx; g_dragLY=my;
   if(g_dragWhat==1){ UiShift(PN,dx,dy); g_panX+=dx;  g_panY+=dy; }
   else             { UiShift(DB,dx,dy); g_dashX+=dx; g_dashY+=dy; }
   ChartRedraw();
  }

//====================================================================
//  ACCOES DO PAINEL
//====================================================================
//--- "so plots": pinta as velas da cor do fundo, ficando apenas o que o
//    indicador desenha. Nao apaga nada — e reversivel no mesmo botao.
color g_savedBull=clrNONE,g_savedBear=clrNONE,g_savedUp=clrNONE,g_savedDn=clrNONE,g_savedLine=clrNONE;

void ApplyCleanChart(const bool on)
  {
   if(on)
     {
      if(g_savedBull==clrNONE)
        {
         g_savedBull=(color)ChartGetInteger(0,CHART_COLOR_CANDLE_BULL);
         g_savedBear=(color)ChartGetInteger(0,CHART_COLOR_CANDLE_BEAR);
         g_savedUp  =(color)ChartGetInteger(0,CHART_COLOR_CHART_UP);
         g_savedDn  =(color)ChartGetInteger(0,CHART_COLOR_CHART_DOWN);
         g_savedLine=(color)ChartGetInteger(0,CHART_COLOR_CHART_LINE);
        }
      color bg=(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
      ChartSetInteger(0,CHART_COLOR_CANDLE_BULL,bg);
      ChartSetInteger(0,CHART_COLOR_CANDLE_BEAR,bg);
      ChartSetInteger(0,CHART_COLOR_CHART_UP,bg);
      ChartSetInteger(0,CHART_COLOR_CHART_DOWN,bg);
      ChartSetInteger(0,CHART_COLOR_CHART_LINE,bg);
      Print("MTM: grafico original escondido - ficam so os plots do indicador");
     }
   else
     {
      if(g_savedBull!=clrNONE)
        {
         ChartSetInteger(0,CHART_COLOR_CANDLE_BULL,g_savedBull);
         ChartSetInteger(0,CHART_COLOR_CANDLE_BEAR,g_savedBear);
         ChartSetInteger(0,CHART_COLOR_CHART_UP,g_savedUp);
         ChartSetInteger(0,CHART_COLOR_CHART_DOWN,g_savedDn);
         ChartSetInteger(0,CHART_COLOR_CHART_LINE,g_savedLine);
        }
      Print("MTM: grafico original reposto");
     }
   ChartRedraw();
  }

//--- entrada manual: usa os mesmos niveis que o automatico usaria
void PanelManualEntry(const int dir)
  {
   double atr[];
   if(CopyBuffer(g_atrH,0,0,1,atr)!=1 || atr[0]<=0){ Print("MTM: sem ATR para a entrada manual"); return; }
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double e =(dir>0)?ask:bid;
   double d =(InpRiskMode==RISK_ATR)? atr[0]*g_actSlMult : e*(InpSlPct/100.0);
   if(d<=0){ Print("MTM: distancia de SL invalida"); return; }
   double sl =(dir>0)? e-d : e+d;
   double t1 =(dir>0)? e+d*g_rr1 : e-d*g_rr1;
   double t2 =(dir>0)? e+d*g_rr2 : e-d*g_rr2;
   double t3 =(dir>0)? e+d*g_rr3 : e-d*g_rr3;
   double t4 =(dir>0)? e+d*g_rr4 : e-d*g_rr4;
   PrintFormat("MTM: entrada MANUAL %s pedida no painel",(dir>0?"BUY":"SELL"));
   //--- a entrada manual salta a zona util (foi decisao tua), mas mantem
   //    o resto das guardas: prop firm, spread, limite de posicoes
   bool antes=g_uiAuto; g_uiAuto=true;
   ExecuteEntry(dir,e,sl,t1,t2,t3,t4,0);
   g_uiAuto=antes;
  }

//--- fecha X% do volume ACTUAL de cada posicao gerida
void PanelPartial(const double pct)
  {
   if(pct<=0 || pct>=100){ Print("MTM: percentagem de parcial invalida"); return; }
   int n=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      double vol=PositionGetDouble(POSITION_VOLUME);
      double cut=NormLot(vol*pct/100.0);
      if(cut<g_lotMin){ PrintFormat("MTM: %.0f%% de %.2f fica abaixo do lote minimo",pct,vol); continue; }
      if(vol-cut<g_lotMin) cut=vol;
      if(cut>=vol) { if(trade.PositionClose(tk,InpDeviation)){ StateDel(tk); n++; } }
      else if(trade.PositionClosePartial(tk,cut,InpDeviation)) n++;
     }
   PrintFormat("MTM: parcial de %.0f%% aplicada a %d posicao(oes)",pct,n);
  }

//--- troca de estilo obriga o motor a recalcular tudo de novo
void PanelSetStyle(const int s)
  {
   g_uiStyle=(s+6)%6;
   g_styleOverride=g_uiStyle;
   ResolveAuto();
   g_emAnchor=0;              // forca reconstrucao do espelho e recalculo total
   PrintFormat("MTM: estilo -> %s  (score min %d, ADX>%.0f, cooldown %d, SLx%.1f)",
               StyleName(g_uiStyle),g_effMinScore,g_effAdx,g_effCooldown,g_actSlMult);
  }

double PanelFloating()
  {
   double v=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      v+=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
     }
   return(v);
  }



//--- Na vista dashboard fica so o essencial: velas + niveis da posicao.
//    Estrutura SMC, order blocks, etiquetas e badges sao escondidos (nao
//    apagados) mexendo no periodo de visibilidade do objecto.
void SetDecorVisible(const bool on)
  {
   long flag = on ? OBJ_ALL_PERIODS : OBJ_NO_PERIODS;
   int total=ObjectsTotal(0,-1,-1);
   for(int i=total-1;i>=0;i--)
     {
      string n=ObjectName(0,i,-1,-1);
      if(StringFind(n,g_prefix)!=0) continue;            // so os do motor
      if(StringFind(n,g_prefix+"L_")==0) continue;       // niveis da trade: ficam
      ObjectSetInteger(0,n,OBJPROP_TIMEFRAMES,flag);
     }
  }

//--- 0 = grafico normal | 1 = so os plots | 2 = dashboard de marca
void PanelSetView(const int v)
  {
   g_uiView=v;
   //--- vista 1 esconde as velas; a 2 mostra-as outra vez, so sem a decoracao
   ApplyCleanChart(v==1);
   SetDecorVisible(v!=2);
   if(v==2) VisualDetach(); else VisualAttach();
   if(v==2)
     {
      DashBuild();
      //--- o painel e recriado por cima do fundo (ordem de criacao = ordem de desenho)
      string r=ObjectGetString(0,PN"risk",OBJPROP_TEXT);
      string q=ObjectGetString(0,PN"part",OBJPROP_TEXT);
      PanelDestroy(); PanelBuild();
      ObjectSetString(0,PN"risk",OBJPROP_TEXT,r);
      ObjectSetString(0,PN"part",OBJPROP_TEXT,q);
     }
   else DashDestroy();
   ChartRedraw();
   Print("MTM: vista -> ",(v==0?"grafico":(v==1?"so plots":"dashboard MoreThanMoney")));
  }

void DashTick()
  {
   if(g_uiView!=2) return;
   //--- se a janela mudou de tamanho, redesenha o fundo
   static int lw=0,lh=0;
   int W=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);
   int H=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS);
   if(W!=lw || H!=lh){ lw=W; lh=H; DashBuild(); }

   bool news=NewsBlocked();
   string rod=StringFormat("%s  %s   ·   %s   ·   %s   ·   morethanmoney.pt",
        _Symbol,EnumToString((ENUM_TIMEFRAMES)_Period),
        (g_uiAuto?"automatico ligado":"automatico desligado"),
        (news?("noticias: "+g_newsCurrent)
             :(g_newsNext>0?("proxima noticia "+TimeToString(g_newsNext,TIME_MINUTES)):"sem noticias")));
   bool ib=(g_curPos>0);
   DashRefresh(g_bullScore,g_bearScore,
               ib?g_grA_b:g_grA_s, ib?g_grB_b:g_grB_s, ib?g_grC_b:g_grC_s, ib?g_grD_b:g_grD_s,
               g_curPos,g_curEntry,g_curSL,g_curTP1,g_curTP2,g_curTP3,g_curTP4,
               g_disp.tp1Hit,g_disp.tp2Hit,g_disp.tp3Hit,g_disp.tp4Hit,g_disp.beTrig,
               g_curAdx,g_curRsi,g_ofBull,g_ofBear,
               (ib?g_htfBuyOK:g_htfSellOK),g_inSess,g_chopOK,g_cooldownOK,
               rod,_Digits);
  }

//--- devolve true se o clique foi tratado pelo painel
bool PanelHandleClick(const string nm)
  {
   if(StringFind(nm,PN)!=0) return(false);
   ObjectSetInteger(0,nm,OBJPROP_STATE,false);
   string k=StringSubstr(nm,StringLen(PN));

   if(k=="auto")     { g_uiAuto=!g_uiAuto;
                       Print("MTM: automatico ",(g_uiAuto?"LIGADO":"DESLIGADO")," no painel"); }
   else if(k=="buy")      PanelManualEntry(1);
   else if(k=="sell")     PanelManualEntry(-1);
   else if(k=="mode")   { g_uiLotMode=1-g_uiLotMode;
                          g_uiRisk=(g_uiLotMode==1)?InpFixedLot:InpRiskPercent;
                          ObjectSetString(0,PN"risk",OBJPROP_TEXT,DoubleToString(g_uiRisk,2));
                          Print("MTM: sizing por ",(g_uiLotMode==1?"LOTES":"RISCO %")); }
   else if(k=="trail")  { g_uiTrailMode=(g_uiTrailMode+1)%3;   // OFF -> ATR -> PONTOS
                          if(g_uiTrailMode==1)
                             PrintFormat("MTM: trailing ATR x%.1f (passo %d pts)",InpEaTrailMult,InpTrailStepPts);
                          else if(g_uiTrailMode==2)
                             PrintFormat("MTM: trailing %d pontos (passo %d)",InpEaTrailPoints,InpTrailStepPts);
                          else Print("MTM: trailing desligado"); }
   else if(k=="clean")  { PanelSetView((g_uiView+1)%3); }
   else if(k=="lang")
     {
      g_uiLang=1-g_uiLang;
      //--- os textos estao nos objectos: e preciso reconstruir para trocarem
      string r=ObjectGetString(0,PN"risk",OBJPROP_TEXT);
      string q=ObjectGetString(0,PN"part",OBJPROP_TEXT);
      PanelDestroy(); PanelBuild();
      ObjectSetString(0,PN"risk",OBJPROP_TEXT,r);
      ObjectSetString(0,PN"part",OBJPROP_TEXT,q);
      if(g_uiView==2) DashBuild();
      Print("MTM: idioma -> ",(g_uiLang==1?"English":"Portugues"));
     }
   else if(k=="dopart")   PanelPartial(g_uiPartial);
   else if(k=="closeall") CloseAllPositions("botao FECHAR TUDO");
   else if(k=="stylL")    PanelSetStyle(g_uiStyle-1);
   else if(k=="stylR")    PanelSetStyle(g_uiStyle+1);
   else return(false);
   ChartRedraw();
   return(true);
  }

//--- campos de texto
bool PanelHandleEdit(const string nm)
  {
   if(nm==PN"risk")
     {
      double v=StringToDouble(ObjectGetString(0,nm,OBJPROP_TEXT));
      if(v>0){ g_uiRisk=v; PrintFormat("MTM: %s = %.2f",(g_uiLotMode==1?"lotes":"risco %%"),v); }
      ObjectSetString(0,nm,OBJPROP_TEXT,DoubleToString(g_uiRisk,2));
      return(true);
     }
   if(nm==PN"part")
     {
      double v=StringToDouble(ObjectGetString(0,nm,OBJPROP_TEXT));
      if(v>0 && v<100) g_uiPartial=v;
      ObjectSetString(0,nm,OBJPROP_TEXT,DoubleToString(g_uiPartial,0));
      return(true);
     }
   return(false);
  }

//====================================================================
//  ONTICK

//====================================================================
//  ONTICK
//====================================================================
void OnTick()
  {
   //--- 1) actualiza o indicador embutido (desenha e recalcula os sinais)
   static datetime lastEngine=0;
   datetime cur=iTime(_Symbol,_Period,0);
   if(cur!=lastEngine){ lastEngine=cur; MtmFeed(); }
   else
     {
      static datetime lastLive=0;
      if(TimeCurrent()!=lastLive){ lastLive=TimeCurrent(); MtmFeed(); }
     }

   LicTick(InpLicenseKey,InpLicenseUrl);
   UpdTick(InpLicenseUrl,InpLicenseKey,InpOtaCheck,InpOtaDownload);
   AplicarOta();

   EnforceEndOfDay();

   ManagePositions();
   NewsRefresh();
   PropEnforce();
   NewsEnforce();

   static datetime lastPanel=0;
   if(TimeCurrent()!=lastPanel)
     {
      lastPanel=TimeCurrent();
      PendingExpire();
      if(InpPropPanel && MQLInfoInteger(MQL_OPTIMIZATION)==0)
        {
         bool news=NewsBlocked();
         bool algo=(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)!=0) && (MQLInfoInteger(MQL_TRADE_ALLOWED)!=0);
         bool eod =EndOfDayReached();
         bool can =PropCanTrade() && !news && g_uiAuto && algo && !eod;
         string why = (!algo)?"AutoTrading desligado":(!g_uiAuto)?"automatico OFF":
                      eod?"fim do dia":news?("noticias: "+g_newsCurrent):
                      (g_propReason!=""?g_propReason:"horario/spread");
         string risco = InpPropEnable
              ? StringFormat("Dia %s   DD %s",PropFmt(PropDailyPL(),PropDailyPct()),
                                              PropFmt(PropTotalPL(),PropTotalPct()))
              : "Prop firm desligado";
         string nots = (!InpUseNews && !InpExtNews) ? "Noticias: filtro off"
                     : (g_newsNext>0 ? "Proxima noticia "+TimeToString(g_newsNext,TIME_MINUTES)
                                     : "Noticias: sem eventos");
         PanelRefresh(can,why,MathMax(g_bullScore,g_bearScore),CountPositions(),
                      PanelFloating(),risco,nots);
         DashTick();
        }
     }

   if(InpFridayClose)
     {
      MqlDateTime d; TimeToStruct(TimeCurrent(),d);
      if(d.day_of_week==5 && d.hour>=InpFridayHour)
        {
         CloseAllPositions("fecho de sexta-feira");
         DeletePendings();
         return;
        }
     }

   datetime bt=iTime(_Symbol,_Period,0);
   bool newBar=(bt!=g_lastBarTime);
   if(newBar)
     {
      g_lastBarTime=bt;
      DeletePendings();
      StateCleanup();
     }

   //--- com "apenas fecho de vela" so vale a pena testar na barra nova
   if(InpConfirmClose && !newBar) return;

   CheckForEntry();
  }
//+------------------------------------------------------------------+
