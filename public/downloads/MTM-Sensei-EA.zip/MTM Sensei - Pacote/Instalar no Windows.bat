@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title MTM Sensei - instalacao no MetaTrader 5

rem ============================================================
rem   MTM Sensei - instalador para Windows
rem   MoreThanMoney - morethanmoney.pt
rem
rem   A pasta de dados do MetaTrader nao e onde o programa esta
rem   instalada: e uma pasta com um nome em hexadecimal dentro de
rem   %APPDATA%\MetaQuotes\Terminal, e quem tem MT5 de duas
rem   corretoras tem duas. Este script encontra-as todas e
rem   instala em cada uma - e o que evita o "instalei e nao
rem   aparece" de quem escolheu a pasta errada.
rem ============================================================

cd /d "%~dp0"

echo.
echo ================================================================
echo   MTM SENSEI  ·  instalacao no MetaTrader 5  ·  Windows
echo ================================================================
echo.

if not exist "MQL5" (
  echo   [x] Este ficheiro tem de ficar DENTRO da pasta do pacote,
  echo       ao lado da pasta MQL5.
  echo.
  pause
  exit /b 1
)

set "RAIZ=%APPDATA%\MetaQuotes\Terminal"
if not exist "%RAIZ%" (
  echo   [x] Nao encontrei o MetaTrader 5 instalado.
  echo.
  echo       Instala-o primeiro em:
  echo         https://www.metatrader5.com/en/download
  echo       Abre-o uma vez, para criar as pastas, e volta a correr isto.
  echo.
  pause
  exit /b 1
)

set /a CONTA=0

rem Cada subpasta com MQL5 la dentro e um terminal instalado. A pasta
rem "Common" tambem vive aqui mas nao tem MQL5, por isso fica de fora.
for /d %%T in ("%RAIZ%\*") do (
  if exist "%%T\MQL5\Experts" (
    echo   Encontrado: %%~nxT
    xcopy /E /I /Y /Q "MQL5" "%%T\MQL5" >nul 2>&1
    if errorlevel 1 (
      echo   [!] Falhou a copia. Fecha o MetaTrader e tenta outra vez.
    ) else (
      echo   [ok] EA, indicador, presets e scripts copiados
      set /a CONTA+=1
    )
  )
)

if %CONTA%==0 (
  echo.
  echo   [x] Encontrei a pasta do MetaTrader mas nenhum terminal.
  echo       Abre o MetaTrader 5 uma vez e volta a correr isto.
  echo.
  pause
  exit /b 1
)

rem Calendario de noticias - pasta partilhada por todos os terminais
if exist "Common\Files" (
  if not exist "%RAIZ%\Common\Files" mkdir "%RAIZ%\Common\Files" >nul 2>&1
  xcopy /E /I /Y /Q "Common\Files" "%RAIZ%\Common\Files" >nul 2>&1
  if not errorlevel 1 echo   [ok] Calendario de noticias instalado
)

rem Abrir o guia
for %%G in (*.pdf) do (
  start "" "%%G"
  echo   [ok] Guia de instrucoes aberto
  goto :guia_feito
)
:guia_feito

echo.
echo ----------------------------------------------------------------
echo   FALTAM 3 PASSOS NO METATRADER
echo ----------------------------------------------------------------
echo.
echo   1. COMPILAR
echo      Abre o MetaEditor (tecla F4) e compila por esta ordem, com F7:
echo        Indicadores ^> MTM ^> MTM_Sensei_v3
echo        Indicadores ^> MTM ^> MTM_Sensei_Core
echo        Consultores ^> MTM ^> MTM_Sensei_AllInOne
echo.
echo   2. PERMITIR O ENDERECO DA LICENCA
echo      Ferramentas ^> Opcoes ^> Consultores
echo      Liga "Permitir WebRequest para os seguintes URLs" e acrescenta:
echo        https://www.morethanmoney.pt
echo      Sem isto o EA nao valida a licenca e nao abre ordens.
echo.
echo   3. POR NO GRAFICO
echo      Arrasta Consultores ^> MTM ^> MTM_Sensei_AllInOne para um grafico,
echo      escreve a tua chave no campo "Licenca" e carrega um preset.
echo.
echo   Instalado em %CONTA% terminal(is).
echo   Duvidas? O guia que abriu tem tudo.
echo.
pause
