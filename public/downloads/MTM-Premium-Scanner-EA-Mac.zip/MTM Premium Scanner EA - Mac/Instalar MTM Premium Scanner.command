#!/bin/bash
# MTM Premium Scanner EA — instalador para MetaTrader 5 no Mac (Wine)
# Duplo clique. Se o Mac bloquear: botao direito > Abrir > Abrir.
cd "$(dirname "$0")" || exit 1
ORIG="$(pwd)/ficheiros"
EX5="$ORIG/MTM_Premium_Scanner_EA.ex5"
SET="$ORIG/MTM_PremiumScanner_XAUUSD_M15.set"
echo ""
echo "=== MTM Premium Scanner EA · instalador Mac ==="
echo ""
if [ ! -f "$EX5" ]; then
  echo "Nao encontrei a pasta 'ficheiros' ao lado deste instalador."
  echo "Descompacta o .zip inteiro e corre outra vez."
  read -r -p "Enter para fechar." _; exit 1
fi

# Procura todas as pastas MQL5 do MetaTrader 5 (app oficial, CrossOver, Wine)
RAIZES=(
  "$HOME/Library/Application Support/net.metaquotes.wine.metatrader5"
  "$HOME/Library/Application Support/MetaTrader 5"
  "$HOME/Library/Application Support/CrossOver/Bottles"
  "$HOME/.wine"
  "$HOME/Library/Application Support"
)
DESTINOS=()
for R in "${RAIZES[@]}"; do
  [ -d "$R" ] || continue
  while IFS= read -r -d '' D; do
    M="${D%/Experts}"
    case " ${DESTINOS[*]} " in *" $M "*) ;; *) DESTINOS+=("$M");; esac
  done < <(find "$R" -maxdepth 12 -type d -path "*MQL5/Experts" -print0 2>/dev/null)
  [ ${#DESTINOS[@]} -gt 0 ] && break
done

if [ ${#DESTINOS[@]} -eq 0 ]; then
  echo "Nao encontrei o MetaTrader 5 neste Mac."
  echo "1) Abre o MetaTrader 5 pelo menos uma vez e fecha-o."
  echo "2) Corre este instalador outra vez."
  echo "Ou instala a mao: no MT5, Ficheiro > Abrir pasta de dados > MQL5,"
  echo "e copia os ficheiros da pasta 'ficheiros' (ver LEIA-ME)."
  open "$ORIG" 2>/dev/null
  read -r -p "Enter para fechar." _; exit 1
fi

for M in "${DESTINOS[@]}"; do
  mkdir -p "$M/Experts/MTM" "$M/Presets"
  cp -f "$EX5" "$M/Experts/MTM/" && cp -f "$SET" "$M/Presets/" \
    && echo "OK  ->  $M" || echo "ERRO a copiar para $M"
done

echo ""
echo "Instalado. Agora, no MetaTrader 5:"
echo "  1. Fecha e volta a abrir o MT5 (ou: Navegador > botao direito > Actualizar)."
echo "  2. Ferramentas > Opcoes > Consultores: marca 'Permitir negociacao algoritmica'"
echo "     e 'Permitir WebRequest para os URLs' e acrescenta:"
echo "        https://www.morethanmoney.pt"
echo "  3. Grafico XAUUSD M15 > arrasta Consultores > MTM > MTM_Premium_Scanner_EA."
echo "  4. Parametros > Carregar > MTM_PremiumScanner_XAUUSD_M15.set"
echo "     e cola a tua chave de licenca (MTM-XXXX-XXXX-XXXX) em 'Chave'."
echo "  5. A EA arranca PARADA: carrega em INICIAR no painel."
echo ""
read -r -p "Enter para fechar." _
