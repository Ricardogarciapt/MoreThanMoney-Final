//+------------------------------------------------------------------+
//|                                      MTM_Sensei_Scalp.mq5        |
//|  Este software e codigo sao parte integrante da propriedade       |
//|  intelectual de RicardoGarciaPT e da sua empresa MoreThanMoney    |
//|                                                                  |
//|  SENSEI SCALP EDITION — negociacao rapida com ordens pendentes.   |
//|                                                                  |
//|  A leitura e a mesma do Sensei — o motor corre inteiro aqui       |
//|  dentro — mas em vez de entrar a mercado com stop e alvos, arma   |
//|  um BUY STOP acima e/ou um SELL STOP abaixo e deixa o preco       |
//|  escolher. Assim que uma dispara, comeca o trailing; a oposta     |
//|  fica armada e passa a ser a REVERSAO.                            |
//|                                                                  |
//|  ── SOBRE O "SEM STOP LOSS" ─────────────────────────────────────  |
//|  Nao ha SL fixo, e isso e por desenho. Mas nao ha sistema nenhum  |
//|  que feche sempre a positivo: quem nunca fecha o lado errado      |
//|  acumula prejuizo por realizar ate a chamada de margem, e e assim |
//|  que se rebentam contas.                                          |
//|                                                                  |
//|  Aqui quem protege e a ORDEM DE REVERSAO. Quando o preco vira,    |
//|  ela dispara, fecha a posicao anterior e abre a contraria. Nessa  |
//|  passagem HA uma perda realizada. E o preco de nao ter stop, e    |
//|  nao ha desenho que a evite — o que ha e limites que a impedem de |
//|  se repetir sem fim, e esses estao todos ligados por defeito.     |
//|                                                                  |
//|  Sem verificacao de licenca, ao contrario do AllInOne: isto e     |
//|  ferramenta de casa, nao produto que se venda.                    |
//|                                                                  |
//|  Desenha os mesmos plots do Sensei — um EA nao tem buffers, por   |
//|  isso aplica o proprio indicador ao grafico.                      |
//|                                                                  |
//|  ── O QUE MUDOU NA v1.10 ────────────────────────────────────────  |
//|  A conta e simples: cada ciclo PAGA o spread, e o que ganha e o   |
//|  que o preco andar. Num mercado parado o ciclo nao consegue       |
//|  pagar-se — nao e azar, e aritmetica — e e em lateral que ele     |
//|  dispara mais vezes. Toda a v1.10 e sobre nao negociar ai:        |
//|    1. So arma se o ATR cobrir distancia + spread com folga.       |
//|    2. Nao reverte contra o vies do Sensei (poe stop, nao abre).   |
//|    3. Trailing indexado ao ATR, com piso em multiplos do spread.  |
//|    4. Tecto de reversoes seguidas; depois exige sinal novo.       |
//|    5. Janela de sessao apertada ao overlap Londres/NY (preset).   |
//|    6. Piramide so com expansao, nao com "ligeiramente positivo".  |
//|                                                                  |
//|  Nada disto substitui o que pesa mais, que nao esta no codigo:    |
//|  numa conta com 55 pontos de spread o custo de 1700 ciclos e de   |
//|  ~935 USD a 0,01 lotes. Em conta raw/ECN e menos de metade.       |
//|                                                                  |
//|  ── SOBRE "HFT" ────────────────────────────────────────────────  |
//|  Isto e scalping rapido, nao high-frequency trading. HFT a serio  |
//|  mede-se em microssegundos e vive ao lado do motor de negociacao  |
//|  da bolsa. O MetaTrader recebe ticks pela internet e executa numa |
//|  corretora de retalho: o teu chao e a latencia dela, nao o teu    |
//|  codigo. Chamar-lhe HFT nao muda o que ele consegue fazer.        |
//+------------------------------------------------------------------+
#property copyright "RicardoGarciaPT - MoreThanMoney"
#property link      "https://morethanmoney.pt"
#property version   "1.10"
#property description "MTM Sensei Scalp Edition - buy stop / sell stop, trailing imediato e reversao, com o viés do Sensei"

#include <Trade/Trade.mqh>
#include <MTMScalp/MTM_Sensei_Defs.mqh>

//====================================================================
//  INPUTS
//====================================================================
//====================================================================
//  PARAMETROS
//
//  SO O QUE INTERESSA A QUEM USA. As distancias, os alvos, a piramide e os
//  68 parametros do motor Sensei ficam fixos no codigo, nos valores com que
//  isto foi MEDIDO. Nao e para esconder nada: postos aqui eram mais de cem
//  campos, dos quais talvez seis mudam alguma coisa para quem esta a operar,
//  e os outros so davam maneira de desafinar em silencio um motor que ja vem
//  afinado. Quem quiser experimentar tem o indicador Sensei, que expoe tudo.
//====================================================================
input group                "=== LICENCA ==="
input string   InpLicenseKey    = "";      // Chave (MTM-XXXX-XXXX-XXXX)
input string   InpLicenseUrl    = "https://www.morethanmoney.pt"; // Servidor (permitir em Opcoes > Consultores)

input group                "=== EXECUCAO ==="
// Arranca PARADA: quem liga e o botao INICIAR do painel. Poe true so se for
// para uma VPS, onde nao ha ninguem para carregar no botao.
input bool     InpEnableTrading = false;   // Comecar a negociar logo ao anexar
input long     InpMagic         = 770101;  // Numero magico (muda se correres duas copias)

input group                "=== DIMENSIONAMENTO ==="
// O DEFEITO E PARA CONTAS PEQUENAS. 0,01 fixo e o que foi medido, e numa
// conta de 100 USD e o unico que cabe: 0,01 em ouro ja ocupa ~41 USD de
// margem a 1:100. O painel deixa trocar isto ao vivo.
input bool     InpRiscoPorPct   = false;   // Dimensionar por % do saldo (senao: lote fixo)
input double   InpLote          = 0.01;    // Lote fixo
input double   InpRiscoPct      = 1.0;     // Risco por ciclo, em % do saldo

input group                "=== SESSAO (HORA DO SERVIDOR, nao a tua) ==="
// A janela e a maior alavanca que se mediu nesta EA: a mesma configuracao
// rendeu +887 das 08h as 21h e +2118 das 13h as 17h, com o MESMO numero de
// trades. 13:00-17:00 e a tarde de Londres com a abertura de Nova Iorque la
// dentro, NUM SERVIDOR GMT+0. Se o teu servidor estiver noutro fuso, corrige
// aqui — a EA escreve a diferenca no log quando arranca.
input bool     InpUsarHorario   = true;    // Limitar a uma janela do dia
input string   InpHoraInicio    = "13:00"; // Inicio (hora do servidor)
input string   InpHoraFim       = "17:00"; // Fim (hora do servidor)

input group                "=== NOTICIAS ==="
// Esta EA nao tem stop loss. Numa NFP o preco anda 3 USD em segundos e a
// ordem de reversao — o unico travao — e preenchida onde houver liquidez,
// nao onde esta desenhada. Por isso o defeito e FECHAR, nao so nao entrar.
input bool     InpFiltroNoticias= true;    // Ligar o filtro de noticias
input bool     InpNoticiasFecham= true;    // Fechar posicoes na janela (senao: so nao abre novas)
input ENUM_MTM_NEWSIMP InpNewsImportance = NEWS_HIGH; // Impacto a considerar
input int      InpNewsBeforeMin  = 30;     // Minutos ANTES do evento
input int      InpNewsAfterMin   = 30;     // Minutos DEPOIS do evento

input group                "=== PROTECOES (sem SL, sao elas que seguram) ==="
// InpMaxCiclosDia e o parametro que MANDA nesta EA, e quase ninguem adivinha:
// nos testes ela bateu no tecto de 20 em 85 dias de 85. Na pratica negoceia a
// primeira hora da janela e para. Subi-lo muda a EA toda.
input int      InpMaxCiclosDia   = 20;     // Maximo de ciclos por dia (0 = sem limite)
input double   InpPerdaMaxDiaPct = 3.0;    // Perda maxima do dia, em % do saldo (0 = sem limite)
input int      InpMaxSpreadPts   = 0;      // Spread maximo em pontos (0 = sem limite)

input group                "=== ECRA ==="
input bool     InpPainel        = true;    // Mostrar o painel
input bool     InpDrawPlots     = true;    // Desenhar os plots do Sensei

//====================================================================
//  O QUE NAO SE MEXE  —  os valores medidos
//
//  ESTAO EM USD, NAO EM PONTOS, E ISSO E DE PROPOSITO.
//
//  Um "ponto" e a ultima casa decimal do preco, e o ouro tem 2 casas numas
//  corretoras e 3 noutras. Escritas em pontos, estas distancias valeriam dez
//  vezes mais ou dez vezes menos conforme a corretora — o ficheiro carregava
//  sem um erro e a estrategia deixava de ser a mesma sem nada no ecra a
//  dize-lo. Foi a armadilha que mais tempo custou a apanhar em todo este
//  trabalho. Em USD nao ha armadilha: 0,150 USD sao 0,150 USD em toda a
//  parte, e a conversao para pontos faz-se no arranque, com o _Point real.
//====================================================================
#define SC_DIST_USD        0.150   // distancia da pendente ao preco
#define SC_TRAIL_USD       0.120   // distancia do trailing
#define SC_BE_USD          0.005   // breakeven acima da entrada (cobre custos)
#define SC_PASSO_USD       0.020   // so mexe o stop se ganhar isto
#define SC_FOLGA_REV_USD   0.030   // a reversao fica isto alem do stop
#define SC_LUCRO_MAIS_USD  0.030   // lucro antes de empilhar mais uma
#define SC_DESVIO_USD      0.020   // desvio maximo aceite na execucao

#define SC_MAX_PIRAMIDE    3       // posicoes empilhadas no maximo
#define SC_MAX_REV_CADEIA  2       // reversoes seguidas antes de exigir sinal novo
#define SC_TRAIL_MIN_SPR   3.0     // piso do trailing, em multiplos do spread

//--- estes tres foram MEDIDOS um a um e nenhum ajudou (-7, -162 e -61 USD).
//    Ficam no codigo, a zero, porque o teste e que manda e nao a intuicao.
#define SC_ATR_MIN_X       0.0
#define SC_TRAIL_ATR_X     0.0
#define SC_PIR_ATR_X       0.0
//--- este disparava 1695 vezes em 1739 ciclos: nao era "reverter com
//    criterio", era "nunca reverter". Ver o LEIA-ME.
#define SC_REV_SO_COM_VIES false

//--- convertidos para pontos no OnInit, ja com o _Point desta corretora
int SC_DIST=150, SC_TRAIL=120, SC_BE=5, SC_PASSO=20, SC_FOLGA_REV=30,
    SC_LUCRO_MAIS=30, SC_DESVIO=20;

//====================================================================
//  ESTADO
//====================================================================
#define MTM_EMBEDDED
#include <MTMScalp/MTM_Sensei_Engine.mqh>
#include <MTMScalp/MTM_Feed.mqh>
#include <MTMScalp/MTM_Visual.mqh>
#include <MTMScalp/MTM_ScalpPanel.mqh>
#include <MTMScalp/MTMSC_Licenca.mqh>
#include <MTMScalp/MTMSC_Noticias.mqh>

CTrade   trade;
int      g_digits=5;
double   g_point=0.00001;
double   g_lotStep=0.01,g_lotMin=0.01,g_lotMax=100.0;
long     g_stopsLevel=0,g_freezeLevel=0;

datetime g_diaActual=0;
int      g_ciclosHoje=0;
double   g_saldoAbertura=0.0;
double   g_realizadoHoje=0.0;   // lucro/prejuizo REALIZADO por esta EA, hoje
bool     g_travadoHoje=false;
datetime g_ultimaVela=0;
string   g_travaoActual="";
int      g_viesActual=2;
int      g_scoreActual=0;

//--- volatilidade medida (em PONTOS, ja convertida) das duas ultimas velas
//    FECHADAS. A vela 0 esta a meio de se formar: usa-la era ler um ATR que
//    muda a cada tick e decidir com um numero que ainda nao existe.
//    (o handle e o `g_hATR` do motor — nao se cria um segundo)
double   g_atrPts=0.0, g_atrPtsAnt=0.0;
datetime g_atrBarra=0;

//--- cadeia de reversoes: quantas dispararam seguidas, qual a pendente que e a
//    reversao (para as contar sem depender de comentarios, que ha corretoras
//    que reescrevem), e a barra a partir da qual se volta a poder armar.
int      g_revSeguidas=0;
ulong    g_tkRev=0;
datetime g_barraEspera=0;

//====================================================================
//  UTILITARIOS
//====================================================================
double NP(const double p){ return(NormalizeDouble(p,g_digits)); }

double NLote(double v)
  {
   if(g_lotStep<=0) g_lotStep=0.01;
   v=MathFloor(v/g_lotStep+0.5)*g_lotStep;
   if(v<g_lotMin) v=g_lotMin;
   if(v>g_lotMax) v=g_lotMax;
   return(NormalizeDouble(v,2));
  }

/**
 * Distancia minima que a corretora aceita entre o preco e uma ordem ou stop.
 *
 * Ignorar isto e o erro 130/10016 — e num scalper com pendentes coladas ao
 * preco isso nao e um caso raro, e o caso normal.
 */
int DistMinima()
  {
   long m=MathMax(g_stopsLevel,g_freezeLevel);
   long sp=SymbolInfoInteger(_Symbol,SYMBOL_SPREAD);
   //--- a margem do spread evita ficar preso quando ele abre de repente
   return((int)MathMax(m+2,sp+2));
  }

/**
 * O valor pedido, ou o minimo da corretora se o pedido for apertado de mais.
 *
 * Avisa quando levanta. Pedir 30 pontos e ficar com 45 sem saber e trabalhar
 * as cegas: uma pessoa aperta o parametro, ve que nada muda, e aperta outra
 * vez — quando o que manda ja e o chao da corretora, nao o parametro.
 */
int PontosSeguros(const int pedido)
  {
   int min=DistMinima();
   if(pedido>=min) return(pedido);

   static int ultimoAviso=-1;
   if(min!=ultimoAviso)
     {
      ultimoAviso=min;
      PrintFormat("MTM Sensei Scalp: pediste %d pontos mas a corretora so aceita %d agora "
                  "(stops level %d, freeze %d, spread %d). A usar %d.",
                  pedido,min,(int)g_stopsLevel,(int)g_freezeLevel,
                  (int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD),min);
     }
   return(min);
  }

/**
 * ATR das duas ultimas velas fechadas, em pontos. Recalcula uma vez por vela.
 */
void AtrActualizar()
  {
   if(g_hATR==INVALID_HANDLE) return;
   datetime b=iTime(_Symbol,_Period,0);
   if(b==g_atrBarra && g_atrPts>0) return;

   double buf[];
   if(CopyBuffer(g_hATR,0,1,2,buf)<2) return;   // 1 e 2 = velas ja fechadas
   ArraySetAsSeries(buf,true);
   if(buf[0]<=0) return;

   g_atrBarra =b;
   g_atrPts   =buf[0]/g_point;
   g_atrPtsAnt=buf[1]/g_point;
  }

/**
 * A vela anda o suficiente para o ciclo se pagar?
 *
 * O ciclo custa o spread (sempre) e tem de cobrir a distancia da pendente ate
 * o preco lhe chegar. Se a amplitude tipica nao chega para as duas coisas com
 * folga, cada disparo e um pagamento ao broker disfarcado de negocio. E em
 * lateral e precisamente quando ele dispara mais vezes.
 */
bool VolatilidadeOK(const int dist)
  {
   if(SC_ATR_MIN_X<=0) return(true);
   if(g_atrPts<=0)   return(true);   // ainda sem leitura: nao se inventa um travao
   int sp=(int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD);
   return(g_atrPts>=SC_ATR_MIN_X*(dist+sp));
  }

/**
 * Distancia do trailing, em pontos, para AGORA.
 *
 * Um trailing fixo abaixo do spread e um trailing que o spread sozinho dispara:
 * o preco nao mexeu, o bid oscilou, e a posicao fechou. Por isso ha duas
 * ancoras — o ATR (quanto este simbolo anda) e um piso em multiplos do spread
 * (quanto e ruido) — e por cima delas o chao da corretora.
 */
int TrailPontos()
  {
   double t=(double)SC_TRAIL;
   if(SC_TRAIL_ATR_X>0 && g_atrPts>0) t=g_atrPts*SC_TRAIL_ATR_X;
   if(SC_TRAIL_MIN_SPR>0)
      t=MathMax(t,SymbolInfoInteger(_Symbol,SYMBOL_SPREAD)*SC_TRAIL_MIN_SPR);
   return(PontosSeguros((int)MathRound(t)));
  }

bool SpreadOK()
  {
   if(InpMaxSpreadPts<=0) return(true);
   return(SymbolInfoInteger(_Symbol,SYMBOL_SPREAD)<=InpMaxSpreadPts);
  }

bool HorarioOK()
  {
   if(!InpUsarHorario) return(true);
   datetime agora=TimeCurrent();
   MqlDateTime t; TimeToStruct(agora,t);
   int m=t.hour*60+t.min;
   int hi=(int)StringToInteger(StringSubstr(InpHoraInicio,0,2))*60+(int)StringToInteger(StringSubstr(InpHoraInicio,3,2));
   int hf=(int)StringToInteger(StringSubstr(InpHoraFim,0,2))*60+(int)StringToInteger(StringSubstr(InpHoraFim,3,2));
   if(hi==hf) return(true);
   if(hi<hf)  return(m>=hi && m<hf);
   return(m>=hi || m<hf);          // sessao que atravessa a meia-noite
  }

//====================================================================
//  POSICOES E PENDENTES DESTE EA
//====================================================================
/**
 * A posicao MAIS RECENTE desta EA, e quantas ha ao todo.
 *
 * "Mais recente" importa porque numa conta HEDGING a ordem de reversao abre
 * uma posicao nova sem fechar a anterior — as duas ficam abertas. A recente e
 * a que vale; as outras tem de ser fechadas (ver FecharOpostas).
 */
bool PosicaoAberta(ulong &ticket,int &dir,double &abertura,double &volume,double &sl,
                   int &quantas,bool &haContrarias)
  {
   quantas=0; ticket=0; haContrarias=false;
   datetime maisNova=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      datetime t=(datetime)PositionGetInteger(POSITION_TIME);
      if(ticket!=0 && t<=maisNova) continue;
      maisNova=t;
      ticket  =tk;
      dir     =(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY)?1:-1;
      abertura=PositionGetDouble(POSITION_PRICE_OPEN);
      volume  =PositionGetDouble(POSITION_VOLUME);
      sl      =PositionGetDouble(POSITION_SL);
     }
   //--- segunda passagem: quantas do lado da mais recente, e ha do outro?
   if(ticket!=0)
      for(int i=PositionsTotal()-1;i>=0;i--)
        {
         ulong tk=PositionGetTicket(i);
         if(tk==0) continue;
         if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
         if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
         int d=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY)?1:-1;
         if(d==dir) quantas++; else haContrarias=true;
        }
   return(ticket!=0);
  }

/**
 * Fecha todas as posicoes desta EA MENOS a indicada.
 *
 * E isto que torna a reversao numa reversao. Sem isto, em conta HEDGING a
 * pendente contraria abria a posicao oposta e a anterior FICAVA LA — sem
 * trailing (o gestor so via uma) e sem stop nenhum, a sangrar ate o limite do
 * dia a fechar a mercado. Foi de onde vieram as perdas de -19 USD num sistema
 * cuja reversao esta a 1,25 USD da entrada.
 */
void FecharOpostas(const int dir)
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      int d=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY)?1:-1;
      if(d==dir) continue;   // mesmo lado = e piramide, fica
      if(trade.PositionClose(tk))
         Print("MTM Sensei Scalp: posicao contraria fechada pela reversao");
     }
  }

/**
 * Poe a MESMA linha de stop em todas as posicoes deste EA.
 *
 * A linha e calculada a partir da posicao MAIS RECENTE — foi o que ficou
 * combinado: a piramide sobe, o stop sobe com ela, e quando o preco toca a
 * linha fecha tudo junto. As mais antigas entraram mais abaixo, portanto uma
 * linha puxada pela mais recente fecha-as com MAIS lucro, nunca com menos.
 *
 * So se mexe no stop de uma posicao quando a linha nova e melhor do que o que
 * ela ja tem. Nunca se piora um stop que ja esta colocado.
 */
int AplicarLinha(const double linha,const int dir)
  {
   int mexidas=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      int d=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY)?1:-1;
      if(d!=dir) continue;
      double sl=PositionGetDouble(POSITION_SL);
      bool melhor=(sl==0.0) || (dir>0 && linha>sl) || (dir<0 && linha<sl);
      if(melhor && trade.PositionModify(tk,linha,0.0)) mexidas++;
     }
   return(mexidas);
  }

/** Devolve o bilhete da pendente deste EA na direccao pedida, ou 0. */
ulong Pendente(const int dir)
  {
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong tk=OrderGetTicket(i);
      if(tk==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=_Symbol) continue;
      if(OrderGetInteger(ORDER_MAGIC)!=InpMagic) continue;
      ENUM_ORDER_TYPE t=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      if(dir>0 && t==ORDER_TYPE_BUY_STOP)  return(tk);
      if(dir<0 && t==ORDER_TYPE_SELL_STOP) return(tk);
     }
   return(0);
  }

void ApagarPendentes(const int dir=0)
  {
   for(int i=OrdersTotal()-1;i>=0;i--)
     {
      ulong tk=OrderGetTicket(i);
      if(tk==0) continue;
      if(OrderGetString(ORDER_SYMBOL)!=_Symbol) continue;
      if(OrderGetInteger(ORDER_MAGIC)!=InpMagic) continue;
      ENUM_ORDER_TYPE t=(ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      if(dir>0 && t!=ORDER_TYPE_BUY_STOP)  continue;
      if(dir<0 && t!=ORDER_TYPE_SELL_STOP) continue;
      trade.OrderDelete(tk);
     }
  }

void FecharTudo(const string porque)
  {
   //--- TODAS. A versao anterior fechava so a primeira que encontrava, por isso
   //    num dia com varias abertas ia fechando uma por tick — e as outras
   //    continuavam a correr sem gestao entretanto.
   int fechadas=0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      if(trade.PositionClose(tk)) fechadas++;
     }
   if(fechadas>0) PrintFormat("MTM Sensei Scalp: %d posicao(oes) fechada(s) - %s",fechadas,porque);
   ApagarPendentes();
  }

/** Lucro/prejuizo por realizar das posicoes DESTA EA (magic + simbolo). */
double LucroFlutuante()
  {
   double t=0.0;
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong tk=PositionGetTicket(i);
      if(tk==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic) continue;
      t+=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
     }
   return(t);
  }

//====================================================================
//  DIMENSIONAMENTO
//====================================================================
double Volume()
  {
   if((!g_loteModoPct)) return(NLote(g_lote));

   //--- Sem SL, a distancia de risco e ate a REVERSAO: e ela que fecha o lado
   //    errado, por isso e ela que define quanto se perde. Dimensionar por um
   //    stop que nao existe seria dimensionar por um numero inventado.
   double dist=(TrailPontos()+SC_FOLGA_REV)*g_point;
   if(dist<=0) return(NLote(g_lote));

   double tickVal=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   double tickSz =SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(tickVal<=0 || tickSz<=0) return(NLote(g_lote));

   double perdaPorLote=(dist/tickSz)*tickVal;
   if(perdaPorLote<=0) return(NLote(g_lote));

   double risco=AccountInfoDouble(ACCOUNT_BALANCE)*(g_riscoPct/100.0);
   return(NLote(risco/perdaPorLote));
  }

//====================================================================
//  VIES DO SENSEI
//  O motor ja calculou g_bullScore / g_bearScore (0-20 cada). Aqui so
//  se le — nao se recalcula nada, senao os dois lados divergiam.
//====================================================================
int Vies(int &score)
  {
   score=0;
   if(!true){ score=20; return(0); }   // 0 = arma os dois lados

   //--- `g_effMinScore` e o minimo EFECTIVO do motor: com o Sensei Otimizado
   //    ligado ele muda por simbolo e tempo grafico, e o `InpMinScore` do ecra
   //    deixa de ser o que vale. Ter aqui um limiar proprio era ter dois
   //    numeros a discordar sobre a mesma pergunta.
   if(g_bullScore>=g_effMinScore && g_bullScore>g_bearScore){ score=g_bullScore; return(1); }
   if(g_bearScore>=g_effMinScore && g_bearScore>g_bullScore){ score=g_bearScore; return(-1); }
   score=MathMax(g_bullScore,g_bearScore);
   return(2);                                   // 2 = indeciso, nao arma nada
  }

/**
 * Pode-se ABRIR a posicao contraria, ou so fechar a que esta?
 *
 * A reversao faz duas coisas ao mesmo tempo: fecha o lado errado (isso e
 * sempre preciso, e o unico stop que ha) e ABRE o lado oposto (isso e um trade
 * novo, e um trade novo precisa das mesmas razoes que qualquer outro). Tratar
 * as duas como uma so era abrir trades que nunca teriam sido armados de raiz.
 *
 * Quando isto devolve false a posicao NAO fica desprotegida: quem fecha passa
 * a ser um stop loss verdadeiro na mesma linha (ver Gerir).
 */
bool ReversaoPermitida(const int oposto,string &porque)
  {
   if(SC_MAX_REV_CADEIA>0 && g_revSeguidas>=SC_MAX_REV_CADEIA)
     {
      porque=StringFormat("%d reversoes seguidas (tecto %d) - so com sinal novo",
                          g_revSeguidas,SC_MAX_REV_CADEIA);
      return(false);
     }

   if(SC_REV_SO_COM_VIES)
     {
      int sc=0;
      int v=Vies(sc);
      if(g_inverter && (v==1 || v==-1)) v=-v;
      if((v==1 || v==-1) && v!=oposto)
        {
         porque="o Sensei aponta ao contrario da reversao";
         return(false);
        }
     }
   return(true);
  }

//====================================================================
//  ARMAR AS PENDENTES
//====================================================================
/**
 * Coloca ou REPOSICIONA a pendente de um lado.
 *
 * Reposicionar e o que faz isto trabalhar sozinho. Uma pendente GTC colocada a
 * 1,20 USD do preco fica onde foi posta: o preco anda 5 USD e a ordem passa a
 * estar a 6 de distancia — deixa de ter relacao com o mercado e o EA arma uma
 * vez e nao volta a fazer nada durante horas.
 *
 * Mas so se move numa direccao: quando o preco se AFASTA e a ordem fica longe
 * demais. Quando o preco se aproxima dela, fica quieta e deixa-se disparar. Uma
 * ordem que mantivesse sempre a mesma distancia fugia do preco e nunca enchia.
 */
void ArmarLado(const int dir,const double vol,const int d,const string com)
  {
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double base=(dir>0)?ask:bid;
   double alvo=(dir>0)? NP(base+d*g_point) : NP(base-d*g_point);

   ulong pend=Pendente(dir);

   if(pend==0)
     {
      datetime exp=(0>0)?(TimeCurrent()+0):0;
      ENUM_ORDER_TYPE_TIME tt=(0>0)?ORDER_TIME_SPECIFIED:ORDER_TIME_GTC;
      bool ok=(dir>0)? trade.BuyStop (vol,alvo,_Symbol,0,0,tt,exp,com)
                     : trade.SellStop(vol,alvo,_Symbol,0,0,tt,exp,com);
      if(!ok)
         PrintFormat("MTM Sensei Scalp: %s STOP recusado @ %s (erro %d)",
                     (dir>0?"BUY":"SELL"),DoubleToString(alvo,g_digits),trade.ResultRetcode());
      return;
     }

   if(!OrderSelect(pend)) return;
   double actual=OrderGetDouble(ORDER_PRICE_OPEN);

   //--- a quantos pontos esta a ordem do preco, agora
   double afastamento=(dir>0)? (actual-ask)/g_point : (bid-actual)/g_point;

   //--- so mexe quando ficou longe de mais; se o preco esta a chegar-lhe, quieta
   if(afastamento>d+SC_PASSO)
      trade.OrderModify(pend,alvo,0,0,ORDER_TIME_GTC,0);
  }

void Armar()
  {
   //--- estar liso e sem pendentes E o fim de uma cadeia. Chegar aqui ja passou
   //    pelo travao da espera no OnTick, portanto ha sinal novo: zera-se.
   if(g_revSeguidas>0)
     {
      PrintFormat("MTM Sensei Scalp: cadeia terminada (%d reversoes) - a comecar de novo.",
                  g_revSeguidas);
      g_revSeguidas=0;
      g_tkRev=0;
     }

   int score=0;
   int vies=Vies(score);
   g_viesActual=vies; g_scoreActual=score;   // o painel mostra o que o EA decidiu

   //--- inverter: o Sensei diz COMPRA e arma-se a VENDA. So mexe no lado
   //    escolhido; 0 (ambos) e 2 (indeciso) nao tem lado para inverter.
   if(g_inverter && (vies==1 || vies==-1)) vies=-vies;
   if(vies==2){ ApagarPendentes(); return; }

   //--- O vies escolheu um lado: o outro NAO pode ficar armado. Sem isto, uma
   //    passagem de compra para venda deixava as duas pendentes no mercado e o
   //    "o Sensei escolhe o lado" passava a ser um straddle por acidente.
   if(vies>0) ApagarPendentes(-1);
   if(vies<0) ApagarPendentes(1);

   int    d  =PontosSeguros(SC_DIST);
   double vol=Volume();
   string com=StringFormat("MTMScalp-%d",score);

   if(vies>=0) ArmarLado( 1,vol,d,com);
   if(vies<=0) ArmarLado(-1,vol,d,com);
  }

//====================================================================
//  GERIR A POSICAO ABERTA
//  Trailing + a ordem de reversao a segui-lo de perto.
//====================================================================
void Gerir(const ulong ticket,const int dir,const double abertura,const double volume,const double slActual)
  {
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double preco=(dir>0)?bid:ask;                       // preco a que se fecharia agora
   double lucroPts=(dir>0)?(preco-abertura)/g_point:(abertura-preco)/g_point;

   //--- o lado oposto fica sempre armado: e ele que apanha a reversao
   int oposto=-dir;

   //====================================================================
   //  O STOP NUNCA FICA PIOR QUE O BREAKEVEN.
   //
   //  E esta a regra que faz a coisa toda bater certo. A versao anterior
   //  punha o stop a `trail` pontos do PRECO — com lucro zero isso e o stop
   //  100 pontos ABAIXO da entrada, ou seja a arrancar em prejuizo. So
   //  chegava a breakeven quando o lucro ja fosse de 100 pontos.
   //
   //  Agora: mal a posicao fique positiva, o stop vai para o breakeven e a
   //  partir dai so sobe. `novoSL = o melhor dos dois` — nunca o pior.
   //
   //  Consequencia, e e o ponto todo: uma trade fechada PELO STOP nunca
   //  fecha a negativo. O unico caminho para uma perda e a ordem de
   //  reversao disparar antes de o breakeven ser alcancavel — que e
   //  exactamente o que o Ricardo disse: "o possivel SL e a linha do buy
   //  stop ou sell stop contrario".
   //====================================================================
   double be =(dir>0)? NP(abertura+SC_BE*g_point)
                     : NP(abertura-SC_BE*g_point);

   double novoSL=slActual;
   if(lucroPts>0)
     {
      int    t   =TrailPontos();
      double segue=(dir>0)? NP(preco-t*g_point) : NP(preco+t*g_point);

      //--- o melhor dos dois: o trailing quando ja vai a frente do BE,
      //    o BE enquanto o trailing ainda estaria atras dele
      double alvoSL=(dir>0)? MathMax(be,segue) : MathMin(be,segue);

      //--- a corretora nao aceita um stop colado ao preco. Enquanto o BE
      //    estiver dentro dessa zona morta, ainda nao da para o colocar —
      //    espera-se mais um bocado em vez de pedir e levar erro 130.
      int    d   =DistMinima();
      double tecto=(dir>0)? NP(preco-d*g_point) : NP(preco+d*g_point);
      bool   cabe=(dir>0)? (alvoSL<=tecto) : (alvoSL>=tecto);

      if(cabe)
        {
         //--- so mexe se ganhar pelo menos o passo; senao seria uma
         //    modificacao por tick, e a corretora recusa por excesso
         bool vale=(slActual==0.0)
                   || (dir>0 && alvoSL-slActual>=SC_PASSO*g_point)
                   || (dir<0 && slActual-alvoSL>=SC_PASSO*g_point);

         if(vale)
           {
            //--- a MESMA linha para toda a piramide, puxada pela mais recente
            int n=AplicarLinha(alvoSL,dir);
            if(n>0)
              {
               novoSL=alvoSL;
               bool emBE=(dir>0)? (alvoSL<=be+g_point/2) : (alvoSL>=be-g_point/2);
               PrintFormat("MTM Sensei Scalp: linha -> %s (%s | lucro %.0f pts | %d posicao%s)",
                           DoubleToString(alvoSL,g_digits),
                           (emBE?"breakeven":"a acompanhar"),lucroPts,n,(n==1?"":"es"));
              }
           }
        }
     }

   if(!true) return;

   //--- Onde fica a reversao: logo a seguir ao stop, para que quando o stop
   //    fecha o vencedor a contraria abra de imediato. Sem stop ainda (ainda
   //    nao arrancou o trailing), fica a distancia de trailing da abertura —
   //    e nesse caso e ELA o unico travao que existe.
   double base=(novoSL>0.0)? novoSL
                           : ((dir>0)? abertura-TrailPontos()*g_point
                                     : abertura+TrailPontos()*g_point);
   //====================================================================
   //  REVERTER CONTRA O SENSEI, OU DEPOIS DE UMA CADEIA, E ABRIR AS CEGAS.
   //
   //  Nestes dois casos nao se ARMA a contraria — mas tambem nao se fica sem
   //  rede: poe-se um STOP LOSS a serio na linha onde a reversao estaria. O
   //  efeito protector e o mesmo (a posicao fecha ali); o que desaparece e o
   //  trade novo que vinha agarrado a ele.
   //
   //  A linha usada e a `base` e nao a `base +/- folga`: a folga so existe
   //  para a reversao disparar DEPOIS do stop, e aqui nao ha reversao nenhuma
   //  para disparar. Usar a `base` tambem evita que a linha se afaste sozinha
   //  a cada tick — sem isto, o stop de agora vira a base do proximo calculo e
   //  a linha andava para tras uma folga de cada vez.
   //====================================================================
   string motivoRev="";
   if(!ReversaoPermitida(oposto,motivoRev))
     {
      ApagarPendentes(oposto);

      //--- a linha ja foi ultrapassada: fecha-se agora, a mao. Sem isto havia
      //    um buraco — a linha esta colada ao preco, a corretora nao aceita la
      //    um stop, e como tambem nao ha pendente de reversao nao sobrava nada
      //    para fechar a posicao. Ficaria aberta a correr contra, que e
      //    exactamente o que este EA nao pode deixar acontecer.
      if((dir>0 && bid<=base) || (dir<0 && ask>=base))
        {
         PrintFormat("MTM Sensei Scalp: linha %s ultrapassada e sem reversao (%s) - a fechar",
                     DoubleToString(NP(base),g_digits),motivoRev);
         if(trade.PositionClose(ticket)) ApagarPendentes();
         return;
        }

      int    dz   =DistMinima();
      double tecto=(dir>0)? NP(bid-dz*g_point) : NP(ask+dz*g_point);
      bool   cabeSL=(dir>0)? (base<=tecto) : (base>=tecto);

      if(cabeSL && AplicarLinha(NP(base),dir)>0)
         PrintFormat("MTM Sensei Scalp: sem reversao (%s) - stop colocado em %s",
                     motivoRev,DoubleToString(NP(base),g_digits));

      //--- o tecto da cadeia so conta a partir do momento em que TRAVA mesmo,
      //    e conta-se em barras: e a barra desta espera que o OnTick usa para
      //    saber quando ha sinal novo.
      if(SC_MAX_REV_CADEIA>0 && g_revSeguidas>=SC_MAX_REV_CADEIA)
         g_barraEspera=iTime(_Symbol,_Period,0);
      return;
     }

   double alvo=(oposto>0)? NP(base+SC_FOLGA_REV*g_point)
                         : NP(base-SC_FOLGA_REV*g_point);

   //====================================================================
   //  SE A LINHA DA REVERSAO JA FOI ULTRAPASSADA, FECHA. NAO PERSEGUE.
   //
   //  Uma buy stop tem de estar ACIMA do mercado. Quando o preco sobe acima
   //  do sitio onde a reversao devia estar, ha duas saidas: empurra-la para
   //  cima, ou aceitar que a linha foi rompida.
   //
   //  A versao anterior empurrava. Resultado no backtest: uma venda aberta a
   //  4461,80 com a reversao a 4463,05 — e a reversao a ser modificada para
   //  4487,11 / 4486,89 / 4486,69, sempre um passo a frente do preco, a
   //  perseguir. Quando finalmente disparou, a perda era de 25,13 USD numa
   //  linha que estava a 1,25 da entrada. Vinte vezes mais.
   //
   //  A linha da reversao E o stop — foi o que ficou combinado. Se o preco ja
   //  esta do outro lado dela, o stop foi rompido e a posicao fecha agora. O
   //  Armar() volta a montar o straddle no tick seguinte.
   //====================================================================
   int    d   =DistMinima();
   double lim =(oposto>0)? NP(ask+d*g_point) : NP(bid-d*g_point);

   //--- ROMPIDA = o preco passou MESMO a linha. Nada mais.
   //
   //    A primeira versao disto testava `alvo<lim`, que e outra coisa: e a
   //    linha estar mais perto do preco do que a corretora deixa colocar. Sao
   //    situacoes diferentes e tratei-as como uma so.
   //
   //    Com definicoes apertadas isso fechava TUDO no primeiro tick: a posicao
   //    abre no ask, o teste le o bid, e o spread sozinho (32 pontos) ja punha
   //    a linha dentro da zona morta. Resultado medido: 60 trades, 60 perdas,
   //    todas de -0,32 USD — exactamente o spread — e zero stops colocados.
   bool rompida=(oposto>0)? (ask>=alvo) : (bid<=alvo);
   if(rompida)
     {
      PrintFormat("MTM Sensei Scalp: linha de reversao rompida (%s vs mercado %s) - a fechar",
                  DoubleToString(alvo,g_digits),DoubleToString((oposto>0?ask:bid),g_digits));
      if(trade.PositionClose(ticket)) ApagarPendentes();
      return;
     }

   //--- nao foi rompida, mas esta perto de mais para a corretora aceitar:
   //    encosta-se ao minimo e espera. Nao se fecha nada por causa disto.
   if(oposto>0 && alvo<lim) alvo=lim;
   if(oposto<0 && alvo>lim) alvo=lim;

   ulong pend=Pendente(oposto);
   double vol=(volume>0)?NLote(volume):Volume();

   if(pend==0)
     {
      bool ok=(oposto>0)? trade.BuyStop (vol,alvo,_Symbol,0,0,ORDER_TIME_GTC,0,"MTMScalp-rev")
                        : trade.SellStop(vol,alvo,_Symbol,0,0,ORDER_TIME_GTC,0,"MTMScalp-rev");
      if(ok) g_tkRev=trade.ResultOrder();   // e por este bilhete que se conta a cadeia
      else   PrintFormat("MTM Sensei Scalp: reversao recusada @ %s (erro %d)",
                         DoubleToString(alvo,g_digits),trade.ResultRetcode());
      return;
     }

   //--- ja existe: so a move quando vale a pena, pela mesma razao do trailing
   if(OrderSelect(pend))
     {
      double actual=OrderGetDouble(ORDER_PRICE_OPEN);
      if(MathAbs(actual-alvo)>=SC_PASSO*g_point)
         trade.OrderModify(pend,alvo,0,0,ORDER_TIME_GTC,0);
     }
  }

//====================================================================
//  LIMITES DO DIA
//====================================================================
void ReporDia()
  {
   MqlDateTime t; TimeToStruct(TimeCurrent(),t);
   t.hour=0; t.min=0; t.sec=0;
   datetime hoje=StructToTime(t);
   if(hoje!=g_diaActual)
     {
      g_diaActual   =hoje;
      g_ciclosHoje  =0;
      g_realizadoHoje=0.0;
      g_saldoAbertura=AccountInfoDouble(ACCOUNT_BALANCE);
      g_travadoHoje =false;
      Print("MTM Sensei Scalp: dia novo - contadores a zero.");
     }
  }

/** true = pode continuar. Escreve sempre a razao quando trava. */
bool LimitesOK()
  {
   if(g_travadoHoje) return(false);

   if(InpMaxCiclosDia>0 && g_ciclosHoje>=InpMaxCiclosDia)
     {
      g_travadoHoje=true;
      PrintFormat("MTM Sensei Scalp: TRAVADO - %d ciclos hoje (limite %d). "
                  "Cada reversao paga o spread; sem tecto, um dia lateral come a conta as fatias.",
                  g_ciclosHoje,InpMaxCiclosDia);
      return(false);
     }

   if(InpPerdaMaxDiaPct>0 && g_saldoAbertura>0)
     {
      //--- SO o que ESTA EA fez: o realizado dela hoje mais o que tem aberto.
      //
      //    Media isto pelo EQUITY da conta, e foi um erro grosseiro: numa conta
      //    onde corre mais alguma coisa — e nesta corre o MTM Auto Sensei — a
      //    EA lia o prejuizo por realizar dos OUTROS como se fosse seu.
      //    Resultado real na conta do Ricardo: travou-se sozinha ao segundo de
      //    arrancar, "perda 72,93 / limite 2,99", sem nunca ter aberto uma
      //    ordem. Um travao que dispara por causa do vizinho e um travao
      //    partido.
      double perda=-(g_realizadoHoje+LucroFlutuante());
      double lim  =g_saldoAbertura*(InpPerdaMaxDiaPct/100.0);
      if(perda>=lim)
        {
         g_travadoHoje=true;
         PrintFormat("MTM Sensei Scalp: TRAVADO - perda do dia %.2f atingiu o limite %.2f (%.1f%%).",
                     perda,lim,InpPerdaMaxDiaPct);
         return(false);
        }
     }
   return(true);
  }

//====================================================================
//  CICLO DE VIDA
//====================================================================
int OnInit()
  {
   g_digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   g_point =SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   g_lotStep=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   g_lotMin =SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   g_lotMax =SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   if(g_lotStep<=0) g_lotStep=0.01;
   g_stopsLevel =SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL);
   g_freezeLevel=SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL);

   //--- AS DISTANCIAS SAO EM USD E CONVERTEM-SE AQUI.
   //    E este o passo que torna a EA indiferente a corretora: 0,150 USD sao
   //    150 pontos num ouro de 3 casas e 15 num de 2, e nos dois casos sao a
   //    MESMA distancia no preco. Escritas em pontos, seriam dez vezes uma ou
   //    outra coisa sem nada a avisar.
   SC_DIST      =(int)MathRound(SC_DIST_USD      /g_point);
   SC_TRAIL     =(int)MathRound(SC_TRAIL_USD     /g_point);
   SC_BE        =(int)MathRound(SC_BE_USD        /g_point);
   SC_PASSO     =(int)MathRound(SC_PASSO_USD     /g_point);
   SC_FOLGA_REV =(int)MathRound(SC_FOLGA_REV_USD /g_point);
   SC_LUCRO_MAIS=(int)MathRound(SC_LUCRO_MAIS_USD/g_point);
   SC_DESVIO    =(int)MathRound(SC_DESVIO_USD    /g_point);

   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(SC_DESVIO);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.LogLevel(LOG_LEVEL_ERRORS);

   if(MQLInfoInteger(MQL_TESTER))
      GlobalVariablesDeleteAll("MTMSC"+IntegerToString(InpMagic)+"_");

   if(MtmEngineInit()!=INIT_SUCCEEDED)
     {
      Print("MTM Sensei Scalp: falha a iniciar o motor Sensei");
      return(INIT_FAILED);
     }

   //--- os inputs decidem o estado INICIAL; a partir daqui manda o painel
   g_scalpLigado=InpEnableTrading;
   g_inverter   =false;
   g_loteModoPct=InpRiscoPorPct;
   g_lote       =InpLote;
   g_riscoPct   =InpRiscoPct;

   //--- Licenca. Sem ela a EA nao abre ordens (mas desenha, le e mostra tudo,
   //    para que quem esta a tratar da chave veja que o resto funciona).
   LicInit(InpLicenseKey,InpLicenseUrl);

   if(InpFiltroNoticias) NewsRefresh();
   if(!InpEnableTrading)
      Print("MTM Sensei Scalp: a arrancar PARADO. Carrega em INICIAR no painel.");

   //--- Em conta NETTING as duas pontas fundem-se numa so e a reversao deixa
   //    de ser reversao: passa a somar volume. Dizer isto agora poupa a
   //    descoberta a meio de um dia mau.
   if((ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE)!=ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
      Print("MTM Sensei Scalp: AVISO - conta NETTING. A ordem de reversao vai somar-se a posicao ",
            "em vez de a inverter. Este EA foi desenhado para conta HEDGING.");

   //--- o chao real deste simbolo: e ele que decide quao justo se pode ir,
   //    e e melhor sabe-lo no arranque do que a descobri-lo por tentativas
   //--- OS PONTOS NAO VALEM O MESMO EM TODA A PARTE.
   //
   //    Um "ponto" e a ultima casa decimal do preco. No XAUUSD.s da PU Prime
   //    ha 2 casas, logo 1 ponto = 0,01 USD e os 120 da distancia sao 1,20 USD.
   //    Numa corretora com 3 casas os MESMOS 120 valem 0,12 — dez vezes menos —
   //    e todas as distancias deste preset colapsam no chao da corretora sem
   //    que nada no ecra o diga. Levar um .set de uma corretora para outra sem
   //    ver isto e a maneira mais silenciosa de mudar a estrategia toda.
     {
      double tv=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
      double ts=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
      double vpp=(ts>0)? tv/ts*g_point : 0.0;          // USD por ponto, 1 lote
      PrintFormat("MTM Sensei Scalp: %s tem %d casas -> 1 ponto = %s no preco = %.4f %s a %.2f lotes. "
                  "Distancia %d pts = %s no preco. Trailing %d pts = %s. CONFERE ISTO ao mudar de corretora.",
                  _Symbol,g_digits,DoubleToString(g_point,g_digits),
                  vpp*g_lote,AccountInfoString(ACCOUNT_CURRENCY),g_lote,
                  SC_DIST,DoubleToString(SC_DIST*g_point,g_digits),
                  SC_TRAIL,DoubleToString(SC_TRAIL*g_point,g_digits));
     }

   PrintFormat("MTM Sensei Scalp: chao da corretora agora = %d pts "
               "(stops level %d | freeze %d | spread %d). Nao vale a pena pedir menos.",
               DistMinima(),(int)g_stopsLevel,(int)g_freezeLevel,
               (int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD));

   //--- O HORARIO E EM HORA DO SERVIDOR, NAO A TUA.
   //
   //    A PU Prime corre em GMT+2/+3 conforme a altura do ano, e Lisboa anda
   //    entre GMT+0 e +1: sao duas ou tres horas de diferenca que mudam com o
   //    calendario. Escrever a janela de Londres/NY em hora local e apanhar a
   //    sessao errada sem dar por isso. Por isso o EA diz aqui as duas horas —
   //    e uma linha de log que evita uma semana a operar a hora errada.
     {
      datetime srv=TimeCurrent(), gmt=TimeGMT(), loc=TimeLocal();
      int offSrv=(int)MathRound((double)(srv-gmt)/3600.0);
      int offLoc=(int)MathRound((double)(loc-gmt)/3600.0);
      PrintFormat("MTM Sensei Scalp: relogios -> servidor %s (GMT%+d) | tu %s (GMT%+d). "
                  "A janela %s-%s e HORA DO SERVIDOR = %02d:%02d-%02d:%02d na tua hora.",
                  TimeToString(srv,TIME_MINUTES),offSrv,
                  TimeToString(loc,TIME_MINUTES),offLoc,
                  InpHoraInicio,InpHoraFim,
                  (((int)StringToInteger(StringSubstr(InpHoraInicio,0,2))-offSrv+offLoc)+24)%24,
                  (int)StringToInteger(StringSubstr(InpHoraInicio,3,2)),
                  (((int)StringToInteger(StringSubstr(InpHoraFim,0,2))-offSrv+offLoc)+24)%24,
                  (int)StringToInteger(StringSubstr(InpHoraFim,3,2)));
     }

   PrintFormat("MTM Sensei Scalp iniciado | %s | dist %d pts | trailing %s | reversao %s | "
               "score minimo %d | stops level %d",
               _Symbol,SC_DIST,
               (SC_TRAIL_ATR_X>0?StringFormat("%.2f x ATR",SC_TRAIL_ATR_X)
                              :StringFormat("%d pts",SC_TRAIL)),
               (true?"ON":"OFF"),g_effMinScore,(int)g_stopsLevel);

   ReporDia();
   MtmFeed();
   VisualAttach();          // os mesmos plots do Sensei, no grafico deste EA
   if(InpPainel && MQLInfoInteger(MQL_OPTIMIZATION)==0)
     {
      ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,true);
      ScalpPanelBuild();
     }
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   LicDeinit();
   VisualDetach();
   ScalpPanelDestroy();
   ChartSetInteger(0,CHART_EVENT_MOUSE_MOVE,false);
   MtmEngineDeinit();
  }

void OnTick()
  {
   //--- o motor so precisa de recalcular quando fecha uma vela
   datetime vela=iTime(_Symbol,_Period,0);
   if(vela!=g_ultimaVela){ g_ultimaVela=vela; MtmFeed(); }
   AtrActualizar();

   ReporDia();
   LicTick(InpLicenseKey,InpLicenseUrl);
   if(InpFiltroNoticias) NewsRefresh();

   ulong tk=0; int dir=0; double ab=0,vol=0,sl=0; int quantas=0; bool contrarias=false;
   bool tem=PosicaoAberta(tk,dir,ab,vol,sl,quantas,contrarias);

   //--- a reversao disparou: fecham as do lado CONTRARIO. As do mesmo lado
   //    ficam — sao a piramide, nao sao sobras.
   if(contrarias) FecharOpostas(dir);

   //--- LIMITES DO DIA PRIMEIRO, E FECHAM TUDO.
   //
   //    A versao anterior so deixava de ARMAR quando o limite batia, e deixava
   //    o Gerir() continuar — mas e o Gerir() que coloca a ordem de reversao.
   //    Resultado: a cadeia nunca parava. Posicao fecha, reversao abre outra,
   //    reversao nova, e outra vez. Um backtest de 25 dias com tecto de 20
   //    ciclos/dia deu MIL por dia, e o `if(!tem) ApagarPendentes()` nunca
   //    chegava a correr porque havia sempre posicao aberta.
   //
   //    Num EA sem stop loss, este e O travao. Um travao que nao trava e pior
   //    do que nenhum, porque da a sensacao de que ha rede.
   if(!LimitesOK())
     {
      if(tem || OrdersTotal()>0) FecharTudo("limite do dia atingido");
      return;
     }

   //--- gerir o que esta aberto vem antes de armar: uma posicao aberta tem de
   //    continuar a ser cuidada mesmo fora de horario
   if(tem) Gerir(tk,dir,ab,vol,sl);

   if(InpUsarHorario && true && !HorarioOK())
     {
      if(tem || OrdersTotal()>0) FecharTudo("fim do horario");
      return;
     }

   int distArmar=PontosSeguros(SC_DIST);

   //--- NOTICIAS ANTES DE TUDO, e podem FECHAR e nao so travar.
   //
   //    Numa EA sem stop loss, estar dentro de uma NFP nao e "um trade que
   //    corre mal": e a unica situacao em que a ordem de reversao — o unico
   //    travao que existe — pode ser preenchida a metros de onde esta
   //    desenhada. Por isso este travao vem antes do de horario e do de
   //    spread, e por defeito tira a EA do mercado em vez de a deixar la
   //    parada a ver.
   if(InpFiltroNoticias && NoticiasTravam(InpNoticiasFecham))
     {
      g_travaoActual="noticias: "+g_newsCurrent;
      if(!tem) ApagarPendentes();
      PainelRefrescar();
      return;
     }

   string bloqueio="";
   if(!g_licOk)                 bloqueio="licenca: "+g_licMsg;
   else if(!g_scalpLigado)      bloqueio="parado no painel";
   else if(!HorarioOK())        bloqueio="fora do horario";
   else if(!SpreadOK())
      bloqueio=StringFormat("spread %d acima do limite %d",
                            (int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD),InpMaxSpreadPts);
   //--- cadeia esgotada: espera-se pela vela seguinte, que traz leitura nova do
   //    motor. Enquanto for a MESMA vela, o "sinal novo" seria o mesmo sinal.
   else if(!tem && SC_MAX_REV_CADEIA>0 && g_revSeguidas>=SC_MAX_REV_CADEIA
           && iTime(_Symbol,_Period,0)<=g_barraEspera)
      bloqueio="cadeia esgotada - a espera de sinal novo";
   else if(!VolatilidadeOK(distArmar))
      bloqueio=StringFormat("volatilidade curta (ATR %.0f pts < %.1f x %d)",
                            g_atrPts,SC_ATR_MIN_X,
                            distArmar+(int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD));

   g_travaoActual=bloqueio;
   if(bloqueio!="")
     {
      //--- travado: nao arma nada de novo, mas nao mexe no que ja esta aberto
      static string ultimo=""; static datetime quando=0;
      if(bloqueio!=ultimo || TimeCurrent()-quando>300)
        { ultimo=bloqueio; quando=TimeCurrent(); Print("MTM Sensei Scalp: sem armar - ",bloqueio); }
      if(!tem) ApagarPendentes();
      return;
     }

   if(!tem) Armar();
   else     Piramide(tk,dir,ab,quantas);
   PainelRefrescar();
  }

/**
 * Empilha mais uma posicao do MESMO lado enquanto a coisa corre bem.
 *
 * Condicoes, todas necessarias: a mais recente ja esta positiva o suficiente,
 * ainda ha espaco no tecto, e a pendente desse lado nao esta armada. So se
 * acrescenta a ganhar — nunca se acrescenta a perder, que e a diferenca entre
 * uma piramide e um martingale.
 */
void Piramide(const ulong ticket,const int dir,const double abertura,const int quantas)
  {
   if(SC_MAX_PIRAMIDE<=1 || quantas>=SC_MAX_PIRAMIDE) return;

   double preco=(dir>0)? SymbolInfoDouble(_Symbol,SYMBOL_BID)
                       : SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double lucroPts=(dir>0)?(preco-abertura)/g_point:(abertura-preco)/g_point;

   //--- Empilhar so faz sentido num movimento que esta a ABRIR. Dentro de uma
   //    range, acrescentar transforma uma perda pequena em tres — e a range e
   //    exactamente onde a posicao passa mais tempo ligeiramente positiva, que
   //    era a unica condicao da versao anterior.
   if(SC_PIR_ATR_X>0 && g_atrPts>0)
     {
      if(lucroPts<SC_PIR_ATR_X*g_atrPts) return;
      if(g_atrPts<=g_atrPtsAnt)        return;   // volatilidade a encolher
     }
   else if(lucroPts<SC_LUCRO_MAIS) return;

   if(Pendente(dir)!=0) return;        // ja esta armada, deixa disparar
   ArmarLado(dir,Volume(),PontosSeguros(SC_DIST),"MTMScalp-pir");
  }

//====================================================================
//  PAINEL
//====================================================================
void PainelRefrescar()
  {
   if(!InpPainel || MQLInfoInteger(MQL_OPTIMIZATION)!=0) return;
   double resultado=g_realizadoHoje+LucroFlutuante();   // só o desta EA
   ScalpPanelRefresh(g_viesActual,g_scoreActual,g_ciclosHoje,InpMaxCiclosDia,
                     resultado,DistMinima(),g_travaoActual,
                     (InpFiltroNoticias? NoticiasProxima() : "filtro desligado"),
                     (g_licOk? ("licenca "+g_licPlano+" activa") : g_licMsg),
                     g_licOk);
  }

void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   if(id==CHARTEVENT_OBJECT_CLICK)
     {
      if(sparam==SP"go")
        {
         //--- e AQUI que se liga a execucao. A variavel que este botao muda e a
         //    mesma que o OnTick le — nao ha uma segunda a discordar dela.
         g_scalpLigado=!g_scalpLigado;
         Print("MTM Sensei Scalp: ",(g_scalpLigado?"INICIADO":"PARADO")," no painel");
         if(!g_scalpLigado) FecharTudo("parado no painel");
         ObjectSetInteger(0,SP"go",OBJPROP_STATE,false);
         PainelRefrescar();
        }
      else if(sparam==SP"inv")
        {
         g_inverter=!g_inverter;
         Print("MTM Sensei Scalp: lado ",(g_inverter?"INVERTIDO":"NORMAL")," no painel");
         FecharTudo("mudanca de lado");   // o que esta aberto foi armado pela regra antiga
         ObjectSetInteger(0,SP"inv",OBJPROP_STATE,false);
         PainelRefrescar();
        }
      else if(sparam==SP"lot")
        {
         //--- trocar de modo com posicoes abertas nao mexe nas que ja estao —
         //    o lote so vale para a PROXIMA ordem. Dizer isto no log evita a
         //    pergunta "mudei e nao aconteceu nada".
         g_loteModoPct=!g_loteModoPct;
         PrintFormat("MTM Sensei Scalp: dimensionamento -> %s (vale para as ordens seguintes)",
                     (g_loteModoPct? StringFormat("risco %.1f%% do saldo",g_riscoPct)
                                   : StringFormat("lote fixo %.2f",g_lote)));
         ObjectSetInteger(0,SP"lot",OBJPROP_STATE,false);
         PainelRefrescar();
        }
      else if(sparam==SP"lm" || sparam==SP"lp")
        {
         ScalpPanelLote(sparam==SP"lp"? +1 : -1);
         ObjectSetInteger(0,sparam,OBJPROP_STATE,false);
         PainelRefrescar();
        }
      else if(sparam==SP"kil")
        {
         FecharTudo("botao FECHAR TUDO");
         ObjectSetInteger(0,SP"kil",OBJPROP_STATE,false);
         PainelRefrescar();
        }
      return;
     }

   //--- arrastar pela barra de titulo
   if(id==CHARTEVENT_MOUSE_MOVE)
     {
      static bool  agarrado=false;
      static int   px=0,py=0;
      int    x=(int)lparam, y=(int)dparam;
      bool   botao=((int)StringToInteger(sparam)&1)==1;
      int    hx=g_spX, hy=g_spY;
      bool   naBarra=(x>=hx && x<=hx+232 && y>=hy && y<=hy+26);

      if(botao && !agarrado && naBarra){ agarrado=true; px=x; py=y; }
      else if(!botao) agarrado=false;
      else if(agarrado){ ScalpPanelShift(x-px,y-py); px=x; py=y; }
     }
  }

//+------------------------------------------------------------------+
//| Conta os ciclos. Um ciclo = uma posicao fechada.                  |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &req,
                        const MqlTradeResult &res)
  {
   if(trans.type!=TRADE_TRANSACTION_DEAL_ADD) return;
   if(trans.symbol!=_Symbol) return;
   if(!HistoryDealSelect(trans.deal)) return;
   if(HistoryDealGetInteger(trans.deal,DEAL_MAGIC)!=InpMagic) return;

   //--- entrou uma posicao pela ordem que era a reversao: a cadeia cresceu.
   //    Conta-se pelo BILHETE da ordem e nao pelo comentario porque ha
   //    corretoras que reescrevem comentarios e ficariamos sem contador.
   if(HistoryDealGetInteger(trans.deal,DEAL_ENTRY)==DEAL_ENTRY_IN)
     {
      //--- A COMISSAO DA ABERTURA TAMBEM E DINHEIRO.
      //
      //    Numa conta ECN a comissao e cobrada nas DUAS pontas. Esta contagem
      //    so somava a do fecho, por isso metade do custo desaparecia: num
      //    teste de 1666 ciclos deu 83,30 USD a menos, 8% do resultado. E nao
      //    era so cosmetico — o `g_realizadoHoje` alimenta o travao de perda
      //    diaria, logo o travao via menos prejuizo do que havia e disparava
      //    tarde. Num EA sem stop loss, um travao optimista e o pior tipo.
      g_realizadoHoje+=HistoryDealGetDouble(trans.deal,DEAL_COMMISSION);

      if(g_tkRev!=0 && trans.order==g_tkRev)
        {
         g_revSeguidas++;
         g_tkRev=0;
         PrintFormat("MTM Sensei Scalp: reversao %d desta cadeia (tecto %d).",
                     g_revSeguidas,SC_MAX_REV_CADEIA);
        }
      return;
     }

   if(HistoryDealGetInteger(trans.deal,DEAL_ENTRY)!=DEAL_ENTRY_OUT) return;

   g_ciclosHoje++;
   double lucro=HistoryDealGetDouble(trans.deal,DEAL_PROFIT)
               +HistoryDealGetDouble(trans.deal,DEAL_SWAP)
               +HistoryDealGetDouble(trans.deal,DEAL_COMMISSION);
   g_realizadoHoje+=lucro;
   PrintFormat("MTM Sensei Scalp: ciclo %d fechado | %.2f | dia %+.2f %s",
               g_ciclosHoje,lucro,g_realizadoHoje,AccountInfoString(ACCOUNT_CURRENCY));
  }
//+------------------------------------------------------------------+
