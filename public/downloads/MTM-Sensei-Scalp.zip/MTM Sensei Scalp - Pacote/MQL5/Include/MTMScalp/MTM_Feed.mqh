//+------------------------------------------------------------------+
//|                                               MTM_Feed.mqh       |
//|  Propriedade intelectual de RicardoGarciaPT / MoreThanMoney      |
//|                                                                  |
//|  Alimentacao do motor Sensei: espelha as velas do grafico em     |
//|  arrays proprios e chama o MtmEngineCalculate.                   |
//|                                                                  |
//|  Vive num include partilhado, e nao copiado dentro de cada EA,   |
//|  porque ha mais do que um EA a correr o mesmo motor. Duas copias  |
//|  disto divergiam no dia em que uma fosse corrigida — e este       |
//|  ficheiro ja teve um bug que so aparecia quando o historico vinha |
//|  curto (redimensionava antes de saber se a copia tinha corrido    |
//|  bem, e ficava preso num espelho vazio, em silencio).            |
//|                                                                  |
//|  QUEM INCLUI ISTO TEM DE DEFINIR:                                 |
//|    SC_ENGINE_BARS  — quantas barras o motor analisa                |
//|  e incluir o MTM_Sensei_Engine.mqh ANTES.                        |
//+------------------------------------------------------------------+
//  ── PORQUE E QUE ISTO E UMA COPIA ────────────────────────────────
//  A arvore MTMScalp/ existe para o MTM_Sensei_Scalp — ferramenta de
//  casa, sem licenca, em experimentacao constante — nao poder mexer no
//  MTM_Sensei_AllInOne, que e o produto que se vende.
//
//  Ja aconteceu: partilhar estes ficheiros deixou o pacote do cliente
//  sem dois includes e a nao compilar. A duplicacao e o preco de o
//  produto ficar quieto enquanto se experimenta ao lado.
//
//  QUEM MEXER AQUI: isto NAO chega ao AllInOne. Se a correccao servir
//  aos dois, tem de ser feita duas vezes, de proposito.

#ifndef MTMSC_FEED_MQH
#define MTMSC_FEED_MQH

//--- Quantas barras o motor analisa. Era um input; deixou de o ser quando a
//    Scalp passou a produto — mudar isto so muda quanto tempo demora a
//    arrancar, e 3000 barras chegam a qualquer leitura que o Sensei faca.
#define SC_ENGINE_BARS 3000

//====================================================================
//  ALIMENTACAO DO MOTOR
//  Espelha as velas do grafico em arrays proprios e chama o motor.
//  A ancora mantem os indices estaveis entre chamadas (o motor guarda
//  estado por barra, por isso os indices NAO podem escorregar).
//====================================================================
datetime EmTime[];
double   EmO[],EmH[],EmL[],EmC[];
long     EmV[];
int      EmSp[];
datetime g_emAnchor=0;
int      g_emPrev=0;

//--- copia as ultimas "count" velas para o fim do espelho.
//    Devolve quantas conseguiu; NAO falha so porque veio menos do que se pediu.
int EmCopyTail(const int total,const int count)
  {
   datetime tt[]; double oo[],hh[],ll[],cc[]; long vv[];
   ArraySetAsSeries(tt,true); ArraySetAsSeries(oo,true); ArraySetAsSeries(hh,true);
   ArraySetAsSeries(ll,true); ArraySetAsSeries(cc,true); ArraySetAsSeries(vv,true);
   int g=CopyTime(_Symbol,_Period,0,count,tt);
   if(g<=0) return(0);
   int g2=CopyOpen (_Symbol,_Period,0,g,oo); if(g2<g) g=g2;
   g2=CopyHigh     (_Symbol,_Period,0,g,hh); if(g2<g) g=g2;
   g2=CopyLow      (_Symbol,_Period,0,g,ll); if(g2<g) g=g2;
   g2=CopyClose    (_Symbol,_Period,0,g,cc); if(g2<g) g=g2;
   g2=CopyTickVolume(_Symbol,_Period,0,g,vv);if(g2<g) g=g2;
   if(g<=0) return(0);
   for(int k=0;k<g;k++)
     {
      int i=total-1-k;
      if(i<0) break;
      EmTime[i]=tt[k]; EmO[i]=oo[k]; EmH[i]=hh[k];
      EmL[i]=ll[k];    EmC[i]=cc[k]; EmV[i]=vv[k]; EmSp[i]=0;
     }
   return(g);
  }

void EmResize(const int n)
  {
   ArrayResize(EmTime,n); ArrayResize(EmO,n); ArrayResize(EmH,n);
   ArrayResize(EmL,n);    ArrayResize(EmC,n); ArrayResize(EmV,n);
   ArrayResize(EmSp,n);
  }

int  g_emFails=0;
bool g_emWarned=false;

int MtmFeed()
  {
   int avail=Bars(_Symbol,_Period);
   if(avail<700) return(0);

   int have =ArraySize(EmTime);
   int total=(g_emAnchor>0)?Bars(_Symbol,_Period,g_emAnchor,TimeCurrent()):0;
   //--- reancorar quando nao ha espelho, quando ele encolheu, ou quando cresceu demais
   bool full=(have==0 || g_emAnchor==0 || total<have || total>SC_ENGINE_BARS*2);

   if(full)
     {
      int want=MathMin(avail,SC_ENGINE_BARS);
      EmResize(want);
      int got=EmCopyTail(want,want);
      if(got<650)
        {
         //--- nao consegui historico suficiente: fica com o espelho anterior
         //    e volta a tentar no proximo tick, em vez de morrer em silencio
         g_emFails++;
         if(g_emFails==5 && !g_emWarned)
           {
            g_emWarned=true;
            PrintFormat("MTM Sensei: sem historico suficiente para o motor (pedidas %d velas, vieram %d). "
                        "Reduz SC_ENGINE_BARS ou espera que o historico carregue.",want,got);
           }
         EmResize(have);
         return(0);
        }
      //--- ficou so com o que veio mesmo
      if(got<want)
        {
         EmResize(got);
         EmCopyTail(got,got);
        }
      g_emFails=0; g_emWarned=false;
      g_emAnchor=EmTime[0];
      g_emPrev=MtmEngineCalculate(ArraySize(EmTime),0,EmTime,EmO,EmH,EmL,EmC,EmV,EmV,EmSp);
      return(ArraySize(EmTime));
     }

   if(total>have)
     {
      EmResize(total);
      int k=total-have+2; if(k>total) k=total;
      if(EmCopyTail(total,k)<=0){ EmResize(have); return(0); }
     }
   else if(EmCopyTail(total,2)<=0) return(0);   // so a vela em formacao mudou

   g_emPrev=MtmEngineCalculate(total,g_emPrev,EmTime,EmO,EmH,EmL,EmC,EmV,EmV,EmSp);
   return(total);
  }

#endif // MTMSC_FEED_MQH
