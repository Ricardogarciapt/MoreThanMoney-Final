//+------------------------------------------------------------------+
//|                                        MTM_Sensei_Engine.mqh     |
//|  Motor partilhado do MTM Sensei v3.                               |
//|  Definir MTM_VISUAL antes do include expoe os inputs visuais.     |
//|  Sem esse define o indicador fica com 44 inputs, dentro do limite  |
//|  de 64 parametros que o iCustom impoe.                            |
//|  Propriedade de RicardoGarciaPT / MoreThanMoney.                  |
//+------------------------------------------------------------------+
#include <MTMScalp/MTM_Sensei_Defs.mqh>

//====================================================================
//  INPUTS - BLOCO DE LOGICA (posicoes 1..44 para o iCustom do EA)
//====================================================================
//input group                   "=== ESTILO DE TRADING ==="
const bool             InpAutoOptimize = true;          // 1  Sensei Otimizado (auto por simbolo x TF)
//--- MEDIDO: STYLE_SCALP rende +2444,19 e STYLE_AGRESSIVO +2266,62 no mesmo
//    periodo (XAUUSD M5, 13/05-09/09/2026, janela 13-17). O AGRESSIVO era o
//    que estava nos testes antigos por acaso, nao por escolha. Fica o SCALP,
//    que alem de melhor e o que o nome do produto promete.
const ENUM_MTM_STYLE     InpStyle = STYLE_SCALP;   // 2  Estilo de Trading
const int              InpMinScore     = 12;            // 3  Confirmacoes minimas (Personalizado)
const int              InpCooldown     = 5;             // 4  Cooldown em barras (Personalizado)

//input group                   "=== NUCLEO ==="
const int              InpLengthPOC    = 14;            // 5  Periodo do POC
const int              InpAtrPeriod    = 14;            // 6  Periodo ATR

//input group                   "=== FILTROS DE QUALIDADE ==="
const bool             InpUseHTF       = true;          // 7  Filtro de tendencia HTF
const ENUM_TIMEFRAMES  InpHTF          = PERIOD_H4;     // 8  Timeframe HTF
const int              InpHtfEmaLen    = 200;           // 9  EMA do HTF
const bool             InpHtfClosedBar = true;          // 10 HTF so com barra fechada (anti-repaint)
const bool             InpUseSession   = false;         // 11 Filtro de sessao
const string           InpSessStart    = "00:00";       // 12 Sessao - inicio (HH:MM)
const string           InpSessEnd      = "24:00";       // 13 Sessao - fim (HH:MM)
const bool             InpUseChop      = true;          // 14 Anti-chop (ADX minimo)
const double           InpAdxChopMin   = 15.0;          // 15 ADX minimo
const bool             InpConfirmClose = true;          // 16 Apenas fecho de vela

//input group                   "=== VIES DE LADO (auditoria) ==="
const bool             InpAllowBuy     = true;          // 17 Permitir COMPRAS
const bool             InpAllowSell    = true;          // 18 Permitir VENDAS
const int              InpSellExtra    = 3;             // 19 Score extra exigido p/ VENDA
const bool             InpStrictAuto   = false;         // 20 So operar setups validados

//input group                   "=== MODO DE FASE ==="
const ENUM_MTM_PHASE   InpPhaseMode    = PHASE_MOMENTUM;// 21 Modo de fase (Personalizado)
const int              InpMomCount     = 9;             // 22 Contagem setup Momentum
const int              InpExhCount     = 13;            // 23 Contagem countdown Exaustao

//input group                   "=== ORDER FLOW ==="
const bool             InpUseLTFOF     = true;          // 24 Delta real via timeframe inferior
const ENUM_TIMEFRAMES  InpLTF          = PERIOD_M1;     // 25 Timeframe do order flow
const double           InpOfImbThr     = 0.25;          // 26 Limiar de imbalance (0-1)
const int              InpOfMaxBars    = 500;           // 27 Barras com delta real (resto = proxy)

//input group                   "=== SENSEI BANDS ==="
const int              InpSenseiLen    = 89;            // 28 Comprimento da banda
const ENUM_MTM_BAND    InpSenseiType   = BAND_ACTIVE;   // 29 Modo da cloud

//input group                   "=== GESTAO DE RISCO ==="
const ENUM_MTM_RISK    InpRiskMode     = RISK_ATR;      // 30 Modo de risco
const double           InpSlMult       = 1.5;           // 31 Multiplicador SL (x ATR)
const double           InpSlPct        = 0.5;           // 32 SL em % (modo percentagem)
const double           InpTP1RR        = 1.5;           // 33 Exit 1 (1:X)
const double           InpTP2RR        = 2.5;           // 34 Exit 2 (1:X)
const double           InpTP3RR        = 4.0;           // 35 Exit 3 (1:X)
const double           InpTP4RR        = 6.0;           // 36 Exit 4 (1:X)



//input group                   "=== BREAKEVEN ==="
const ENUM_MTM_BE      InpBeMode       = BE_EXIT1;      // 39 Mover SL para BE em
const double           InpBePoints     = 10.0;          // 40 Pontos (modo Pontos)


//input group                   "=== SMC / ESTRUTURA ==="
const int              InpSmcLen       = 50;            // 42 CHoCH period
const int              InpSmcShortLen  = 3;             // 43 IDM period
const bool             InpDynLevels    = false;         // 44 Niveis dinamicos

//====================================================================
//  INPUTS - BLOCO VISUAL
//  (so existem como inputs na versao visual; na "core" sao constantes,
//   para o indicador caber no limite de 64 parametros do iCustom)
//====================================================================
#ifdef MTM_VISUAL
//input group                   "=== TEMA E EXIBICAO ==="
const ENUM_MTM_THEME   InpTheme      = TH_LIGHT;     // Tema (Light = fundo branco)
const ENUM_MTM_DISPLAY InpSignalDisp = DISP_ACTIVE;  // Sinais: so o ativo ou o historico
const bool   InpShowDEMA     = true;   // DEMAs 15/50/238
const bool   InpShowPOC      = true;   // POC
const bool   InpShowBands    = true;   // Banda 1 sigma
const bool   InpShowCloud    = true;   // Cloud
const bool   InpShowExits    = true;   // Linhas dos Exits E1-E4
const bool   InpShowTradeBox = true;   // Niveis da trade ativa (Entry/SL/Exits)
const bool   InpAllowDrag    = true;   // Poder arrastar SL e Exits no grafico
const bool   InpShowStruct   = true;   // Estrutura SMC (CHoCH / BOS / IDM / sweeps)
const bool   InpShowOB       = true;   // Order blocks
const bool   InpShowMarks    = true;   // Marcas de fase, swings e etiqueta de score
//input group                   "=== ALERTAS ==="
const bool   InpAlertPopup   = false;  // Popup no sinal
const bool   InpAlertPush    = false;  // Push para o telemovel
const bool   InpAlertSound   = false;  // Som no sinal
#else
const ENUM_MTM_THEME   InpTheme      = TH_LIGHT;
const ENUM_MTM_DISPLAY InpSignalDisp = DISP_ACTIVE;
const bool InpShowDEMA=true;   const bool InpShowPOC=true;
const bool InpShowBands=true;  const bool InpShowCloud=true;
const bool InpShowExits=true;  const bool InpShowTradeBox=true;
const bool InpAllowDrag=true;  const bool InpShowStruct=true;
const bool InpShowOB=true;     const bool InpShowMarks=true;
const bool InpAlertPopup=false;const bool InpAlertPush=false;
const bool InpAlertSound=false;
#endif

//--- fixos: nunca precisaram de ser inputs (o tema ja manda nas cores)
const string InpSoundFile     = "alert.wav";
const bool   InpDragResetNew  = true;
const int    InpStructBars    = 400;
const bool   InpShowConfPanel = false;
const bool   InpShowRules     = false;
const bool   InpShowTrdPanel  = false;
const color  InpSenseiBull    = C'124,58,237';
const color  InpSenseiBear    = C'55,65,81';
const color  InpBullCss       = C'8,153,129';
const color  InpBearCss       = C'255,82,82';
const color  InpIdmCss        = clrGray;
const color  InpSweepCss      = clrGray;


const ENUM_MTM_TRAIL InpTrailMode = TRAIL_OFF;

const double InpTrailMult = 1.5;

const bool InpBeCompletes = false;

//====================================================================
//  BUFFERS
//====================================================================
double BufD15[],BufD50[],BufD238[],BufPOC[],BufBU[],BufBL[],BufCF[],BufCS[];
double BufFillA[],BufFillB[];
double BufArrUp[],BufArrDn[];
double BufMomB[],BufMomS[],BufExhB[],BufExhS[];
double BufSwHi[],BufSwLo[];
double BufSigO[],BufSigH[],BufSigL[],BufSigC[],BufSigCol[];
double BufSignal[],BufEntry[],BufSL[],BufTP1[],BufTP2[],BufTP3[],BufTP4[];
double BufScore[],BufType[],BufATR[];

//====================================================================
//  HANDLES E CACHES
//====================================================================
int    g_hD15=INVALID_HANDLE,g_hD50=INVALID_HANDLE,g_hD238=INVALID_HANDLE;
int    g_hATR=INVALID_HANDLE,g_hRSI=INVALID_HANDLE,g_hADX=INVALID_HANDLE;
int    g_hSMA=INVALID_HANDLE,g_hSTD=INVALID_HANDLE;
int    g_hEMAF=INVALID_HANDLE,g_hEMAS=INVALID_HANDLE,g_hHTF=INVALID_HANDLE;

double   g_d15[],g_d50[],g_d238[],g_atr[],g_rsi[],g_adx[],g_sma[],g_std[],g_emaF[],g_emaS[];
double   g_volMA[],g_atrMA[],g_htfEma[];
double   g_ltfUp[],g_ltfDn[];
int      g_ltfSz[];
uchar    g_ltfDone[];

double   g_htfVals[];      // cache do EMA do HTF
datetime g_htfTimes[];     // tempos das barras do HTF
int      g_htfCount=0;

//====================================================================
//  PARAMETROS EFETIVOS (resolvidos no OnInit)
//====================================================================
bool            g_autoOn        = false;
bool            g_autoValid     = false;
int             g_effMinScore   = 12;
int             g_effCooldown   = 5;
double          g_effAdx        = 18.0;
double          g_actSlMult     = 1.5;
ENUM_MTM_PHASE  g_phaseMode     = PHASE_MOMENTUM;
ENUM_MTM_BE     g_effBe         = BE_EXIT1;
double          g_rr1=1.5,g_rr2=2.5,g_rr3=4.0,g_rr4=6.0;
double          g_pipUnit       = 0.0001;
double          g_tickSize      = 0.00001;
int             g_senseiFastLen = 34;
int             g_warmup        = 600;
string          g_prefix        = "MTMS_";

//====================================================================
//  ESTADO (portado das variaveis "var" do Pine)
//====================================================================
struct SwingState
  {
   int      os;
   int      topx;
   int      btmx;
  };

struct SState
  {
   //--- swings
   SwingState swLong;
   SwingState swShort;
   //--- momentum / exaustao
   int      buySetup,sellSetup,buyCD,sellCD;
   bool     buyCDact,sellCDact;
   int      lastPhaseBuy,lastPhaseSell;
   //--- market structure
   int      os_ms;
   bool     top_crossed,btm_crossed;
   double   max_ms,min_ms;
   int      max_x1,min_x1;
   double   topy,btmy;
   bool     hasTopy,hasBtmy;
   double   stopy,sbtmy;
   bool     hasStopy,hasSbtmy;
   bool     stop_crossed,sbtm_crossed;
   int      choch_bull_bar,choch_bear_bar,bos_bull_bar,bos_bear_bar;
   //--- order blocks
   double   obBullTop,obBullBot,obBearTop,obBearBot;
   int      obBullBar,obBearBar;
   //--- POC
   double   pocPrice,pocVol;
   //--- sinal
   int      lastSigBar;
   double   fixEntry,fixSL,fixTP1,fixTP2,fixTP3,fixTP4,fixSlPips;
   int      fixPos;      // 1 buy, -1 sell, 0 nenhum
   int      position;    // idem (var position do Pine)
   int      sigType;     // 1 CON, 2 REV
   int      sigBar;      // barra do ultimo sinal
   //--- gestao (visual + estatisticas)
   bool     beTrig;
   double   beLvl,trailSL;
   bool     tp1Hit,tp2Hit,tp3Hit,tp4Hit,tradeDone,slDone;
   int      stWins,stLosses;
   double   stSumR;
  };

SState g_state;
SState g_disp;      // fotografia para os paineis
int    g_lastRates=0;

//--- valores da ultima barra calculada (para paineis)
int    g_bullScore=0,g_bearScore=0;
int    g_grA_b=0,g_grA_s=0,g_grB_b=0,g_grB_s=0,g_grC_b=0,g_grC_s=0,g_grD_b=0,g_grD_s=0;
bool   g_cA1b,g_cA1s,g_cA2b,g_cA2s,g_cA3b,g_cA3s,g_cA5b,g_cA5s;
bool   g_cB1,g_cB3,g_cB5b,g_cB5s;
bool   g_cC1b,g_cC1s,g_cC2b,g_cC2s,g_cC3b,g_cC3s,g_cC4b,g_cC4s,g_cC5b,g_cC5s;
bool   g_cD1b,g_cD1s,g_cD3b,g_cD3s,g_cD4b,g_cD4s,g_cD5;
bool   g_htfBuyOK,g_htfSellOK,g_inSess,g_chopOK,g_ltfValid;
bool   g_baseBuy,g_baseSell,g_cooldownOK;
double g_curAdx=0,g_curRsi=0,g_curDelta=0;
bool   g_ofBull=false,g_ofBear=false;
double g_curEntry=0,g_curSL=0,g_curTP1=0,g_curTP2=0,g_curTP3=0,g_curTP4=0;
int    g_curPos=0;
bool   g_tradeActive=false;
datetime g_lastAlertBar=0;
//--- diagnostico do funil de sinal (quantas barras morrem em cada filtro)
long g_dBars=0,g_dBase=0,g_dScore=0,g_dConf=0,g_dCool=0,g_dSess=0,g_dChop=0,g_dBar=0,g_dHtf=0,g_dOk=0;
long g_dBaseS=0,g_dScoreS=0,g_dOkS=0;
long g_dScoreHist[21];
int  g_dMaxScore=0;
double g_dSumScore=0;
//--- niveis movidos a mao no grafico (0 = a seguir o indicador)
double   g_manSL=0.0,g_manTP1=0.0,g_manTP2=0.0,g_manTP3=0.0,g_manTP4=0.0;
double   g_drawSL=0.0,g_drawT1=0.0,g_drawT2=0.0,g_drawT3=0.0,g_drawT4=0.0;
bool     g_onChart=false;
int      g_tfsec=0;


//====================================================================
//  PALETA DE TEMA (portada do Pine)
//====================================================================
color th_bg,th_bg2,th_text,th_text2,th_bull,th_bear,th_accent,th_gold;
color th_ok,th_fail,th_entry,th_sl,th_be,th_tp1,th_tp2,th_tp3,th_tp4;
color th_head;

void ApplyTheme()
  {
   switch(InpTheme)
     {
      case TH_CLASSIC:
         th_bg=C'15,23,42';    th_bg2=C'30,27,75';   th_text=clrWhite;
         th_text2=C'148,163,184'; th_accent=C'79,70,229'; th_entry=C'79,70,229';
         th_bull=C'34,197,94'; th_bear=C'239,68,68';
         break;
      case TH_LIGHT:
         th_bg=C'240,244,255'; th_bg2=C'224,234,255'; th_text=C'30,27,75';
         th_text2=C'55,65,81';  th_accent=C'124,58,237'; th_entry=C'124,58,237';
         th_bull=C'22,101,52'; th_bear=C'153,27,27';
         break;
      case TH_POP:
         th_bg=C'26,0,48';     th_bg2=C'45,0,71';    th_text=clrWhite;
         th_text2=C'148,163,184'; th_accent=C'204,0,255'; th_entry=C'204,0,255';
         th_bull=C'0,255,136'; th_bear=C'255,0,85';
         break;
      default: // TH_DARK
         th_bg=C'13,13,26';    th_bg2=C'19,19,37';   th_text=clrWhite;
         th_text2=C'148,163,184'; th_accent=C'124,58,237'; th_entry=C'124,58,237';
         th_bull=C'34,197,94'; th_bear=C'239,68,68';
         break;
     }
   th_gold=(InpTheme==TH_POP)?C'255,215,0':C'245,158,11';
   th_ok  =(InpTheme==TH_POP)?C'0,255,136':((InpTheme==TH_LIGHT)?C'22,101,52':C'74,222,128');
   th_fail=(InpTheme==TH_POP)?C'255,0,85' :((InpTheme==TH_LIGHT)?C'153,27,27':C'248,113,113');
   th_sl  =(InpTheme==TH_POP)?C'255,0,85':clrRed;
   th_be  =(InpTheme==TH_POP)?C'255,136,0':clrOrange;
   th_tp1 =(InpTheme==TH_POP)?C'0,255,136':C'34,197,94';
   th_tp2 =(InpTheme==TH_POP)?C'0,204,102':C'22,163,74';
   th_tp3 =(InpTheme==TH_POP)?C'0,153,68' :C'21,128,61';
   th_tp4 =(InpTheme==TH_POP)?C'0,119,51' :C'15,118,110';
   th_head=th_accent;
  }

//====================================================================
//  HELPERS
//====================================================================
double RoundP(const double x)
  {
   if(g_tickSize<=0.0) return(x);
   return(MathRound(x/g_tickSize)*g_tickSize);
  }

double HighestVal(const double &a[],const int i,const int len)
  {
   double m=a[i];
   for(int k=1;k<len;k++) if(a[i-k]>m) m=a[i-k];
   return(m);
  }

double LowestVal(const double &a[],const int i,const int len)
  {
   double m=a[i];
   for(int k=1;k<len;k++) if(a[i-k]<m) m=a[i-k];
   return(m);
  }

int ParseHM(const string s)
  {
   string p[];
   int n=StringSplit(s,':',p);
   if(n<2) return(0);
   return((int)StringToInteger(p[0])*60+(int)StringToInteger(p[1]));
  }

bool InSession(const datetime t)
  {
   if(!InpUseSession) return(true);
   MqlDateTime d;
   TimeToStruct(t,d);
   int cur=d.hour*60+d.min;
   int s=ParseHM(InpSessStart);
   int e=ParseHM(InpSessEnd);
   if(s==e) return(true);
   if(s<e)  return(cur>=s && cur<e);
   return(cur>=s || cur<e);
  }

string ConfMark(const int score)
  {
   if(score>=18) return("*****");
   if(score>=15) return("**** ");
   if(score>=12) return("***  ");
   if(score>=9)  return("**   ");
   return("*    ");
  }

string Dots(const int s)
  {
   switch(s)
     {
      case 5: return("#####");
      case 4: return("####-");
      case 3: return("###--");
      case 2: return("##---");
      case 1: return("#----");
     }
   return("-----");
  }

string Ck(const bool v){ return(v?"[x]":"[ ]"); }

//====================================================================
//  RESOLUCAO AUTO (matriz walk-forward por simbolo x timeframe)
//====================================================================
int g_styleOverride=-1;   // -1 = usa o input; caso contrario manda o painel

void ResolveAuto()
  {
   string sym=_Symbol;
   StringToUpper(sym);
   int  tfsec = PeriodSeconds(_Period);
   bool is15  = (tfsec==900);
   bool is60  = (tfsec==3600);
   bool isBTC = (StringFind(sym,"BTC")>=0);
   bool isETH = (StringFind(sym,"ETH")>=0);
   bool isXAU = (StringFind(sym,"XAU")>=0 || StringFind(sym,"GOLD")>=0);
   bool isNAS = (StringFind(sym,"NAS")>=0 || StringFind(sym,"US100")>=0 ||
                 StringFind(sym,"NDX")>=0 || StringFind(sym,"USTEC")>=0);
   bool isJPY = (StringFind(sym,"USDJPY")>=0);
   bool isCAD = (StringFind(sym,"USDCAD")>=0);

   g_autoValid=false;
   ENUM_MTM_PHASE aPhase=PHASE_MOMENTUM;
   int    aMin=15,aCd=8;
   double aAdx=16.0,aSl=2.0;
   ENUM_MTM_BE aBe=BE_EXIT1;
   double a1=1.5,a2=3.0,a3=5.0,a4=8.0;

   if(is60 && isBTC)
     { g_autoValid=true; aPhase=PHASE_MOMENTUM; aAdx=16; aMin=15; aSl=2.0; aCd=8; aBe=BE_EXIT2; a1=1.5;a2=3.0;a3=5.0;a4=8.0; }
   else if(is60 && isETH)
     { g_autoValid=true; aPhase=PHASE_MOMENTUM; aAdx=22; aMin=15; aSl=2.5; aCd=8; aBe=BE_EXIT2; a1=1.5;a2=3.0;a3=5.0;a4=8.0; }
   else if(is60 && isXAU)
     { g_autoValid=true; aPhase=PHASE_MOMENTUM; aAdx=16; aMin=13; aSl=2.5; aCd=4; aBe=BE_EXIT2; a1=1.5;a2=3.0;a3=5.0;a4=8.0; }
   else if(is60 && isJPY)
     { g_autoValid=true; aPhase=PHASE_EXAUSTAO; aAdx=16; aMin=13; aSl=2.5; aCd=8; aBe=BE_EXIT1; a1=2.0;a2=3.0;a3=4.5;a4=6.5; }
   else if(is15 && isNAS)
     { g_autoValid=true; aPhase=PHASE_MOMENTUM; aAdx=22; aMin=13; aSl=2.5; aCd=4; aBe=BE_EXIT2; a1=1.5;a2=3.0;a3=5.0;a4=8.0; }
   else if(is15 && isCAD)
     { g_autoValid=true; aPhase=PHASE_MOMENTUM; aAdx=16; aMin=13; aSl=2.5; aCd=4; aBe=BE_EXIT1; a1=2.0;a2=3.0;a3=4.5;a4=6.5; }

   g_autoOn = (InpAutoOptimize && g_autoValid);

   if(g_autoOn)
     {
      g_effMinScore = aMin;
      g_effCooldown = aCd;
      g_effAdx      = aAdx;
      g_actSlMult   = aSl;
      g_phaseMode   = aPhase;
      g_effBe       = aBe;
      g_rr1=a1; g_rr2=a2; g_rr3=a3; g_rr4=a4;
     }
   else
     {
      ENUM_MTM_STYLE st=(g_styleOverride>=0)?(ENUM_MTM_STYLE)g_styleOverride:InpStyle;
      switch(st)
        {
         case STYLE_CONSERVADOR:   g_effMinScore=16; g_effCooldown=12; g_effAdx=26; g_actSlMult=2.5; g_phaseMode=PHASE_EXAUSTAO; break;
         case STYLE_SWING:         g_effMinScore=14; g_effCooldown=8;  g_effAdx=22; g_actSlMult=2.0; g_phaseMode=PHASE_EXAUSTAO; break;
         case STYLE_INTRADAY:      g_effMinScore=12; g_effCooldown=5;  g_effAdx=18; g_actSlMult=1.3; g_phaseMode=PHASE_MOMENTUM; break;
         case STYLE_AGRESSIVO:     g_effMinScore=11; g_effCooldown=4;  g_effAdx=18; g_actSlMult=1.5; g_phaseMode=PHASE_MOMENTUM; break;
         case STYLE_SCALP:         g_effMinScore=10; g_effCooldown=2;  g_effAdx=14; g_actSlMult=1.0; g_phaseMode=PHASE_MOMENTUM; break;
         default: // Personalizado
            g_effMinScore=InpMinScore; g_effCooldown=InpCooldown; g_effAdx=18;
            g_actSlMult=InpSlMult;     g_phaseMode=InpPhaseMode;  break;
        }
      g_effBe = InpBeMode;
      //--- ordena os RR (E1 < E2 < E3 < E4) tal como o Pine
      double rr[4]; rr[0]=InpTP1RR; rr[1]=InpTP2RR; rr[2]=InpTP3RR; rr[3]=InpTP4RR;
      ArraySort(rr);
      g_rr1=rr[0]; g_rr2=rr[1]; g_rr3=rr[2]; g_rr4=rr[3];
     }
  }

//====================================================================
//  RESET DO ESTADO
//====================================================================
void ResetState()
  {
   ZeroMemory(g_state);
   g_state.swLong.os=0;  g_state.swLong.topx=-1;  g_state.swLong.btmx=-1;
   g_state.swShort.os=0; g_state.swShort.topx=-1; g_state.swShort.btmx=-1;
   g_state.os_ms=0;
   g_state.max_ms=0; g_state.min_ms=0; g_state.max_x1=-1; g_state.min_x1=-1;
   g_state.choch_bull_bar=-1; g_state.choch_bear_bar=-1;
   g_state.bos_bull_bar=-1;   g_state.bos_bear_bar=-1;
   g_state.obBullBar=-1;      g_state.obBearBar=-1;
   g_state.lastSigBar=-100000;
   g_state.lastPhaseBuy=-100000; g_state.lastPhaseSell=-100000;
   g_state.sigType=1;
   g_state.sigBar=-1;
   g_disp=g_state;
  }

//====================================================================
//  ONINIT
//====================================================================
#ifdef MTM_EMBEDDED
//--- dentro de um EA nao ha buffers de indicador nem plots
int MtmEngineInit()
  {
#else
int OnInit()
  {
   SetIndexBuffer(0 ,BufD15   ,INDICATOR_DATA);
   SetIndexBuffer(1 ,BufD50   ,INDICATOR_DATA);
   SetIndexBuffer(2 ,BufD238  ,INDICATOR_DATA);
   SetIndexBuffer(3 ,BufPOC   ,INDICATOR_DATA);
   SetIndexBuffer(4 ,BufBU    ,INDICATOR_DATA);
   SetIndexBuffer(5 ,BufBL    ,INDICATOR_DATA);
   SetIndexBuffer(6 ,BufCF    ,INDICATOR_DATA);
   SetIndexBuffer(7 ,BufCS    ,INDICATOR_DATA);
   SetIndexBuffer(8 ,BufFillA ,INDICATOR_DATA);
   SetIndexBuffer(9 ,BufFillB ,INDICATOR_DATA);
   SetIndexBuffer(10,BufArrUp ,INDICATOR_DATA);
   SetIndexBuffer(11,BufArrDn ,INDICATOR_DATA);
   SetIndexBuffer(12,BufMomB  ,INDICATOR_DATA);
   SetIndexBuffer(13,BufMomS  ,INDICATOR_DATA);
   SetIndexBuffer(14,BufExhB  ,INDICATOR_DATA);
   SetIndexBuffer(15,BufExhS  ,INDICATOR_DATA);
   SetIndexBuffer(16,BufSwHi  ,INDICATOR_DATA);
   SetIndexBuffer(17,BufSwLo  ,INDICATOR_DATA);
   SetIndexBuffer(18,BufSigO  ,INDICATOR_DATA);
   SetIndexBuffer(19,BufSigH  ,INDICATOR_DATA);
   SetIndexBuffer(20,BufSigL  ,INDICATOR_DATA);
   SetIndexBuffer(21,BufSigC  ,INDICATOR_DATA);
   SetIndexBuffer(22,BufSigCol,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(23,BufSignal,INDICATOR_DATA);
   SetIndexBuffer(24,BufEntry ,INDICATOR_DATA);
   SetIndexBuffer(25,BufSL    ,INDICATOR_DATA);
   SetIndexBuffer(26,BufTP1   ,INDICATOR_DATA);
   SetIndexBuffer(27,BufTP2   ,INDICATOR_DATA);
   SetIndexBuffer(28,BufTP3   ,INDICATOR_DATA);
   SetIndexBuffer(29,BufTP4   ,INDICATOR_DATA);
   SetIndexBuffer(30,BufScore ,INDICATOR_DATA);
   SetIndexBuffer(31,BufType  ,INDICATOR_DATA);
   SetIndexBuffer(32,BufATR   ,INDICATOR_DATA);

   for(int p=0;p<18;p++) PlotIndexSetDouble(p,PLOT_EMPTY_VALUE,EMPTY_VALUE);
   PlotIndexSetInteger(9 ,PLOT_ARROW,233);   // BUY
   PlotIndexSetInteger(10,PLOT_ARROW,234);   // SELL
   PlotIndexSetInteger(11,PLOT_ARROW,241);   // Momentum buy
   PlotIndexSetInteger(12,PLOT_ARROW,242);   // Momentum sell
   PlotIndexSetInteger(13,PLOT_ARROW,110);   // Exaustao buy
   PlotIndexSetInteger(14,PLOT_ARROW,110);   // Exaustao sell
   PlotIndexSetInteger(15,PLOT_ARROW,159);   // Swing high
   PlotIndexSetInteger(16,PLOT_ARROW,159);   // Swing low
   PlotIndexSetInteger(9 ,PLOT_ARROW_SHIFT, 14);
   PlotIndexSetInteger(10,PLOT_ARROW_SHIFT,-14);
   PlotIndexSetInteger(11,PLOT_ARROW_SHIFT, 26);
   PlotIndexSetInteger(12,PLOT_ARROW_SHIFT,-26);
   PlotIndexSetInteger(13,PLOT_ARROW_SHIFT, 34);
   PlotIndexSetInteger(14,PLOT_ARROW_SHIFT,-34);

   ApplyTheme();
   PlotIndexSetInteger(8,PLOT_LINE_COLOR,0,th_bull);
   PlotIndexSetInteger(8,PLOT_LINE_COLOR,1,th_bear);
   PlotIndexSetInteger(9 ,PLOT_LINE_COLOR,0,th_bull);
   PlotIndexSetInteger(10,PLOT_LINE_COLOR,0,th_bear);
   PlotIndexSetInteger(11,PLOT_LINE_COLOR,0,th_bull);
   PlotIndexSetInteger(12,PLOT_LINE_COLOR,0,th_bear);
   PlotIndexSetInteger(13,PLOT_LINE_COLOR,0,th_bull);
   PlotIndexSetInteger(14,PLOT_LINE_COLOR,0,th_bear);
   PlotIndexSetInteger(15,PLOT_LINE_COLOR,0,InpBearCss);
   PlotIndexSetInteger(16,PLOT_LINE_COLOR,0,InpBullCss);
   PlotIndexSetInteger(17,PLOT_LINE_COLOR,0,th_bull);
   PlotIndexSetInteger(17,PLOT_LINE_COLOR,1,th_bear);
   PlotIndexSetInteger(4,PLOT_LINE_COLOR,0,InpSenseiBull);
   PlotIndexSetInteger(5,PLOT_LINE_COLOR,0,InpSenseiBull);
   PlotIndexSetInteger(6,PLOT_LINE_COLOR,0,InpSenseiBull);
   PlotIndexSetInteger(7,PLOT_LINE_COLOR,0,InpSenseiBear);

   IndicatorSetString(INDICATOR_SHORTNAME,"MTM Sensei v3");
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);
#endif
   g_tfsec=PeriodSeconds(_Period);
   g_tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(g_tickSize<=0.0) g_tickSize=_Point;
   g_pipUnit = (_Point<0.01) ? _Point*10.0 : _Point;

   ResolveAuto();
   g_senseiFastLen = (InpSenseiType==BAND_ACTIVE)
                     ? (int)MathRound(InpSenseiLen*0.382)
                     : (int)MathRound(InpSenseiLen*0.5);
   if(g_senseiFastLen<2) g_senseiFastLen=2;

   g_hD15  = iDEMA(_Symbol,_Period,15 ,0,PRICE_CLOSE);
   g_hD50  = iDEMA(_Symbol,_Period,50 ,0,PRICE_CLOSE);
   g_hD238 = iDEMA(_Symbol,_Period,238,0,PRICE_CLOSE);
   g_hATR  = iATR (_Symbol,_Period,InpAtrPeriod);
   g_hRSI  = iRSI (_Symbol,_Period,14,PRICE_CLOSE);
   g_hADX  = iADX (_Symbol,_Period,14);
   g_hSMA  = iMA  (_Symbol,_Period,InpSenseiLen,0,MODE_SMA,PRICE_CLOSE);
   g_hSTD  = iStdDev(_Symbol,_Period,InpSenseiLen,0,MODE_SMA,PRICE_CLOSE);
   g_hEMAF = iMA  (_Symbol,_Period,g_senseiFastLen,0,MODE_EMA,PRICE_CLOSE);
   g_hEMAS = iMA  (_Symbol,_Period,InpSenseiLen,0,MODE_EMA,PRICE_CLOSE);
   g_hHTF  = iMA  (_Symbol,InpHTF ,InpHtfEmaLen,0,MODE_EMA,PRICE_CLOSE);

   if(g_hD15==INVALID_HANDLE || g_hD50==INVALID_HANDLE || g_hD238==INVALID_HANDLE ||
      g_hATR==INVALID_HANDLE || g_hRSI==INVALID_HANDLE || g_hADX ==INVALID_HANDLE ||
      g_hSMA==INVALID_HANDLE || g_hSTD==INVALID_HANDLE || g_hEMAF==INVALID_HANDLE ||
      g_hEMAS==INVALID_HANDLE|| g_hHTF==INVALID_HANDLE)
     {
      Print("MTM Sensei: falha a criar handles de indicadores");
      return(INIT_FAILED);
     }

   g_warmup = 600;
   if(InpSenseiLen+50 > g_warmup) g_warmup = InpSenseiLen+50;
   if(InpSmcLen  +50 > g_warmup) g_warmup = InpSmcLen+50;

   ResetState();
   g_lastRates=0;
   ObjectsDeleteAll(0,g_prefix);
   return(INIT_SUCCEEDED);
  }

#ifdef MTM_EMBEDDED
void MtmEngineDeinit()
#else
void OnDeinit(const int reason)
#endif
  {
   ObjectsDeleteAll(0,g_prefix);
   ChartRedraw();
  }

//====================================================================
//  COPIA DE BUFFERS AUXILIARES
//====================================================================
bool CopyTail(const int handle,const int bufnum,double &dest[],const int rates_total,const int need)
  {
   double tmp[];
   ArraySetAsSeries(tmp,true);
   int n=MathMin(need,rates_total);
   if(n<=0) return(true);
   if(CopyBuffer(handle,bufnum,0,n,tmp)<n) return(false);
   for(int k=0;k<n;k++) dest[rates_total-1-k]=tmp[k];
   return(true);
  }

bool RefreshHtfCache()
  {
   int total=Bars(_Symbol,InpHTF);
   if(total<InpHtfEmaLen+10) return(false);
   int cnt=MathMin(total,20000);
   ArrayResize(g_htfVals,cnt);
   ArrayResize(g_htfTimes,cnt);
   double tv[]; datetime tt[];
   ArraySetAsSeries(tv,true);
   ArraySetAsSeries(tt,true);
   if(CopyBuffer(g_hHTF,0,0,cnt,tv)<cnt) return(false);
   if(CopyTime(_Symbol,InpHTF,0,cnt,tt)<cnt) return(false);
   for(int k=0;k<cnt;k++)
     {
      g_htfVals[cnt-1-k]=tv[k];
      g_htfTimes[cnt-1-k]=tt[k];
     }
   g_htfCount=cnt;
   return(true);
  }

//--- EMA do HTF para o instante t (barra fechada = anti-repaint)
double HtfEmaAt(const datetime t)
  {
   if(g_htfCount<=2) return(0.0);
   int lo=0,hi=g_htfCount-1,pos=-1;
   while(lo<=hi)
     {
      int mid=(lo+hi)/2;
      if(g_htfTimes[mid]<=t){ pos=mid; lo=mid+1; }
      else hi=mid-1;
     }
   if(pos<0) return(0.0);
   int use = InpHtfClosedBar ? pos-1 : pos;
   if(use<0) return(0.0);
   return(g_htfVals[use]);
  }

//--- delta real via timeframe inferior
void UpdateLTF(const int i,const int rates_total,const datetime &time[])
  {
   if(!InpUseLTFOF){ g_ltfUp[i]=0; g_ltfDn[i]=0; g_ltfSz[i]=0; g_ltfDone[i]=1; return; }
   if(i < rates_total-InpOfMaxBars){ g_ltfUp[i]=0; g_ltfDn[i]=0; g_ltfSz[i]=0; g_ltfDone[i]=1; return; }
   if(g_ltfDone[i]==1 && i<rates_total-2) return;

   MqlRates r[];
   datetime t1=time[i];
   datetime t2=t1+PeriodSeconds(_Period)-1;
   int n=CopyRates(_Symbol,InpLTF,t1,t2,r);
   double up=0,dn=0;
   if(n>0)
      for(int k=0;k<n;k++)
        {
         if(r[k].close>=r[k].open) up+=(double)r[k].tick_volume;
         else                      dn+=(double)r[k].tick_volume;
        }
   g_ltfUp[i]=up; g_ltfDn[i]=dn; g_ltfSz[i]=(n>0?n:0);
   g_ltfDone[i]=1;
  }

//====================================================================
//  SWINGS (port do ta.highest/lowest do Pine)
//====================================================================
void Swings(const int i,const int slen,SwingState &s,
            const double &high[],const double &low[],
            bool &newTop,double &topVal,bool &newBtm,double &btmVal)
  {
   newTop=false; newBtm=false; topVal=0; btmVal=0;
   if(i-slen<0) return;
   double up_=HighestVal(high,i,slen);
   double dn_=LowestVal (low ,i,slen);
   int prevOs=s.os;
   if(high[i-slen]>up_)      s.os=0;
   else if(low[i-slen]<dn_)  s.os=1;
   newTop=(s.os==0 && prevOs!=0);
   newBtm=(s.os==1 && prevOs!=1);
   if(newTop){ topVal=high[i-slen]; s.topx=i-slen; }
   if(newBtm){ btmVal=low[i-slen];  s.btmx=i-slen; }
  }


//====================================================================
//  ETIQUETAS DE SINAL E DE EVENTO (equivalente aos label.new do Pine)
//====================================================================
void DrawTextLabel(const string nm,const datetime t,const double price,const string txt,
                   const color clr,const int fsize,const ENUM_ANCHOR_POINT anc)
  {
   if(ObjectFind(0,nm)>=0) return;
   if(!ObjectCreate(0,nm,OBJ_TEXT,0,t,price)) return;
   ObjectSetString (0,nm,OBJPROP_TEXT,txt);
   ObjectSetInteger(0,nm,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,fsize);
   ObjectSetInteger(0,nm,OBJPROP_ANCHOR,anc);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
   ObjectSetString (0,nm,OBJPROP_FONT,"Arial Bold");
  }

//====================================================================
//  DESENHO DE ESTRUTURA (linhas SMC criadas no momento do evento)
//====================================================================
int g_structSeq=0;

void DrawStructLine(const string tag,const datetime t1,const double p1,const datetime t2,
                    const double p2,const color clr,const ENUM_LINE_STYLE st,const string txt)
  {
   string nm=g_prefix+"S_"+tag+"_"+IntegerToString(g_structSeq++);
   if(!ObjectCreate(0,nm,OBJ_TREND,0,t1,p1,t2,p2)) return;
   ObjectSetInteger(0,nm,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,nm,OBJPROP_STYLE,st);
   ObjectSetInteger(0,nm,OBJPROP_WIDTH,1);
   ObjectSetInteger(0,nm,OBJPROP_RAY_RIGHT,false);
   ObjectSetInteger(0,nm,OBJPROP_BACK,true);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   if(txt!="")
     {
      string nl=g_prefix+"T_"+tag+"_"+IntegerToString(g_structSeq++);
      if(ObjectCreate(0,nl,OBJ_TEXT,0,t2,p2))
        {
         ObjectSetString (0,nl,OBJPROP_TEXT,txt);
         ObjectSetInteger(0,nl,OBJPROP_COLOR,clr);
         ObjectSetInteger(0,nl,OBJPROP_FONTSIZE,7);
         ObjectSetInteger(0,nl,OBJPROP_ANCHOR,ANCHOR_LEFT);
         ObjectSetInteger(0,nl,OBJPROP_SELECTABLE,false);
        }
     }
  }

//====================================================================
//  CALCULO DE UMA BARRA
//====================================================================
double g_pocArr[];

void ComputeBar(const int i,const int rates_total,const bool persist,
                const datetime &time[],const double &open[],const double &high[],
                const double &low[],const double &close[],const long &tick_volume[])
  {
   //--- valores base
   double dema15=g_d15[i],dema50=g_d50[i],dema238=g_d238[i];
   double atrVal=g_atr[i];
   double rsi14 =g_rsi[i];
   double adxVal=g_adx[i];
   double basis =g_sma[i];
   double sdev  =g_std[i];
   double senseiU1=basis+sdev;
   double senseiL1=basis-sdev;
   double senseiCF=g_emaF[i];
   double senseiCS=g_emaS[i];
   bool   cloudBull=(senseiCF>=senseiCS);
   double volMA =g_volMA[i];
   double atrMA =g_atrMA[i];
   double vol   =(double)tick_volume[i];

   //--- snapshot para comparacoes tipo "[1]"
   double prevMax=g_state.max_ms;
   double prevMin=g_state.min_ms;
   int    prevOsMs=g_state.os_ms;

   //================= POC =================
   if(i%InpLengthPOC==0)
     {
      g_state.pocVol=0.0; g_state.pocPrice=0.0;
      for(int k=0;k<InpLengthPOC;k++)
        {
         if(i-k<0) break;
         double v=(double)tick_volume[i-k];
         if(v>g_state.pocVol){ g_state.pocVol=v; g_state.pocPrice=close[i-k]; }
        }
     }
   double poc=g_state.pocPrice;
   bool   pocOK=(poc>0.0);
   g_pocArr[i]=poc;

   //================= ORDER FLOW =================
   UpdateLTF(i,rates_total,time);
   double ltfDelta=g_ltfUp[i]-g_ltfDn[i];
   double ltfTot  =g_ltfUp[i]+g_ltfDn[i];
   bool   ltfValid=(InpUseLTFOF && g_ltfSz[i]>0 && ltfTot>0);

   double ofProxy=0.0;
   for(int k=0;k<14;k++)
     {
      if(i-k<0) break;
      int sg=(close[i-k]>open[i-k])?1:((close[i-k]<open[i-k])?-1:0);
      ofProxy+=(double)tick_volume[i-k]*sg;
     }
   bool ofBull = ltfValid ? (ltfDelta>0) : (ofProxy>0);
   bool ofBear = ltfValid ? (ltfDelta<0) : (ofProxy<0);
   bool ofImbBull = ltfValid && ltfDelta>0 && ltfDelta>=ltfTot*InpOfImbThr;
   bool ofImbBear = ltfValid && ltfDelta<0 && -ltfDelta>=ltfTot*InpOfImbThr;

   double cRange=high[i]-low[i];
   double cBody =MathAbs(close[i]-open[i]);
   double cBrat =(cRange>0)?cBody/cRange:0.0;
   double cCpct =(cRange>0)?(close[i]-low[i])/cRange:0.5;
   bool buyPressure  =(cCpct>0.55 && ofBull);
   bool sellPressure =(cCpct<0.45 && ofBear);
   bool absorption   =(vol>volMA*1.5 && cBrat<0.40);

   bool volaSafe   =(atrVal>0 && atrMA>0 && atrVal<=atrMA*2.5);
   bool volaExpand =(i>=3 && atrVal>g_atr[i-3]);
   bool volOnSignal=(volMA>0 && vol>=volMA*0.90);

   //================= FILTROS =================
   double htfEma=HtfEmaAt(time[i]);
   bool htfBull=(htfEma>0.0 && close[i]>htfEma);
   bool htfBear=(htfEma>0.0 && close[i]<htfEma);
   bool htfBuyOK =(!InpUseHTF || htfBull);
   bool htfSellOK=(!InpUseHTF || htfBear);
   bool inSess=InSession(time[i]);
   bool chopOK=(!InpUseChop || adxVal>InpAdxChopMin);
   bool barOK =(!InpConfirmClose || i<=rates_total-2);

   //================= FASE =================
   bool flipDown=(i>=4 && close[i]<close[i-4]);
   bool flipUp  =(i>=4 && close[i]>close[i-4]);
   g_state.buySetup  = flipDown ? g_state.buySetup+1  : 0;
   g_state.sellSetup = flipUp   ? g_state.sellSetup+1 : 0;
   bool momBuy =(g_state.buySetup ==InpMomCount);
   bool momSell=(g_state.sellSetup==InpMomCount);
   if(momBuy) { g_state.buyCDact=true;  g_state.buyCD=0;  }
   if(momSell){ g_state.sellCDact=true; g_state.sellCD=0; }
   if(g_state.buyCDact  && i>=2 && close[i]<=low[i-2])  g_state.buyCD++;
   if(g_state.sellCDact && i>=2 && close[i]>=high[i-2]) g_state.sellCD++;
   bool exhBuy =(g_state.buyCDact  && g_state.buyCD ==InpExhCount);
   bool exhSell=(g_state.sellCDact && g_state.sellCD==InpExhCount);
   if(exhBuy) { g_state.buyCDact=false;  g_state.buyCD=0;  }
   if(exhSell){ g_state.sellCDact=false; g_state.sellCD=0; }
   if(momSell) g_state.buyCDact=false;
   if(momBuy)  g_state.sellCDact=false;

   bool phaseBuyTrig  =(g_phaseMode==PHASE_MOMENTUM)? momBuy  : exhBuy;
   bool phaseSellTrig =(g_phaseMode==PHASE_MOMENTUM)? momSell : exhSell;
   if(phaseBuyTrig)  g_state.lastPhaseBuy =i;
   if(phaseSellTrig) g_state.lastPhaseSell=i;
   bool phaseBuyRecent =(i-g_state.lastPhaseBuy <=6);
   bool phaseSellRecent=(i-g_state.lastPhaseSell<=6);

   //================= SMC =================
   bool nTopL,nBtmL,nTopS,nBtmS;
   double vTopL,vBtmL,vTopS,vBtmS;
   Swings(i,InpSmcLen     ,g_state.swLong ,high,low,nTopL,vTopL,nBtmL,vBtmL);
   Swings(i,InpSmcShortLen,g_state.swShort,high,low,nTopS,vTopS,nBtmS,vBtmS);

   if(nTopL){ g_state.topy=vTopL; g_state.hasTopy=true; g_state.top_crossed=false;
              if(InpShowMarks && i-InpSmcLen>=0) BufSwHi[i-InpSmcLen]=vTopL; }
   if(nBtmL){ g_state.btmy=vBtmL; g_state.hasBtmy=true; g_state.btm_crossed=false;
              if(InpShowMarks && i-InpSmcLen>=0) BufSwLo[i-InpSmcLen]=vBtmL; }
   if(nTopS){ g_state.stopy=vTopS; g_state.hasStopy=true; }
   if(nBtmS){ g_state.sbtmy=vBtmS; g_state.hasSbtmy=true; }

   bool drawOK = persist && g_onChart && InpShowStruct && (i>=rates_total-InpStructBars)
                 && MQLInfoInteger(MQL_OPTIMIZATION)==0;
   bool lblOK  = persist && g_onChart && (i>=rates_total-InpStructBars)
                 && MQLInfoInteger(MQL_OPTIMIZATION)==0;

   if(g_state.hasTopy && close[i]>g_state.topy && !g_state.top_crossed)
     { g_state.os_ms=1; g_state.top_crossed=true; g_state.choch_bull_bar=i; }
   if(g_state.hasBtmy && close[i]<g_state.btmy && !g_state.btm_crossed)
     { g_state.os_ms=0; g_state.btm_crossed=true; g_state.choch_bear_bar=i; }

   if(g_state.os_ms!=prevOsMs)
     {
      g_state.max_ms=high[i]; g_state.min_ms=low[i];
      g_state.max_x1=i; g_state.min_x1=i;
      g_state.stop_crossed=false; g_state.sbtm_crossed=false;
      if(drawOK && InpShowStruct)
        {
         if(g_state.os_ms==1 && g_state.swLong.topx>=0)
            DrawStructLine("CH",time[g_state.swLong.topx],g_state.topy,time[i],g_state.topy,
                           InpBullCss,STYLE_DASH,"CHoCH");
         else if(g_state.os_ms==0 && g_state.swLong.btmx>=0)
            DrawStructLine("CH",time[g_state.swLong.btmx],g_state.btmy,time[i],g_state.btmy,
                           InpBearCss,STYLE_DASH,"CHoCH");
        }
     }

   //--- IDM / BOS bull
   if(g_state.hasSbtmy && low[i]<g_state.sbtmy && !g_state.sbtm_crossed &&
      g_state.os_ms==1 && g_state.sbtmy!=g_state.btmy)
     {
      if(drawOK && InpShowStruct && g_state.swShort.btmx>=0)
         DrawStructLine("ID",time[g_state.swShort.btmx],g_state.sbtmy,time[i],g_state.sbtmy,
                        InpIdmCss,STYLE_DOT,"IDM");
      g_state.sbtm_crossed=true;
     }
   if(g_state.max_x1>=0 && close[i]>g_state.max_ms && g_state.sbtm_crossed && g_state.os_ms==1)
     {
      if(drawOK && InpShowStruct) DrawStructLine("BO",time[g_state.max_x1],g_state.max_ms,time[i],g_state.max_ms,
                                InpBullCss,STYLE_SOLID,"BOS");
      g_state.bos_bull_bar=i;
      g_state.sbtm_crossed=false;
     }
   //--- IDM / BOS bear
   if(g_state.hasStopy && high[i]>g_state.stopy && !g_state.stop_crossed &&
      g_state.os_ms==0 && g_state.stopy!=g_state.topy)
     {
      if(drawOK && InpShowStruct && g_state.swShort.topx>=0)
         DrawStructLine("ID",time[g_state.swShort.topx],g_state.stopy,time[i],g_state.stopy,
                        InpIdmCss,STYLE_DOT,"IDM");
      g_state.stop_crossed=true;
     }
   if(g_state.min_x1>=0 && close[i]<g_state.min_ms && g_state.stop_crossed && g_state.os_ms==0)
     {
      if(drawOK && InpShowStruct) DrawStructLine("BO",time[g_state.min_x1],g_state.min_ms,time[i],g_state.min_ms,
                                InpBearCss,STYLE_SOLID,"BOS");
      g_state.bos_bear_bar=i;
      g_state.stop_crossed=false;
     }
   //--- sweeps
   if(drawOK && InpShowStruct && g_state.max_x1>=0 && high[i]>g_state.max_ms && close[i]<g_state.max_ms &&
      g_state.os_ms==1 && (i-g_state.max_x1)>1)
      DrawStructLine("SW",time[g_state.max_x1],g_state.max_ms,time[i],g_state.max_ms,
                     InpSweepCss,STYLE_DOT,"x");
   if(drawOK && InpShowStruct && g_state.min_x1>=0 && low[i]<g_state.min_ms && close[i]>g_state.min_ms &&
      g_state.os_ms==0 && (i-g_state.min_x1)>1)
      DrawStructLine("SW",time[g_state.min_x1],g_state.min_ms,time[i],g_state.min_ms,
                     InpSweepCss,STYLE_DOT,"x");

   g_state.max_ms=MathMax(high[i],g_state.max_ms);
   g_state.min_ms=(g_state.min_x1<0)?low[i]:MathMin(low[i],g_state.min_ms);
   if(g_state.max_ms>prevMax) g_state.max_x1=i;
   if(g_state.min_ms<prevMin || prevMin<=0) g_state.min_x1=i;

   //================= ORDER BLOCKS =================
   if(g_state.os_ms==1 && prevOsMs==0)
      for(int k=1;k<=6;k++)
        {
         if(i-k<0) break;
         if(close[i-k]<open[i-k])
           { g_state.obBullTop=high[i-k]; g_state.obBullBot=low[i-k]; g_state.obBullBar=i-k; break; }
        }
   if(g_state.os_ms==0 && prevOsMs==1)
      for(int k=1;k<=6;k++)
        {
         if(i-k<0) break;
         if(close[i-k]>open[i-k])
           { g_state.obBearTop=high[i-k]; g_state.obBearBot=low[i-k]; g_state.obBearBar=i-k; break; }
        }

   //================= 20 CONFIRMACOES =================
   bool chochBullRec=(g_state.choch_bull_bar>=0 && i-g_state.choch_bull_bar<=25);
   bool chochBearRec=(g_state.choch_bear_bar>=0 && i-g_state.choch_bear_bar<=25);
   bool bosBullRec  =(g_state.bos_bull_bar  >=0 && i-g_state.bos_bull_bar  <=35);
   bool bosBearRec  =(g_state.bos_bear_bar  >=0 && i-g_state.bos_bear_bar  <=35);

   bool cA1b=(dema15>dema50),                    cA1s=(dema15<dema50);
   bool cA2b=(dema50>dema238),                   cA2s=(dema50<dema238);
   bool cA3b=(i>=2 && dema15>g_d15[i-1] && dema15>g_d15[i-2]);
   bool cA3s=(i>=2 && dema15<g_d15[i-1] && dema15<g_d15[i-2]);
   bool cA4b=(i>=3 && dema50>g_d50[i-3]),        cA4s=(i>=3 && dema50<g_d50[i-3]);
   bool cA5b=(close[i]>dema15),                  cA5s=(close[i]<dema15);

   bool cB1 =volOnSignal;
   bool cB2 =volaExpand;
   bool cB3 =(adxVal>g_effAdx);
   bool cB4b=(rsi14>38 && rsi14<72);
   bool cB4s=(rsi14>28 && rsi14<62);
   bool cB5b=ofBull, cB5s=ofBear;

   bool cC1b=(g_state.os_ms==1), cC1s=(g_state.os_ms==0);
   bool cC2b=chochBullRec,       cC2s=chochBearRec;
   bool cC3b=bosBullRec,         cC3s=bosBearRec;
   bool cC4b=(pocOK && close[i]>poc), cC4s=(pocOK && close[i]<poc);
   bool cC5b=ofImbBull,          cC5s=ofImbBear;

   bool cD1b=cloudBull,          cD1s=!cloudBull;
   bool cD2b=(close[i]>senseiL1 && close[i]<senseiU1+sdev);
   bool cD2s=(close[i]<senseiU1 && close[i]>senseiL1-sdev);
   bool cD3b=phaseBuyRecent,     cD3s=phaseSellRecent;
   bool cD4b=buyPressure,        cD4s=sellPressure;
   bool cD5 =volaSafe;

   int grA_b=(cA1b?1:0)+(cA2b?1:0)+(cA3b?1:0)+(cA4b?1:0)+(cA5b?1:0);
   int grA_s=(cA1s?1:0)+(cA2s?1:0)+(cA3s?1:0)+(cA4s?1:0)+(cA5s?1:0);
   int grB_b=(cB1?1:0)+(cB2?1:0)+(cB3?1:0)+(cB4b?1:0)+(cB5b?1:0);
   int grB_s=(cB1?1:0)+(cB2?1:0)+(cB3?1:0)+(cB4s?1:0)+(cB5s?1:0);
   int grC_b=(cC1b?1:0)+(cC2b?1:0)+(cC3b?1:0)+(cC4b?1:0)+(cC5b?1:0);
   int grC_s=(cC1s?1:0)+(cC2s?1:0)+(cC3s?1:0)+(cC4s?1:0)+(cC5s?1:0);
   int grD_b=(cD1b?1:0)+(cD2b?1:0)+(cD3b?1:0)+(cD4b?1:0)+(cD5?1:0);
   int grD_s=(cD1s?1:0)+(cD2s?1:0)+(cD3s?1:0)+(cD4s?1:0)+(cD5?1:0);
   int bullScore=grA_b+grB_b+grC_b+grD_b;
   int bearScore=grA_s+grB_s+grC_s+grD_s;

   //================= GATILHOS =================
   double pocPrev=(i>0)?g_pocArr[i-1]:0.0;
   bool pocUp=(pocOK && pocPrev>0 && close[i]>poc && close[i-1]<=pocPrev);
   bool pocDn=(pocOK && pocPrev>0 && close[i]<poc && close[i-1]>=pocPrev);
   bool baseBuy =(pocUp || (phaseBuyTrig  && (!pocOK || close[i]>=poc)));
   bool baseSell=(pocDn || (phaseSellTrig && (!pocOK || close[i]<=poc)));

   bool cooldown=(i-g_state.lastSigBar>=g_effCooldown);
   bool buyConf =(volaSafe && volOnSignal && !ofBear && !(absorption && ofBear));
   bool sellConf=(volaSafe && volOnSignal && !ofBull && !(absorption && ofBull));
   bool validOK =(!InpStrictAuto || g_autoValid);

   bool isBuy = InpAllowBuy  && baseBuy  && bullScore>=g_effMinScore              &&
                buyConf  && cooldown && inSess && chopOK && barOK && htfBuyOK  && validOK;
   bool isSell= InpAllowSell && baseSell && bearScore>=g_effMinScore+InpSellExtra &&
                sellConf && cooldown && inSess && chopOK && barOK && htfSellOK && validOK;

   //================= DIAGNOSTICO =================
   if(persist)
     {
      g_dBars++;
      if(bullScore>=0 && bullScore<=20) g_dScoreHist[bullScore]++;
      if(bullScore>g_dMaxScore) g_dMaxScore=bullScore;
      g_dSumScore+=bullScore;
      if(baseBuy)
        {
         g_dBase++;
         if(bullScore>=g_effMinScore)
           {
            g_dScore++;
            if(buyConf){ g_dConf++;
              if(cooldown){ g_dCool++;
                if(inSess){ g_dSess++;
                  if(chopOK){ g_dChop++;
                    if(barOK){ g_dBar++;
                      if(htfBuyOK){ g_dHtf++;
                        if(validOK) g_dOk++; }}}}}}
           }
        }
      if(baseSell)
        {
         g_dBaseS++;
         if(bearScore>=g_effMinScore+InpSellExtra){ g_dScoreS++; if(isSell) g_dOkS++; }
        }
     }

   if(isBuy || isSell) g_state.lastSigBar=i;
   bool newSignal=(isBuy||isSell);

   if(isBuy)       g_state.sigType=(g_phaseMode==PHASE_EXAUSTAO && exhBuy )?2:1;
   else if(isSell) g_state.sigType=(g_phaseMode==PHASE_EXAUSTAO && exhSell)?2:1;

   //================= NIVEIS =================
   if(isBuy)  g_state.position=1;
   if(isSell) g_state.position=-1;

   if(newSignal)
     {
      double e=RoundP(close[i]);
      double d=(InpRiskMode==RISK_ATR)? atrVal*g_actSlMult : e*(InpSlPct/100.0);
      int    dir=g_state.position;
      g_state.fixEntry=e;
      g_state.fixSL =(dir>0)?RoundP(e-d):RoundP(e+d);
      g_state.fixTP1=(dir>0)?RoundP(e+d*g_rr1):RoundP(e-d*g_rr1);
      g_state.fixTP2=(dir>0)?RoundP(e+d*g_rr2):RoundP(e-d*g_rr2);
      g_state.fixTP3=(dir>0)?RoundP(e+d*g_rr3):RoundP(e-d*g_rr3);
      g_state.fixTP4=(dir>0)?RoundP(e+d*g_rr4):RoundP(e-d*g_rr4);
      g_state.fixPos=dir;
      g_state.fixSlPips=MathRound(MathAbs(e-g_state.fixSL)/g_pipUnit);
      g_state.sigBar=i;
     }

   int    curPos=InpDynLevels ? g_state.position : g_state.fixPos;
   double entryLvl=InpDynLevels ? RoundP(close[i]) : g_state.fixEntry;
   double slLvl,tp1,tp2,tp3,tp4;
   if(InpDynLevels && curPos!=0)
     {
      double d=(InpRiskMode==RISK_ATR)? atrVal*g_actSlMult : entryLvl*(InpSlPct/100.0);
      slLvl=(curPos>0)?RoundP(entryLvl-d):RoundP(entryLvl+d);
      tp1  =(curPos>0)?RoundP(entryLvl+d*g_rr1):RoundP(entryLvl-d*g_rr1);
      tp2  =(curPos>0)?RoundP(entryLvl+d*g_rr2):RoundP(entryLvl-d*g_rr2);
      tp3  =(curPos>0)?RoundP(entryLvl+d*g_rr3):RoundP(entryLvl-d*g_rr3);
      tp4  =(curPos>0)?RoundP(entryLvl+d*g_rr4):RoundP(entryLvl-d*g_rr4);
     }
   else
     {
      slLvl=g_state.fixSL; tp1=g_state.fixTP1; tp2=g_state.fixTP2;
      tp3=g_state.fixTP3;  tp4=g_state.fixTP4;
     }

   //================= BREAKEVEN + TRAILING (visual) =================
   double beTarget=0.0;
   if(curPos!=0 && tp1>0)
     {
      switch(g_effBe)
        {
         case BE_EXIT1: beTarget=tp1; break;
         case BE_EXIT2: beTarget=tp2; break;
         case BE_EXIT3: beTarget=tp3; break;
         default: beTarget=(curPos>0)? entryLvl+InpBePoints*_Point
                                     : entryLvl-InpBePoints*_Point; break;
        }
     }
   bool beHit=(beTarget>0 && !g_state.beTrig &&
               ((curPos>0 && high[i]>=beTarget)||(curPos<0 && low[i]<=beTarget)));
   if(newSignal){ g_state.beTrig=false; g_state.beLvl=0; g_state.trailSL=0; }
   if(beHit && !g_state.beTrig){ g_state.beTrig=true; g_state.beLvl=entryLvl; }

   if(InpTrailMode==TRAIL_ATR && curPos!=0 && !newSignal)
     {
      double cand=(curPos>0)? close[i]-atrVal*InpTrailMult : close[i]+atrVal*InpTrailMult;
      if(g_state.trailSL<=0) g_state.trailSL=cand;
      else g_state.trailSL=(curPos>0)? MathMax(g_state.trailSL,cand) : MathMin(g_state.trailSL,cand);
     }
   double baseSL2=(g_state.beTrig? g_state.beLvl : slLvl);
   double effSL  =baseSL2;
   if(InpTrailMode==TRAIL_ATR && g_state.trailSL>0 && baseSL2>0)
      effSL=(curPos>0)? MathMax(baseSL2,g_state.trailSL) : MathMin(baseSL2,g_state.trailSL);

   //================= HITS + ESTATISTICAS =================
   if(newSignal)
     {
      g_state.tp1Hit=false; g_state.tp2Hit=false; g_state.tp3Hit=false; g_state.tp4Hit=false;
      g_state.tradeDone=false; g_state.slDone=false;
     }
   bool afterEntry=(!newSignal && curPos!=0);
   bool tp1Now=afterEntry && !g_state.tradeDone && !g_state.tp1Hit && tp1>0 &&
               ((curPos>0 && high[i]>=tp1)||(curPos<0 && low[i]<=tp1));
   bool tp2Now=afterEntry && !g_state.tradeDone && !g_state.tp2Hit && tp2>0 &&
               ((curPos>0 && high[i]>=tp2)||(curPos<0 && low[i]<=tp2));
   bool tp3Now=afterEntry && !g_state.tradeDone && !g_state.tp3Hit && tp3>0 &&
               ((curPos>0 && high[i]>=tp3)||(curPos<0 && low[i]<=tp3));
   bool tp4Now=afterEntry && !g_state.tradeDone && !g_state.tp4Hit && tp4>0 &&
               ((curPos>0 && high[i]>=tp4)||(curPos<0 && low[i]<=tp4));
   if(tp1Now) g_state.tp1Hit=true;
   if(tp2Now) g_state.tp2Hit=true;
   if(tp3Now) g_state.tp3Hit=true;
   if(tp4Now) g_state.tp4Hit=true;
   bool slNow=afterEntry && !g_state.tradeDone && effSL>0 &&
              ((curPos>0 && low[i]<=effSL)||(curPos<0 && high[i]>=effSL));
   bool lastTPNow = InpShowExits? tp4Now : (InpShowExits? tp3Now : (InpShowExits? tp2Now : tp1Now));
   bool doneNow=(lastTPNow||slNow||(InpBeCompletes && beHit)) && !g_state.tradeDone;

   if(doneNow)
     {
      g_state.tradeDone=true;
      if(slNow) g_state.slDone=true;
      double riskD=MathAbs(g_state.fixEntry-g_state.fixSL);
      double exitP= slNow? effSL : (g_state.tp4Hit? tp4 : (g_state.tp3Hit? tp3 :
                    (g_state.tp2Hit? tp2 : (g_state.tp1Hit? tp1 : close[i]))));
      double rOut=(riskD>0)?(((curPos>0)?(exitP-g_state.fixEntry):(g_state.fixEntry-exitP))/riskD):0.0;
      if(rOut>0)      g_state.stWins++;
      else if(rOut<0) g_state.stLosses++;
      g_state.stSumR+=rOut;
     }

   //================= BUFFERS =================
   BufD15[i] = InpShowDEMA ? dema15 : EMPTY_VALUE;
   BufD50[i] = InpShowDEMA ? dema50 : EMPTY_VALUE;
   BufD238[i]= InpShowDEMA ? dema238: EMPTY_VALUE;
   BufPOC[i] = (InpShowPOC && pocOK)? poc : EMPTY_VALUE;
   BufBU[i]  = InpShowBands ? senseiU1 : EMPTY_VALUE;
   BufBL[i]  = InpShowBands ? senseiL1 : EMPTY_VALUE;
   BufCF[i]  = InpShowCloud ? senseiCF : EMPTY_VALUE;
   BufCS[i]  = InpShowCloud ? senseiCS : EMPTY_VALUE;
   //--- preenchimento da cloud (equivalente ao fill() do Pine)
   BufFillA[i]= InpShowCloud ? senseiCF : EMPTY_VALUE;
   BufFillB[i]= InpShowCloud ? senseiCS : EMPTY_VALUE;
   //--- setas de entrada
   BufArrUp[i]= isBuy  ? low[i]  : EMPTY_VALUE;
   BufArrDn[i]= isSell ? high[i] : EMPTY_VALUE;
   //--- contagem de fase (triangulos = momentum, quadrados = exaustao)
   BufMomB[i] = (InpShowMarks && momBuy ) ? low[i]  : EMPTY_VALUE;
   BufMomS[i] = (InpShowMarks && momSell) ? high[i] : EMPTY_VALUE;
   BufExhB[i] = (InpShowMarks && exhBuy ) ? low[i]  : EMPTY_VALUE;
   BufExhS[i] = (InpShowMarks && exhSell) ? high[i] : EMPTY_VALUE;
   //--- circulos de swing: a barra i so e marcada por uma barra FUTURA (i+SmcLen),
   //    por isso aqui e sempre seguro limpar
   BufSwHi[i]=EMPTY_VALUE;
   BufSwLo[i]=EMPTY_VALUE;
   //--- vela do sinal recolorida (equivalente ao barcolor() do Pine)
   if(InpShowMarks && newSignal)
     {
      BufSigO[i]=open[i]; BufSigH[i]=high[i];
      BufSigL[i]=low[i];  BufSigC[i]=close[i];
      BufSigCol[i]= isBuy ? 0.0 : 1.0;
     }
   else
     {
      BufSigO[i]=EMPTY_VALUE; BufSigH[i]=EMPTY_VALUE;
      BufSigL[i]=EMPTY_VALUE; BufSigC[i]=EMPTY_VALUE;
      BufSigCol[i]=0.0;
     }
   BufATR[i] = atrVal;

   //================= ETIQUETAS NO GRAFICO =================
   if(lblOK && newSignal && InpShowMarks)
     {
      string bt=(g_state.sigType==2)?"REV":"CON";
      string tx=StringFormat("%s  %s%d/20   SL %.0fp",bt,(isBuy?"+":"+"),
                             (isBuy?bullScore:bearScore),g_state.fixSlPips);
      double py=isBuy ? low[i]-atrVal*1.2 : high[i]+atrVal*1.2;
      DrawTextLabel(g_prefix+"B_"+IntegerToString((int)time[i]),time[i],py,tx,
                    isBuy?th_bull:th_bear,8,
                    isBuy?ANCHOR_UPPER:ANCHOR_LOWER);
     }
   if(lblOK && InpSignalDisp==DISP_ALL)
     {
      string k=IntegerToString((int)time[i]);
      if(tp1Now && InpShowExits) DrawTextLabel(g_prefix+"E1_"+k,time[i],tp1,"E1",th_tp1,7,ANCHOR_LEFT);
      if(tp2Now && InpShowExits) DrawTextLabel(g_prefix+"E2_"+k,time[i],tp2,"E2",th_tp2,7,ANCHOR_LEFT);
      if(tp3Now && InpShowExits) DrawTextLabel(g_prefix+"E3_"+k,time[i],tp3,"E3",th_tp3,7,ANCHOR_LEFT);
      if(tp4Now && InpShowExits) DrawTextLabel(g_prefix+"E4_"+k,time[i],tp4,"E4",th_tp4,7,ANCHOR_LEFT);
      if(beHit)                DrawTextLabel(g_prefix+"BE_"+k,time[i],entryLvl,"BE",th_be,7,ANCHOR_LEFT);
      if(slNow)                DrawTextLabel(g_prefix+"SL_"+k,time[i],effSL,
                                             (g_state.beTrig?"BE":"SL"),
                                             (g_state.beTrig?th_be:th_sl),7,ANCHOR_LEFT);
     }

   if(newSignal)
     {
      BufSignal[i]= isBuy?1.0:-1.0;
      BufEntry[i] = g_state.fixEntry;
      BufSL[i]    = g_state.fixSL;
      BufTP1[i]   = g_state.fixTP1;
      BufTP2[i]   = g_state.fixTP2;
      BufTP3[i]   = g_state.fixTP3;
      BufTP4[i]   = g_state.fixTP4;
      BufScore[i] = (double)(isBuy? bullScore : bearScore);
      BufType[i]  = (double)g_state.sigType;
     }
   else
     {
      BufSignal[i]=0.0; BufEntry[i]=0.0; BufSL[i]=0.0;
      BufTP1[i]=0.0; BufTP2[i]=0.0; BufTP3[i]=0.0; BufTP4[i]=0.0;
      BufScore[i]=0.0; BufType[i]=0.0;
     }

   //================= ESTADO PARA PAINEIS =================
   g_bullScore=bullScore; g_bearScore=bearScore;
   g_grA_b=grA_b; g_grA_s=grA_s; g_grB_b=grB_b; g_grB_s=grB_s;
   g_grC_b=grC_b; g_grC_s=grC_s; g_grD_b=grD_b; g_grD_s=grD_s;
   g_cA1b=cA1b; g_cA1s=cA1s; g_cA2b=cA2b; g_cA2s=cA2s;
   g_cA3b=cA3b; g_cA3s=cA3s; g_cA5b=cA5b; g_cA5s=cA5s;
   g_cB1=cB1; g_cB3=cB3; g_cB5b=cB5b; g_cB5s=cB5s;
   g_cC1b=cC1b; g_cC1s=cC1s; g_cC2b=cC2b; g_cC2s=cC2s;
   g_cC3b=cC3b; g_cC3s=cC3s; g_cC4b=cC4b; g_cC4s=cC4s;
   g_cC5b=cC5b; g_cC5s=cC5s;
   g_cD1b=cD1b; g_cD1s=cD1s; g_cD3b=cD3b; g_cD3s=cD3s;
   g_cD4b=cD4b; g_cD4s=cD4s; g_cD5=cD5;
   g_htfBuyOK=htfBuyOK; g_htfSellOK=htfSellOK; g_inSess=inSess;
   g_chopOK=chopOK; g_ltfValid=ltfValid;
   g_baseBuy=baseBuy; g_baseSell=baseSell; g_cooldownOK=cooldown;
   g_curAdx=adxVal; g_curRsi=rsi14; g_curDelta=ltfDelta;
   g_ofBull=ofBull; g_ofBear=ofBear;
   g_curPos=curPos; g_curEntry=entryLvl; g_curSL=effSL;
   g_curTP1=tp1; g_curTP2=tp2; g_curTP3=tp3; g_curTP4=tp4;
   g_tradeActive=(curPos!=0 && entryLvl>0 && !g_state.tradeDone);

   //================= ALERTAS =================
   if(persist && newSignal && i>=rates_total-3 && time[i]!=g_lastAlertBar)
     {
      g_lastAlertBar=time[i];
      if(InpDragResetNew)
        {
         g_manSL=0; g_manTP1=0; g_manTP2=0; g_manTP3=0; g_manTP4=0;
         MtmManualClear(_Symbol,g_tfsec);
        }
      string dir=isBuy?"BUY":"SELL";
      string msg=StringFormat("MTM Sensei %s %s %s @ %s | SL %s | E1 %s E2 %s E3 %s E4 %s | score %d/20",
                              dir,_Symbol,EnumToString((ENUM_TIMEFRAMES)_Period),
                              DoubleToString(g_state.fixEntry,_Digits),
                              DoubleToString(g_state.fixSL,_Digits),
                              DoubleToString(g_state.fixTP1,_Digits),
                              DoubleToString(g_state.fixTP2,_Digits),
                              DoubleToString(g_state.fixTP3,_Digits),
                              DoubleToString(g_state.fixTP4,_Digits),
                              (isBuy?bullScore:bearScore));
      if(InpAlertPopup) Alert(msg);
      if(InpAlertPush)  SendNotification(msg);
      if(InpAlertSound) PlaySound(InpSoundFile);
     }
  }

//====================================================================
//  PAINEIS
//====================================================================
void PanelBG(const string nm,const ENUM_BASE_CORNER corner,const int x,const int y,
             const int w,const int h)
  {
   if(ObjectFind(0,nm)<0)
     {
      ObjectCreate(0,nm,OBJ_RECTANGLE_LABEL,0,0,0);
      ObjectSetInteger(0,nm,OBJPROP_BGCOLOR,C'20,20,32');
      ObjectSetInteger(0,nm,OBJPROP_BORDER_TYPE,BORDER_FLAT);
      ObjectSetInteger(0,nm,OBJPROP_COLOR,C'124,58,237');
      ObjectSetInteger(0,nm,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,nm,OBJPROP_BACK,false);
      ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
     }
   ObjectSetInteger(0,nm,OBJPROP_CORNER,corner);
   ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,nm,OBJPROP_XSIZE,w);
   ObjectSetInteger(0,nm,OBJPROP_YSIZE,h);
  }

void PanelRow(const string nm,const ENUM_BASE_CORNER corner,const int x,const int y,
              const string txt,const color clr,const int fsize=8)
  {
   if(ObjectFind(0,nm)<0)
     {
      ObjectCreate(0,nm,OBJ_LABEL,0,0,0);
      ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
      ObjectSetString (0,nm,OBJPROP_FONT,"Consolas");
     }
   ObjectSetInteger(0,nm,OBJPROP_CORNER,corner);
   ObjectSetInteger(0,nm,OBJPROP_ANCHOR,
                    (corner==CORNER_RIGHT_UPPER||corner==CORNER_RIGHT_LOWER)?ANCHOR_RIGHT_UPPER:ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,fsize);
   ObjectSetInteger(0,nm,OBJPROP_COLOR,clr);
   ObjectSetString (0,nm,OBJPROP_TEXT,txt);
  }

color GrCol(const int s)
  {
   if(s>=4) return(C'74,222,128');
   if(s>=3) return(C'245,158,11');
   return(C'248,113,113');
  }

void DrawConfPanel()
  {
   if(!InpShowConfPanel) return;
   string p=g_prefix+"CP_";
   bool hasPos=g_tradeActive;
   bool ib=(hasPos && g_curPos>0);
   int  sc=hasPos ? (ib?g_bullScore:g_bearScore) : MathMax(g_bullScore,g_bearScore);
   int  gA=ib?g_grA_b:g_grA_s, gB=ib?g_grB_b:g_grB_s;
   int  gC=ib?g_grC_b:g_grC_s, gD=ib?g_grD_b:g_grD_s;
   if(!hasPos && g_bullScore>=g_bearScore){ gA=g_grA_b; gB=g_grB_b; gC=g_grC_b; gD=g_grD_b; }

   int x=8,y=18,w=300,h=142,row=16;
   PanelBG(p+"bg",CORNER_RIGHT_UPPER,x-4,y-4,w,h);
   string dir = hasPos ? ((ib?"BUY  ":"SELL ")+IntegerToString(sc)+"/20 "+ConfMark(sc))
                       : "-- a aguardar sinal --";
   PanelRow(p+"0",CORNER_RIGHT_UPPER,x,y,
            StringFormat("%-16s%16s","CONFIRMACOES",dir),C'196,181,253',9);
   PanelRow(p+"1",CORNER_RIGHT_UPPER,x,y+row*1,
            StringFormat("%-22s%10s","TENDENCIA DEMA",Dots(gA)+" "+IntegerToString(gA)+"/5"),GrCol(gA));
   PanelRow(p+"2",CORNER_RIGHT_UPPER,x,y+row*2,
            StringFormat("%-22s%10s","MOM / VOL / FLOW",Dots(gB)+" "+IntegerToString(gB)+"/5"),GrCol(gB));
   PanelRow(p+"3",CORNER_RIGHT_UPPER,x,y+row*3,
            StringFormat("%-22s%10s","SMC / STRUCTURE",Dots(gC)+" "+IntegerToString(gC)+"/5"),GrCol(gC));
   PanelRow(p+"4",CORNER_RIGHT_UPPER,x,y+row*4,
            StringFormat("%-22s%10s","SENSEI / FASE / VOL",Dots(gD)+" "+IntegerToString(gD)+"/5"),GrCol(gD));
   PanelRow(p+"5",CORNER_RIGHT_UPPER,x,y+row*5,
            StringFormat("%-22s%10s","TOTAL",IntegerToString(sc)+" / 20"),C'245,158,11');
   string slTxt=(g_disp.fixSlPips>0)?DoubleToString(g_disp.fixSlPips,0)+" pips":"--";
   string rmTxt=(InpRiskMode==RISK_ATR)?("ATRx"+DoubleToString(g_actSlMult,1))
                                       :("%"+DoubleToString(InpSlPct,1));
   PanelRow(p+"6",CORNER_RIGHT_UPPER,x,y+row*6,
            StringFormat("%-22s%10s","SL ("+rmTxt+")",slTxt),C'248,113,113');
   int tot=g_disp.stWins+g_disp.stLosses;
   double wr=(tot>0)?(100.0*g_disp.stWins/tot):0.0;
   double ar=(tot>0)?(g_disp.stSumR/tot):0.0;
   PanelRow(p+"7",CORNER_RIGHT_UPPER,x,y+row*7,
            StringFormat("%-22s%10s","WR / R med / N",
                         DoubleToString(wr,1)+"% "+DoubleToString(ar,2)+"R ("+IntegerToString(tot)+")"),
            C'245,158,11');
  }

void DrawRulesPanel()
  {
   if(!InpShowRules) return;
   string p=g_prefix+"RP_";
   bool bias=(g_bullScore>=g_bearScore);
   int x=8,y=8,w=350,h=126,row=16;
   PanelBG(p+"bg",CORNER_LEFT_LOWER,x-4,y+h-4,w,h);
   int yb=y+h-18;
   string styleTxt=(g_autoOn?"AUTO":EnumToString(InpStyle))+" / "+
                   ((g_phaseMode==PHASE_MOMENTUM)?"Momentum":"Exaustao");
   PanelRow(p+"0",CORNER_LEFT_LOWER,x,yb-row*0,
            StringFormat("CHECKLIST SENSEI  %s  %d/20   [%s]",
                         (bias?"BULL":"BEAR"),(bias?g_bullScore:g_bearScore),styleTxt),
            C'196,181,253',9);
   PanelRow(p+"1",CORNER_LEFT_LOWER,x,yb-row*1,
            StringFormat("TENDENCIA %s DEMA15>50  %s 50>238  %s Slope  %s P>DEMA",
                         Ck(bias?g_cA1b:g_cA1s),Ck(bias?g_cA2b:g_cA2s),
                         Ck(bias?g_cA3b:g_cA3s),Ck(bias?g_cA5b:g_cA5s)),clrSilver);
   PanelRow(p+"2",CORNER_LEFT_LOWER,x,yb-row*2,
            StringFormat("MOM/OF    %s Vol  %s OF-delta  %s ADX>%.0f  %s Imbal",
                         Ck(g_cB1),Ck(bias?g_cB5b:g_cB5s),Ck(g_cB3),g_effAdx,
                         Ck(bias?g_cC5b:g_cC5s)),clrSilver);
   PanelRow(p+"3",CORNER_LEFT_LOWER,x,yb-row*3,
            StringFormat("ESTRUTURA %s OS  %s CHoCH  %s BOS  %s POC",
                         Ck(bias?g_cC1b:g_cC1s),Ck(bias?g_cC2b:g_cC2s),
                         Ck(bias?g_cC3b:g_cC3s),Ck(bias?g_cC4b:g_cC4s)),clrSilver);
   PanelRow(p+"4",CORNER_LEFT_LOWER,x,yb-row*4,
            StringFormat("FASE/VOL  %s Cloud  %s Fase  %s Vol-safe  %s Pressao",
                         Ck(bias?g_cD1b:g_cD1s),Ck(bias?g_cD3b:g_cD3s),
                         Ck(g_cD5),Ck(bias?g_cD4b:g_cD4s)),clrSilver);
   PanelRow(p+"5",CORNER_LEFT_LOWER,x,yb-row*5,
            StringFormat("FILTROS   %s HTF  %s Sessao  %s Anti-chop  %s OF-LTF",
                         Ck(bias?g_htfBuyOK:g_htfSellOK),Ck(g_inSess),
                         Ck(g_chopOK),Ck(g_ltfValid)),clrSilver);
   bool trig=(bias?g_baseBuy:g_baseSell);
   PanelRow(p+"6",CORNER_LEFT_LOWER,x,yb-row*6,
            StringFormat("GATILHO   %s   COOLDOWN %s   MoreThanMoney",
                         (trig?"ATIVO":"-----"),(g_cooldownOK?"ok":"espera")),
            (trig?C'74,222,128':clrGray));
  }

void DrawTradePanel()
  {
   if(!InpShowTrdPanel || !g_tradeActive) return;
   string p=g_prefix+"TP_";
   int x=8,y=8,w=300,h=178,row=16;
   PanelBG(p+"bg",CORNER_RIGHT_LOWER,x-4,y+h-4,w,h);
   int yb=y+h-18;
   bool ib=(g_curPos>0);
   int  sc=ib?g_bullScore:g_bearScore;
   PanelRow(p+"0",CORNER_RIGHT_LOWER,x,yb-row*0,
            StringFormat("%-14s%18s","SENSEI TRADE",(ib?"BUY  ":"SELL ")+IntegerToString(sc)+"/20"),
            C'196,181,253',9);
   PanelRow(p+"1",CORNER_RIGHT_LOWER,x,yb-row*1,
            StringFormat("%-14s%18s","ENTRY",DoubleToString(g_curEntry,_Digits)),clrWhite);
   string slLbl=g_disp.beTrig?"BE":((InpTrailMode==TRAIL_ATR&&g_disp.trailSL>0)?"TRAIL":"SL");
   PanelRow(p+"2",CORNER_RIGHT_LOWER,x,yb-row*2,
            StringFormat("%-14s%18s",slLbl,DoubleToString(g_curSL,_Digits)),
            g_disp.beTrig?clrOrange:C'248,113,113');
   PanelRow(p+"3",CORNER_RIGHT_LOWER,x,yb-row*3,
            StringFormat("%-14s%18s","SL em pips",DoubleToString(g_disp.fixSlPips,0)),C'248,113,113');
   PanelRow(p+"4",CORNER_RIGHT_LOWER,x,yb-row*4,
            StringFormat("E1 1:%-9s%18s",DoubleToString(g_rr1,1),
                         DoubleToString(g_curTP1,_Digits)+(g_disp.tp1Hit?" v":"")),C'34,197,94');
   PanelRow(p+"5",CORNER_RIGHT_LOWER,x,yb-row*5,
            StringFormat("E2 1:%-9s%18s",DoubleToString(g_rr2,1),
                         DoubleToString(g_curTP2,_Digits)+(g_disp.tp2Hit?" v":"")),C'22,163,74');
   PanelRow(p+"6",CORNER_RIGHT_LOWER,x,yb-row*6,
            StringFormat("E3 1:%-9s%18s",DoubleToString(g_rr3,1),
                         DoubleToString(g_curTP3,_Digits)+(g_disp.tp3Hit?" v":"")),C'21,128,61');
   PanelRow(p+"7",CORNER_RIGHT_LOWER,x,yb-row*7,
            StringFormat("E4 1:%-9s%18s",DoubleToString(g_rr4,1),
                         DoubleToString(g_curTP4,_Digits)+(g_disp.tp4Hit?" v":"")),C'15,118,110');
   string ofTxt=g_ltfValid? ((g_ofBull?"+":(g_ofBear?"-":" "))+DoubleToString(MathAbs(g_curDelta),0))
                          : "proxy";
   PanelRow(p+"8",CORNER_RIGHT_LOWER,x,yb-row*8,
            StringFormat("%-14s%18s","Order Flow",ofTxt),
            g_ofBull?C'74,222,128':(g_ofBear?C'248,113,113':clrGray));
   PanelRow(p+"9",CORNER_RIGHT_LOWER,x,yb-row*9,
            StringFormat("ADX %-10sRSI %13s",DoubleToString(g_curAdx,1),DoubleToString(g_curRsi,1)),
            clrSilver);
  }

//====================================================================
//  NIVEIS DA TRADE ATIVA
//====================================================================
void DrawLevel(const string nm,const datetime t1,const datetime t2,const double price,
               const color clr,const ENUM_LINE_STYLE st,const int wdt,const string txt,
               const bool draggable=false)
  {
   if(price<=0) return;
   if(ObjectFind(0,nm)<0)
     {
      ObjectCreate(0,nm,OBJ_TREND,0,t1,price,t2,price);
      ObjectSetInteger(0,nm,OBJPROP_RAY_RIGHT,false);
      ObjectSetInteger(0,nm,OBJPROP_BACK,false);
     }
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,draggable);
   ObjectSetInteger(0,nm,OBJPROP_HIDDEN,!draggable);
   ObjectMove(0,nm,0,t1,price);
   ObjectMove(0,nm,1,t2,price);
   ObjectSetInteger(0,nm,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,nm,OBJPROP_STYLE,st);
   ObjectSetInteger(0,nm,OBJPROP_WIDTH,wdt);
   ObjectSetString (0,nm,OBJPROP_TOOLTIP,draggable?(txt+"  (arrasta para gerir a mao)"):txt);

   string nl=nm+"_t";
   if(ObjectFind(0,nl)<0)
     {
      ObjectCreate(0,nl,OBJ_TEXT,0,t2,price);
      ObjectSetInteger(0,nl,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nl,OBJPROP_HIDDEN,true);
      ObjectSetInteger(0,nl,OBJPROP_ANCHOR,ANCHOR_LEFT);
      ObjectSetInteger(0,nl,OBJPROP_FONTSIZE,8);
     }
   ObjectMove(0,nl,0,t2,price);
   ObjectSetInteger(0,nl,OBJPROP_COLOR,clr);
   ObjectSetString (0,nl,OBJPROP_TEXT,txt);
  }

void DelLevel(const string nm)
  {
   ObjectDelete(0,nm);
   ObjectDelete(0,nm+"_t");
  }

void DrawTradeBox(const int rates_total,const datetime &time[])
  {
   string p=g_prefix+"L_";
   if(!InpShowTradeBox || !g_tradeActive || g_disp.sigBar<0)
     {
      DelLevel(p+"EN"); DelLevel(p+"SL"); DelLevel(p+"T1");
      DelLevel(p+"T2"); DelLevel(p+"T3"); DelLevel(p+"T4");
      return;
     }
   //--- ancora na vela do sinal: a linha cobre a trade toda, de entrada ate agora
   int      sb = g_disp.sigBar;
   if(sb<0 || sb>=rates_total) sb=rates_total-1;
   datetime t1 = time[sb];
   datetime t2 = (datetime)(time[rates_total-1]+PeriodSeconds(_Period)*14);

   //--- um nivel movido a mao manda sobre o do indicador
   double lvSL = (g_manSL >0)? g_manSL  : g_curSL;
   double lvT1 = (g_manTP1>0)? g_manTP1 : g_curTP1;
   double lvT2 = (g_manTP2>0)? g_manTP2 : g_curTP2;
   double lvT3 = (g_manTP3>0)? g_manTP3 : g_curTP3;
   double lvT4 = (g_manTP4>0)? g_manTP4 : g_curTP4;
   string mkSL = (g_manSL >0)? "  <manual>":"";
   string mk1  = (g_manTP1>0)? "  <manual>":"";
   string mk2  = (g_manTP2>0)? "  <manual>":"";
   string mk3  = (g_manTP3>0)? "  <manual>":"";
   string mk4  = (g_manTP4>0)? "  <manual>":"";

   g_drawSL=lvSL; g_drawT1=lvT1; g_drawT2=lvT2; g_drawT3=lvT3; g_drawT4=lvT4;

   string dirTx = (g_curPos>0?"BUY":"SELL");
   DrawLevel(p+"EN",t1,t2,g_curEntry,th_entry,STYLE_SOLID,2,
             StringFormat("ENTRY %s   %s  %d/20",DoubleToString(g_curEntry,_Digits),
                          dirTx,(g_curPos>0?g_bullScore:g_bearScore)));

   color  slc = g_disp.beTrig ? th_be : th_sl;
   string sltx= g_disp.beTrig ? "BE " :
                ((InpTrailMode==TRAIL_ATR && g_disp.trailSL>0) ? "TRAIL " : "SL ");
   DrawLevel(p+"SL",t1,t2,lvSL,slc,STYLE_SOLID,2,
             sltx+DoubleToString(lvSL,_Digits)+"  ["+DoubleToString(g_disp.fixSlPips,0)+"p]"+mkSL,
             InpAllowDrag);

   if(InpShowExits && !g_disp.tp1Hit)
      DrawLevel(p+"T1",t1,t2,lvT1,th_tp1,STYLE_SOLID,1,
                "EXIT 1  1:"+DoubleToString(g_rr1,1)+"   "+DoubleToString(lvT1,_Digits)+mk1,
                InpAllowDrag);
   else DelLevel(p+"T1");
   if(InpShowExits && !g_disp.tp2Hit)
      DrawLevel(p+"T2",t1,t2,lvT2,th_tp2,STYLE_SOLID,1,
                "EXIT 2  1:"+DoubleToString(g_rr2,1)+"   "+DoubleToString(lvT2,_Digits)+mk2,
                InpAllowDrag);
   else DelLevel(p+"T2");
   if(InpShowExits && !g_disp.tp3Hit)
      DrawLevel(p+"T3",t1,t2,lvT3,th_tp3,STYLE_SOLID,1,
                "EXIT 3  1:"+DoubleToString(g_rr3,1)+"   "+DoubleToString(lvT3,_Digits)+mk3,
                InpAllowDrag);
   else DelLevel(p+"T3");
   if(InpShowExits && !g_disp.tp4Hit)
      DrawLevel(p+"T4",t1,t2,lvT4,th_tp4,STYLE_DASH,1,
                "EXIT 4  1:"+DoubleToString(g_rr4,1)+"   "+DoubleToString(lvT4,_Digits)+mk4,
                InpAllowDrag);
   else DelLevel(p+"T4");
  }

void DrawOrderBlocks(const datetime lastTime,const datetime &time[])
  {
   string nb=g_prefix+"OBB",nr=g_prefix+"OBR";
   if(!InpShowOB){ ObjectDelete(0,nb); ObjectDelete(0,nr); return; }
   datetime t2=(datetime)(lastTime+PeriodSeconds(_Period)*20);
   if(g_disp.obBullBar>=0 && g_disp.obBullTop>0)
     {
      if(ObjectFind(0,nb)<0)
        {
         ObjectCreate(0,nb,OBJ_RECTANGLE,0,time[g_disp.obBullBar],g_disp.obBullTop,t2,g_disp.obBullBot);
         ObjectSetInteger(0,nb,OBJPROP_COLOR,C'8,153,129');
         ObjectSetInteger(0,nb,OBJPROP_FILL,true);
         ObjectSetInteger(0,nb,OBJPROP_BACK,true);
         ObjectSetInteger(0,nb,OBJPROP_SELECTABLE,false);
        }
      ObjectMove(0,nb,0,time[g_disp.obBullBar],g_disp.obBullTop);
      ObjectMove(0,nb,1,t2,g_disp.obBullBot);
     }
   if(g_disp.obBearBar>=0 && g_disp.obBearTop>0)
     {
      if(ObjectFind(0,nr)<0)
        {
         ObjectCreate(0,nr,OBJ_RECTANGLE,0,time[g_disp.obBearBar],g_disp.obBearTop,t2,g_disp.obBearBot);
         ObjectSetInteger(0,nr,OBJPROP_COLOR,C'255,82,82');
         ObjectSetInteger(0,nr,OBJPROP_FILL,true);
         ObjectSetInteger(0,nr,OBJPROP_BACK,true);
         ObjectSetInteger(0,nr,OBJPROP_SELECTABLE,false);
        }
      ObjectMove(0,nr,0,time[g_disp.obBearBar],g_disp.obBearTop);
      ObjectMove(0,nr,1,t2,g_disp.obBearBot);
     }
  }

//====================================================================
//  MEDIAS AUXILIARES
//====================================================================
void ComputeMAs(const int rates_total,const int from,const long &tick_volume[])
  {
   int s=MathMax(from,25);
   for(int i=s;i<rates_total;i++)
     {
      double sv=0,sa=0;
      for(int k=0;k<20;k++){ sv+=(double)tick_volume[i-k]; sa+=g_atr[i-k]; }
      g_volMA[i]=sv/20.0;
      g_atrMA[i]=sa/20.0;
     }
  }


//====================================================================
//  RELATORIO DO FUNIL DE SINAL
//  Diz onde morrem os sinais: e a diferenca entre "o setup e raro"
//  e "ha um filtro a matar tudo".
//====================================================================
void MtmDiagPrint()
  {
   if(g_dBars<=0) return;
   Print("================ MTM SENSEI - FUNIL DE SINAL ================");
   PrintFormat("  simbolo/TF        : %s %s   |  auto=%s  minScore=%d  ADX>%.0f  cooldown=%d",
               _Symbol,EnumToString((ENUM_TIMEFRAMES)_Period),
               (g_autoOn?"SIM (matriz validada)":"nao"),g_effMinScore,g_effAdx,g_effCooldown);
   PrintFormat("  barras avaliadas  : %I64d", g_dBars);
   PrintFormat("  score medio/max   : %.1f / %d   (exigido %d)",
               g_dSumScore/g_dBars, g_dMaxScore, g_effMinScore);
   Print("  --- COMPRAS: quantas barras sobrevivem a cada filtro ---");
   PrintFormat("   1 gatilho base (POC/fase) : %8I64d  (%.2f%% das barras)", g_dBase, 100.0*g_dBase/g_dBars);
   PrintFormat("   2 score >= %-2d             : %8I64d", g_effMinScore, g_dScore);
   PrintFormat("   3 confirmacao vol/flow    : %8I64d", g_dConf);
   PrintFormat("   4 cooldown                : %8I64d", g_dCool);
   PrintFormat("   5 sessao                  : %8I64d", g_dSess);
   PrintFormat("   6 anti-chop (ADX)         : %8I64d", g_dChop);
   PrintFormat("   7 vela fechada            : %8I64d", g_dBar);
   PrintFormat("   8 tendencia HTF           : %8I64d", g_dHtf);
   PrintFormat("   9 setup validado          : %8I64d   <== SINAIS DE COMPRA", g_dOk);
   PrintFormat("  --- VENDAS: base %I64d -> score %I64d -> sinais %I64d (exigem %d)",
               g_dBaseS,g_dScoreS,g_dOkS,g_effMinScore+InpSellExtra);
   string h="  distribuicao do score bull: ";
   for(int k=8;k<=20;k++) if(g_dScoreHist[k]>0) h+=StringFormat("%d:%I64d  ",k,g_dScoreHist[k]);
   Print(h);
   Print("============================================================");
  }

//====================================================================
//  ONCALCULATE
//====================================================================
#ifdef MTM_EMBEDDED
int MtmEngineCalculate(const int rates_total,
                const int prev_calculated,
#else
int OnCalculate(const int rates_total,
                const int prev_calculated,
#endif
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(rates_total<g_warmup+60) return(0);

   ArraySetAsSeries(time,false);  ArraySetAsSeries(open,false);
   ArraySetAsSeries(high,false);  ArraySetAsSeries(low,false);
   ArraySetAsSeries(close,false); ArraySetAsSeries(tick_volume,false);

#ifdef MTM_EMBEDDED
   //--- num EA os "buffers" sao arrays normais: temos de os dimensionar
   if(ArraySize(BufD15)!=rates_total)
     {
      ArrayResize(BufD15,rates_total);  ArrayResize(BufD50,rates_total);
      ArrayResize(BufD238,rates_total); ArrayResize(BufPOC,rates_total);
      ArrayResize(BufBU,rates_total);   ArrayResize(BufBL,rates_total);
      ArrayResize(BufCF,rates_total);   ArrayResize(BufCS,rates_total);
      ArrayResize(BufFillA,rates_total);ArrayResize(BufFillB,rates_total);
      ArrayResize(BufArrUp,rates_total);ArrayResize(BufArrDn,rates_total);
      ArrayResize(BufMomB,rates_total); ArrayResize(BufMomS,rates_total);
      ArrayResize(BufExhB,rates_total); ArrayResize(BufExhS,rates_total);
      ArrayResize(BufSwHi,rates_total); ArrayResize(BufSwLo,rates_total);
      ArrayResize(BufSigO,rates_total); ArrayResize(BufSigH,rates_total);
      ArrayResize(BufSigL,rates_total); ArrayResize(BufSigC,rates_total);
      ArrayResize(BufSigCol,rates_total);
      ArrayResize(BufSignal,rates_total);ArrayResize(BufEntry,rates_total);
      ArrayResize(BufSL,rates_total);   ArrayResize(BufTP1,rates_total);
      ArrayResize(BufTP2,rates_total);  ArrayResize(BufTP3,rates_total);
      ArrayResize(BufTP4,rates_total);  ArrayResize(BufScore,rates_total);
      ArrayResize(BufType,rates_total); ArrayResize(BufATR,rates_total);
     }
#endif
   bool full=(prev_calculated<=0);
   int oldSize=ArraySize(g_d15);
   if(oldSize!=rates_total)
     {
      ArrayResize(g_d15,rates_total);  ArrayResize(g_d50,rates_total);
      ArrayResize(g_d238,rates_total); ArrayResize(g_atr,rates_total);
      ArrayResize(g_rsi,rates_total);  ArrayResize(g_adx,rates_total);
      ArrayResize(g_sma,rates_total);  ArrayResize(g_std,rates_total);
      ArrayResize(g_emaF,rates_total); ArrayResize(g_emaS,rates_total);
      ArrayResize(g_volMA,rates_total);ArrayResize(g_atrMA,rates_total);
      ArrayResize(g_pocArr,rates_total);
      ArrayResize(g_ltfUp,rates_total);ArrayResize(g_ltfDn,rates_total);
      ArrayResize(g_ltfSz,rates_total);ArrayResize(g_ltfDone,rates_total);
      //--- so as posicoes novas sao inicializadas (o resto e cache valida)
      for(int q=MathMax(oldSize,0);q<rates_total;q++)
        { g_ltfDone[q]=0; g_pocArr[q]=0.0; g_ltfUp[q]=0; g_ltfDn[q]=0; g_ltfSz[q]=0; }
      if(oldSize<=0) full=true;
     }

   int need = full ? rates_total : MathMin(rates_total,rates_total-prev_calculated+3);
   if(need<3) need=3;

   if(!CopyTail(g_hD15 ,0,g_d15 ,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hD50 ,0,g_d50 ,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hD238,0,g_d238,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hATR ,0,g_atr ,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hRSI ,0,g_rsi ,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hADX ,0,g_adx ,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hSMA ,0,g_sma ,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hSTD ,0,g_std ,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hEMAF,0,g_emaF,rates_total,need)) return(prev_calculated);
   if(!CopyTail(g_hEMAS,0,g_emaS,rates_total,need)) return(prev_calculated);
   if(InpUseHTF)
     {
      if(!RefreshHtfCache() && full) return(prev_calculated);
     }
   else g_htfCount=0;

   ComputeMAs(rates_total,rates_total-need,tick_volume);

   int start;
   if(full)
     {
      ResetState();
      ArrayInitialize(g_ltfDone,0);
      g_structSeq=0;
      ObjectsDeleteAll(0,g_prefix+"S_");
      ObjectsDeleteAll(0,g_prefix+"T_");
      ObjectsDeleteAll(0,g_prefix+"B_");
      ObjectsDeleteAll(0,g_prefix+"E1_"); ObjectsDeleteAll(0,g_prefix+"E2_");
      ObjectsDeleteAll(0,g_prefix+"E3_"); ObjectsDeleteAll(0,g_prefix+"E4_");
      ObjectsDeleteAll(0,g_prefix+"BE_"); ObjectsDeleteAll(0,g_prefix+"SL_");
      for(int i=0;i<rates_total;i++)
        {
         BufD15[i]=EMPTY_VALUE; BufD50[i]=EMPTY_VALUE; BufD238[i]=EMPTY_VALUE;
         BufPOC[i]=EMPTY_VALUE; BufBU[i]=EMPTY_VALUE;  BufBL[i]=EMPTY_VALUE;
         BufCF[i]=EMPTY_VALUE;  BufCS[i]=EMPTY_VALUE;
         BufFillA[i]=EMPTY_VALUE; BufFillB[i]=EMPTY_VALUE;
         BufArrUp[i]=EMPTY_VALUE; BufArrDn[i]=EMPTY_VALUE;
         BufMomB[i]=EMPTY_VALUE;  BufMomS[i]=EMPTY_VALUE;
         BufExhB[i]=EMPTY_VALUE;  BufExhS[i]=EMPTY_VALUE;
         BufSwHi[i]=EMPTY_VALUE;  BufSwLo[i]=EMPTY_VALUE;
         BufSigO[i]=EMPTY_VALUE;  BufSigH[i]=EMPTY_VALUE;
         BufSigL[i]=EMPTY_VALUE;  BufSigC[i]=EMPTY_VALUE; BufSigCol[i]=0;
         BufSignal[i]=0; BufEntry[i]=0; BufSL[i]=0;
         BufTP1[i]=0; BufTP2[i]=0; BufTP3[i]=0; BufTP4[i]=0;
         BufScore[i]=0; BufType[i]=0; BufATR[i]=0;
        }
      start=g_warmup;
     }
   else
      start=MathMax(g_warmup,prev_calculated-1);

   int lastClosed=rates_total-2;
   for(int i=start;i<=lastClosed;i++)
      ComputeBar(i,rates_total,true,time,open,high,low,close,tick_volume);

   //--- barra em formacao: calcula sem persistir estado
   SState snap=g_state;
   ComputeBar(rates_total-1,rates_total,false,time,open,high,low,close,tick_volume);
   g_disp=g_state;
   g_state=snap;

   g_lastRates=rates_total;

   //--- desenho
#ifdef MTM_EMBEDDED
   g_onChart=true;                      // o EA esta sempre no seu proprio grafico
#else
   g_onChart=(ChartWindowFind()>=0);
#endif
   if(g_onChart && MQLInfoInteger(MQL_OPTIMIZATION)==0)
     {
      DrawTradeBox(rates_total,time);
      DrawOrderBlocks(time[rates_total-1],time);
      DrawConfPanel();
      DrawRulesPanel();
      DrawTradePanel();
     }

   return(rates_total);
  }

//====================================================================
//  GESTAO MANUAL - arrastar SL / E1-E4 no grafico
//====================================================================
double LastDrawnOf(const string key)
  {
   if(key=="SL") return(g_drawSL);
   if(key=="T1") return(g_drawT1);
   if(key=="T2") return(g_drawT2);
   if(key=="T3") return(g_drawT3);
   if(key=="T4") return(g_drawT4);
   return(0.0);
  }

void StoreManual(const string key,const double price)
  {
   if(key=="SL"){ g_manSL =price; MtmManualSet(_Symbol,g_tfsec,"SL" ,price); }
   if(key=="T1"){ g_manTP1=price; MtmManualSet(_Symbol,g_tfsec,"TP1",price); }
   if(key=="T2"){ g_manTP2=price; MtmManualSet(_Symbol,g_tfsec,"TP2",price); }
   if(key=="T3"){ g_manTP3=price; MtmManualSet(_Symbol,g_tfsec,"TP3",price); }
   if(key=="T4"){ g_manTP4=price; MtmManualSet(_Symbol,g_tfsec,"TP4",price); }
  }

void ClearManual(const string key)
  {
   if(key=="SL"){ g_manSL =0; GlobalVariableDel(MtmManualGV(_Symbol,g_tfsec,"SL" )); }
   if(key=="T1"){ g_manTP1=0; GlobalVariableDel(MtmManualGV(_Symbol,g_tfsec,"TP1")); }
   if(key=="T2"){ g_manTP2=0; GlobalVariableDel(MtmManualGV(_Symbol,g_tfsec,"TP2")); }
   if(key=="T3"){ g_manTP3=0; GlobalVariableDel(MtmManualGV(_Symbol,g_tfsec,"TP3")); }
   if(key=="T4"){ g_manTP4=0; GlobalVariableDel(MtmManualGV(_Symbol,g_tfsec,"TP4")); }
  }

#ifdef MTM_EMBEDDED
void MtmEngineChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
#else
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
#endif
  {
   if(!InpAllowDrag) return;
   string pfx=g_prefix+"L_";
   if(StringFind(sparam,pfx)!=0) return;
   string key=StringSubstr(sparam,StringLen(pfx));
   if(key!="SL" && key!="T1" && key!="T2" && key!="T3" && key!="T4") return;

   if(id==CHARTEVENT_OBJECT_DRAG)
     {
      double p0=ObjectGetDouble(0,sparam,OBJPROP_PRICE,0);
      double p1=ObjectGetDouble(0,sparam,OBJPROP_PRICE,1);
      double last=LastDrawnOf(key);
      //--- se so uma ponta foi puxada, vale a ponta que mexeu
      double np=(MathAbs(p0-last)>=MathAbs(p1-last))?p0:p1;
      np=RoundP(np);
      if(np<=0) return;
      //--- forca a linha a ficar horizontal
      datetime t0=(datetime)ObjectGetInteger(0,sparam,OBJPROP_TIME,0);
      datetime t1=(datetime)ObjectGetInteger(0,sparam,OBJPROP_TIME,1);
      ObjectMove(0,sparam,0,t0,np);
      ObjectMove(0,sparam,1,t1,np);
      ObjectMove(0,sparam+"_t",0,t1,np);
      StoreManual(key,np);
      PrintFormat("MTM Sensei: %s movido a mao para %s - o EA passa a usar este nivel",
                  key,DoubleToString(np,_Digits));
      ChartRedraw();
     }
   else if(id==CHARTEVENT_OBJECT_DELETE)
     {
      ClearManual(key);
      Print("MTM Sensei: ",key," apagado - volta ao nivel calculado pelo indicador");
     }
  }
//+------------------------------------------------------------------+
