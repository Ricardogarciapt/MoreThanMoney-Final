//+------------------------------------------------------------------+
//|                                          MTM_ScalpPanel.mqh      |
//|  Propriedade intelectual de RicardoGarciaPT / MoreThanMoney      |
//|                                                                  |
//|  Painel do Sensei Scalp: iniciar/parar, fechar tudo, e o estado  |
//|  que interessa enquanto ele trabalha.                             |
//|                                                                  |
//|  ── A REGRA DESTE FICHEIRO ──────────────────────────────────────  |
//|  O botao INICIAR manda MESMO. `g_scalpLigado` e a unica verdade   |
//|  sobre se este EA pode abrir ordens, e o OnTick le essa variavel  |
//|  e mais nenhuma.                                                  |
//|                                                                  |
//|  Isto nao e zelo: no AllInOne o botao AUTO mudava uma variavel    |
//|  que o ExecuteEntry nao lia, e o painel dizia "ON" com a execucao |
//|  desligada nos parametros. O Ricardo carregou em COMPRAR e nao    |
//|  aconteceu nada, sem uma linha no log. O input aqui so decide o   |
//|  estado INICIAL — a partir dai manda o botao.                     |
//|                                                                  |
//|  As primitivas de desenho sao parecidas com as do MTM_Panel.mqh   |
//|  de proposito: sao produtos diferentes, com estado diferente, e   |
//|  partilhar o painel do AllInOne obrigava o scalper a carregar o   |
//|  estado dele (parciais, estilos, vistas, dashboards) que aqui nao |
//|  existe.                                                          |
//+------------------------------------------------------------------+
#ifndef MTMSC_SCALPPANEL_MQH
#define MTMSC_SCALPPANEL_MQH

#define SP "MTMSP_"

//--- A UNICA verdade sobre se este EA pode abrir ordens.
bool g_scalpLigado = false;

//--- Inverter o lado: o vies diz COMPRA e arma-se a VENDA, e vice-versa.
//    Nao inverte o tipo de ordem (uma buy stop tem sempre de estar acima do
//    mercado) — inverte o LADO que o Sensei escolheu. So faz diferenca com o
//    vies ligado; a armar os dois lados, inverter nao muda nada.
bool g_inverter = false;

//--- COMO SE DIMENSIONA. Vive aqui e nao nos inputs porque se muda ao vivo:
//    quem esta a olhar para o grafico com uma posicao aberta quer poder baixar
//    o lote sem tirar a EA do grafico e perder o estado todo.
//
//    Duas maneiras, e sao mesmo diferentes:
//      LOTE FIXO  — 0,01 sempre, aconteca o que acontecer. E o defeito, e e o
//                   que foi medido. Numa conta de 100 USD e o unico que faz
//                   sentido: 0,01 em ouro ja ocupa ~41 USD de margem.
//      RISCO %    — o lote sai de uma percentagem do saldo. Cresce com a
//                   conta, e tambem encolhe quando ela encolhe.
bool   g_loteModoPct = false;   // false = lote fixo, true = % do saldo
double g_lote        = 0.01;
double g_riscoPct    = 1.0;

//--- origem do painel (arrastavel pela barra de titulo)
int  g_spX = 14, g_spY = 34;

//====================================================================
//  PRIMITIVAS
//====================================================================
void SpRect(const string n,const int x,const int y,const int w,const int h,
            const color bg,const color borda)
  {
   if(ObjectFind(0,n)<0)
     {
      ObjectCreate(0,n,OBJ_RECTANGLE_LABEL,0,0,0);
      ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,n,OBJPROP_BACK,false);
      ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,n,OBJPROP_HIDDEN,true);
     }
   ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x);  ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,n,OBJPROP_XSIZE,w);      ObjectSetInteger(0,n,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,n,OBJPROP_BGCOLOR,bg);   ObjectSetInteger(0,n,OBJPROP_COLOR,borda);
  }

void SpText(const string n,const int x,const int y,const string t,
            const color c,const int size=8,const string fonte="Segoe UI")
  {
   if(ObjectFind(0,n)<0)
     {
      ObjectCreate(0,n,OBJ_LABEL,0,0,0);
      ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,n,OBJPROP_HIDDEN,true);
     }
   ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x); ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,n,OBJPROP_COLOR,c);     ObjectSetInteger(0,n,OBJPROP_FONTSIZE,size);
   ObjectSetString (0,n,OBJPROP_FONT,fonte);  ObjectSetString (0,n,OBJPROP_TEXT,t);
  }

void SpBtn(const string n,const int x,const int y,const int w,const int h,
           const string t,const color bg,const color fg,const int size=9)
  {
   if(ObjectFind(0,n)<0)
     {
      ObjectCreate(0,n,OBJ_BUTTON,0,0,0);
      ObjectSetInteger(0,n,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,n,OBJPROP_BORDER_COLOR,clrDimGray);
      ObjectSetInteger(0,n,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,n,OBJPROP_HIDDEN,true);
      ObjectSetString (0,n,OBJPROP_FONT,"Segoe UI Semibold");
     }
   ObjectSetInteger(0,n,OBJPROP_XDISTANCE,x); ObjectSetInteger(0,n,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,n,OBJPROP_XSIZE,w);     ObjectSetInteger(0,n,OBJPROP_YSIZE,h);
   ObjectSetInteger(0,n,OBJPROP_BGCOLOR,bg);  ObjectSetInteger(0,n,OBJPROP_COLOR,fg);
   ObjectSetInteger(0,n,OBJPROP_FONTSIZE,size);
   ObjectSetInteger(0,n,OBJPROP_STATE,false);
   ObjectSetString (0,n,OBJPROP_TEXT,t);
  }

//====================================================================
//  CONSTRUCAO
//====================================================================
void ScalpPanelBuild()
  {
   int X=g_spX, Y=g_spY, W=232;

   SpRect(SP"bg",X,Y,W,300,C'18,18,26',C'210,166,60');
   SpRect(SP"hd",X,Y,W,26,C'210,166,60',C'210,166,60');
   SpText(SP"ti",X+10,Y+6,"MTM SENSEI SCALP  ·  arrasta aqui",C'20,20,20',8,"Segoe UI Semibold");

   SpBtn(SP"go" ,X+10,Y+34,W-20,30,"INICIAR",C'40,160,90',clrWhite,10);
   SpBtn(SP"kil",X+10,Y+70,W-20,22,"FECHAR TUDO",C'150,50,50',clrWhite,8);
   SpBtn(SP"inv",X+10,Y+96,W-20,22,"LADO: NORMAL",C'70,75,90',clrWhite,8);

   //--- linha do lote: o texto troca o modo, os dois botoes mexem no valor
   SpBtn(SP"lot",X+10 ,Y+122,W-74,22,"LOTE 0.01 fixo",C'52,58,74',clrWhite,8);
   SpBtn(SP"lm" ,X+W-60,Y+122,24,22,"-",C'70,75,90',clrWhite,9);
   SpBtn(SP"lp" ,X+W-32,Y+122,22,22,"+",C'70,75,90',clrWhite,9);

   SpText(SP"l1",X+10,Y+156,"LEITURA",C'148,163,184',7);
   SpText(SP"v1",X+10,Y+168,"—",clrWhite,9,"Segoe UI Semibold");

   SpText(SP"l2",X+10,Y+190,"CICLOS HOJE",C'148,163,184',7);
   SpText(SP"v2",X+10,Y+202,"—",clrWhite,9,"Segoe UI Semibold");

   SpText(SP"l3",X+118,Y+190,"RESULTADO DO DIA",C'148,163,184',7);
   SpText(SP"v3",X+118,Y+202,"—",clrWhite,9,"Segoe UI Semibold");

   SpText(SP"l5",X+10,Y+224,"NOTICIAS",C'148,163,184',7);
   SpText(SP"v5",X+10,Y+236,"—",C'200,205,215',8);

   SpText(SP"v6",X+10,Y+258,"—",C'120,130,145',7);   // licenca
   SpText(SP"v4",X+10,Y+276,"—",C'120,130,145',7);   // chao da corretora
  }

void ScalpPanelDestroy()
  {
   ObjectsDeleteAll(0,SP);
  }

//====================================================================
//  ACTUALIZACAO
//====================================================================
void ScalpPanelRefresh(const int vies,const int score,const int ciclos,const int tectoCiclos,
                       const double resultadoDia,const int chaoPontos,const string travao,
                       const string noticias,const string licenca,const bool licOk)
  {
   if(ObjectFind(0,SP"bg")<0) return;

   if(g_scalpLigado)
     {
      ObjectSetString (0,SP"go",OBJPROP_TEXT,"A TRABALHAR  ·  parar");
      ObjectSetInteger(0,SP"go",OBJPROP_BGCOLOR,C'40,160,90');
     }
   else
     {
      ObjectSetString (0,SP"go",OBJPROP_TEXT,"INICIAR");
      ObjectSetInteger(0,SP"go",OBJPROP_BGCOLOR,C'70,75,90');
     }

   if(g_inverter)
     {
      ObjectSetString (0,SP"inv",OBJPROP_TEXT,"LADO: INVERTIDO");
      ObjectSetInteger(0,SP"inv",OBJPROP_BGCOLOR,C'150,90,40');
     }
   else
     {
      ObjectSetString (0,SP"inv",OBJPROP_TEXT,"LADO: NORMAL");
      ObjectSetInteger(0,SP"inv",OBJPROP_BGCOLOR,C'70,75,90');
     }

   //--- o lote, dito como e: ou o numero, ou a percentagem
   ObjectSetString(0,SP"lot",OBJPROP_TEXT,
                   g_loteModoPct ? StringFormat("RISCO %.1f%% do saldo",g_riscoPct)
                                 : StringFormat("LOTE %.2f fixo",g_lote));

   string leitura; color cor=C'148,163,184';
   if(travao!="")      { leitura="parada — "+travao;                     cor=C'224,180,95'; }
   else if(vies>0)     { leitura=StringFormat("COMPRA  (score %d)",score); cor=C'79,201,138'; }
   else if(vies<0)     { leitura=StringFormat("VENDA  (score %d)",score);  cor=C'224,117,95'; }
   else if(vies==0)    { leitura="ambos os lados armados";                 cor=clrWhite;      }
   else                { leitura=StringFormat("a aguardar setup (%d)",score); }
   ObjectSetString (0,SP"v1",OBJPROP_TEXT,leitura);
   ObjectSetInteger(0,SP"v1",OBJPROP_COLOR,cor);

   ObjectSetString(0,SP"v2",OBJPROP_TEXT,
                   (tectoCiclos>0)? StringFormat("%d / %d",ciclos,tectoCiclos)
                                  : IntegerToString(ciclos));

   ObjectSetString (0,SP"v3",OBJPROP_TEXT,StringFormat("%+.2f",resultadoDia));
   ObjectSetInteger(0,SP"v3",OBJPROP_COLOR,(resultadoDia>=0)?C'79,201,138':C'224,117,95');

   //--- Noticias: vazio nao e "esta tudo bem", pode ser "esta desligado". Por
   //    isso as duas coisas dizem-se por palavras diferentes.
   ObjectSetString (0,SP"v5",OBJPROP_TEXT,(noticias=="")? "nada a vista" : noticias);
   ObjectSetInteger(0,SP"v5",OBJPROP_COLOR,(noticias=="")? C'120,130,145' : C'224,180,95');

   ObjectSetString (0,SP"v6",OBJPROP_TEXT,licenca);
   ObjectSetInteger(0,SP"v6",OBJPROP_COLOR,licOk? C'90,150,110' : C'224,117,95');

   ObjectSetString(0,SP"v4",OBJPROP_TEXT,StringFormat("chao da corretora: %d pts",chaoPontos));
  }

//====================================================================
//  ARRASTAR
//====================================================================
void ScalpPanelShift(const int dx,const int dy)
  {
   g_spX+=dx; g_spY+=dy;
   if(g_spX<0) g_spX=0;
   if(g_spY<0) g_spY=0;
   ScalpPanelBuild();
  }

//====================================================================
//  BOTOES DO LOTE
//  Passos que fazem sentido em cada modo: 0,01 no lote (que e o minimo em
//  quase toda a parte) e 0,1% no risco. Com tectos, porque um painel que
//  deixa carregar ate 50 lotes num clique repetido nao e um painel, e uma
//  armadilha.
//====================================================================
void ScalpPanelLote(const int passo)
  {
   if(g_loteModoPct)
     {
      g_riscoPct+=passo*0.1;
      if(g_riscoPct<0.1)  g_riscoPct=0.1;
      if(g_riscoPct>10.0) g_riscoPct=10.0;
     }
   else
     {
      double minimo=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
      double degrau=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
      if(minimo<=0) minimo=0.01;
      if(degrau<=0) degrau=0.01;
      g_lote+=passo*degrau;
      if(g_lote<minimo) g_lote=minimo;
      if(g_lote>10.0)   g_lote=10.0;
      g_lote=NormalizeDouble(g_lote,2);
     }
  }

#endif // MTMSC_SCALPPANEL_MQH
