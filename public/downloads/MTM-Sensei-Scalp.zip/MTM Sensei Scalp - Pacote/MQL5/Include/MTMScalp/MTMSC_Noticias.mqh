//+------------------------------------------------------------------+
//|                                        MTMSC_Noticias.mqh        |
//|  Propriedade intelectual de RicardoGarciaPT / MoreThanMoney      |
//|                                                                  |
//|  FILTRO DE NOTICIAS da Sensei Scalp.                             |
//|                                                                  |
//|  Portado do AllInOne, onde ja estava provado. Duas fontes:        |
//|    1. o calendario economico do proprio MetaTrader (CalendarValue |
//|       History) - nao precisa de nada instalado, mas ha corretoras |
//|       cujo servidor nao o serve;                                  |
//|    2. um CSV em Common\Files, para essas.                         |
//|                                                                  |
//|  PORQUE E QUE ISTO IMPORTA MAIS AQUI DO QUE NO ALLINONE: a Scalp  |
//|  nao tem stop loss. Numa NFP o preco anda 3 USD em segundos e a   |
//|  ordem de reversao - que e o unico travao - e preenchida onde o   |
//|  livro tiver liquidez, nao onde esta desenhada. Por isso o defeito|
//|  aqui e FECHAR TUDO e nao apenas bloquear entradas novas.         |
//+------------------------------------------------------------------+
#ifndef MTMSC_NOTICIAS_MQH
#define MTMSC_NOTICIAS_MQH

//--- fecha o que a EA tenha aberto (implementada no .mq5)
void FecharTudo(const string porque);
void NewsLoadExternal(string &ccy[]);

//--- o que a EA expoe ao filtro: o resto do modulo veio do AllInOne, onde
//    estes eram inputs. Aqui sao os poucos que ficaram a vista, mais os que
//    nunca ninguem mexeu, fixos.
#define InpUseNews          InpFiltroNoticias
#define InpExtNews          InpFiltroNoticias
#define InpNewsSymbolCcy    true
#define InpNewsExtraCcy     "USD"
#define InpNewsSkipHoliday  true
#define InpNewsShiftMin     0
#define InpNewsRefreshMin   15
#define InpExtFile          "mtm_news.csv"
#define InpExtServerGMT     999
//--- pasta Common: o tester tambem la le, e e onde o instalador poe o CSV
#define InpExtCommonFolder  true

//====================================================================
//  FILTRO DE NOTICIAS - calendario economico do MT5 + CSV de reserva
//====================================================================
datetime g_newsTimes[];
string   g_newsNames[];
datetime g_newsLastRefresh=0;
bool     g_newsAvailable=true;
string   g_newsCurrent="";
datetime g_newsNext=0;
string   g_newsNextName="";
datetime g_extLastFetch=0;
bool     g_extLoaded=false;
int      g_extCount=0;

bool NewsWanted(const ENUM_CALENDAR_EVENT_IMPORTANCE imp)
  {
   if(InpNewsImportance==NEWS_HIGH)    return(imp==CALENDAR_IMPORTANCE_HIGH);
   if(InpNewsImportance==NEWS_HIGHMED) return(imp==CALENDAR_IMPORTANCE_HIGH || imp==CALENDAR_IMPORTANCE_MODERATE);
   return(imp!=CALENDAR_IMPORTANCE_NONE);
  }

void NewsCurrencyList(string &out[])
  {
   string tmp[];
   int n=0;
   ArrayResize(tmp,0);
   if(InpNewsSymbolCcy)
     {
      string b=SymbolInfoString(_Symbol,SYMBOL_CURRENCY_BASE);
      string q=SymbolInfoString(_Symbol,SYMBOL_CURRENCY_PROFIT);
      if(b!=""){ ArrayResize(tmp,++n); tmp[n-1]=b; }
      if(q!="" && q!=b){ ArrayResize(tmp,++n); tmp[n-1]=q; }
     }
   if(StringLen(InpNewsExtraCcy)>0)
     {
      string parts[];
      int c=StringSplit(InpNewsExtraCcy,',',parts);
      for(int i=0;i<c;i++)
        {
         string v=parts[i];
         StringTrimLeft(v); StringTrimRight(v); StringToUpper(v);
         if(v=="") continue;
         bool dup=false;
         for(int k=0;k<n;k++) if(tmp[k]==v) dup=true;
         if(!dup){ ArrayResize(tmp,++n); tmp[n-1]=v; }
        }
     }
   ArrayResize(out,n);
   for(int i=0;i<n;i++) out[i]=tmp[i];
  }

void NewsRefresh()
  {
   if(!InpUseNews && !InpExtNews) return;
   if(g_newsLastRefresh>0 &&
      (long)(TimeCurrent()-g_newsLastRefresh) < (long)InpNewsRefreshMin*60) return;
   g_newsLastRefresh=TimeCurrent();

   string ccy[];
   NewsCurrencyList(ccy);
   ArrayResize(g_newsTimes,0);
   ArrayResize(g_newsNames,0);
   g_extCount=0;

   //---------------- calendario nativo do MT5 ----------------
   if(InpUseNews && ArraySize(ccy)>0)
     {
      datetime from=TimeCurrent()-(datetime)(24*3600);
      datetime to  =TimeCurrent()+(datetime)(72*3600);
      int total=0;
      for(int c=0;c<ArraySize(ccy);c++)
        {
         MqlCalendarValue vals[];
         int n=CalendarValueHistory(vals,from,to,NULL,ccy[c]);
         if(n<=0) continue;
         for(int i=0;i<n;i++)
           {
            MqlCalendarEvent ev;
            if(!CalendarEventById(vals[i].event_id,ev)) continue;
            if(InpNewsSkipHoliday && ev.type==CALENDAR_TYPE_HOLIDAY) continue;
            if(!NewsWanted(ev.importance)) continue;
            datetime t=vals[i].time+(datetime)(InpNewsShiftMin*60);
            NewsAdd(t,ccy[c]+" "+ev.name);
            total++;
           }
        }
      if(total==0 && g_newsAvailable && !MQLInfoInteger(MQL_TESTER))
        {
         MqlCalendarValue probe[];
         if(CalendarValueHistory(probe,from,to,NULL,NULL)<=0)
           {
            g_newsAvailable=false;
            Print("MTM Sensei: calendario nativo indisponivel",
                  (InpExtNews?" - a usar so a fonte externa.":" - filtro de noticias inativo."));
           }
        }
     }

   //---------------- fonte externa (CSV / URL) ----------------
   NewsLoadExternal(ccy);
  }

int ImpactFromText(string v)
  {
   StringToUpper(v);
   StringTrimLeft(v); StringTrimRight(v);
   if(v=="3" || StringFind(v,"HIGH")>=0)   return(3);
   if(v=="2" || StringFind(v,"MED")>=0 || StringFind(v,"MOD")>=0) return(2);
   if(v=="1" || StringFind(v,"LOW")>=0)    return(1);
   return(0);
  }

bool ImpactWanted(const int imp)
  {
   if(InpNewsImportance==NEWS_HIGH)    return(imp>=3);
   if(InpNewsImportance==NEWS_HIGHMED) return(imp>=2);
   return(imp>=1);
  }

bool CurrencyWanted(string ccy,string &list[])
  {
   if(ArraySize(list)==0) return(true);
   StringToUpper(ccy);
   StringTrimLeft(ccy); StringTrimRight(ccy);
   for(int i=0;i<ArraySize(list);i++) if(list[i]==ccy) return(true);
   return(false);
  }

void NewsAdd(const datetime t,const string label)
  {
   int n=ArraySize(g_newsTimes);
   ArrayResize(g_newsTimes,n+1);
   ArrayResize(g_newsNames,n+1);
   g_newsTimes[n]=t;
   g_newsNames[n]=label;
   g_extCount++;
  }

//--- desvio do servidor face a GMT, em segundos
int ServerGmtOffset()
  {
   if(InpExtServerGMT!=999) return(InpExtServerGMT*3600);
   long off=(long)TimeTradeServer()-(long)TimeGMT();
   //--- arredonda a meia hora para limar imprecisoes
   long half=1800;
   return((int)(MathRound((double)off/half)*half));
  }

datetime ParseStamp(string v)
  {
   StringTrimLeft(v); StringTrimRight(v);
   StringReplace(v,"-",".");
   StringReplace(v,"T"," ");
   return(StringToTime(v));
  }

//--- le o CSV; devolve quantos eventos aceitou
int NewsLoadCsv(string &ccy[])
  {
   int flags=FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ;
   if(InpExtCommonFolder) flags|=FILE_COMMON;
   int h=FileOpen(InpExtFile,flags);
   if(h==INVALID_HANDLE) return(-1);

   int added=0;
   while(!FileIsEnding(h))
     {
      string line=FileReadString(h);
      StringTrimLeft(line); StringTrimRight(line);
      if(line=="" || StringGetCharacter(line,0)=='#') continue;
      string f[];
      int n=StringSplit(line,';',f);
      if(n<3) n=StringSplit(line,',',f);
      if(n<3) continue;

      datetime t=ParseStamp(f[0]);
      if(t<=0) continue;
      string c=f[1];
      int imp=ImpactFromText(f[2]);
      string nm=(n>3)?f[3]:"evento";
      if(!ImpactWanted(imp)) continue;
      if(!CurrencyWanted(c,ccy)) continue;
      StringToUpper(c);
      NewsAdd(t,c+" "+nm);
      added++;
     }
   FileClose(h);
   return(added);
  }

//--- carrega a fonte externa para os arrays partilhados
void NewsLoadExternal(string &ccy[])
  {
   if(!InpExtNews) return;
   int got=-1;
   string csv="";

   //--- SO O FICHEIRO, ao contrario do AllInOne.
   //
   //    O AllInOne tambem sabe ir buscar o calendario a um URL. Aqui isso foi
   //    deliberadamente tirado: obrigaria o cliente a autorizar um SEGUNDO
   //    endereco no MetaTrader, alem do nosso — e a lista de enderecos
   //    permitidos e ja o passo onde toda a gente tropeca uma vez. Um passo
   //    para instalar vale mais do que uma fonte de dados a mais.
   //
   //    Fica o calendario do proprio MT5 (que nao precisa de autorizacao
   //    nenhuma) e, para as corretoras cujo servidor nao o serve, o CSV em
   //    Common\\Files que o instalador copia.
   if(true)
     {
      int f=NewsLoadCsv(ccy);
      if(f<0)
        {
         static bool warned=false;
         if(!warned)
           {
            warned=true;
            PrintFormat("MTM Sensei: ficheiro de noticias \"%s\" nao encontrado em %s",
                        InpExtFile,(InpExtCommonFolder?"Common\\Files":"MQL5\\Files"));
           }
        }
      else got=f;
     }

   if(got>0) g_extLoaded=true;
  }

//--- true se estamos dentro da janela de bloqueio
bool NewsBlocked()
  {
   g_newsCurrent="";
   g_newsNext=0; g_newsNextName="";
   if(!InpUseNews && !InpExtNews) return(false);
   if(ArraySize(g_newsTimes)==0)   return(false);
   datetime now=TimeCurrent();
   bool blocked=false;
   for(int i=0;i<ArraySize(g_newsTimes);i++)
     {
      datetime t=g_newsTimes[i];
      if(now>=t-(datetime)(InpNewsBeforeMin*60) && now<=t+(datetime)(InpNewsAfterMin*60))
        { blocked=true; g_newsCurrent=g_newsNames[i]; }
      if(t>now && (g_newsNext==0 || t<g_newsNext))
        { g_newsNext=t; g_newsNextName=g_newsNames[i]; }
     }
   return(blocked);
  }

//+------------------------------------------------------------------+
//| Quanto falta para a proxima noticia, em texto para o painel.     |
//| Vazio quando nao ha nenhuma a vista.                             |
//+------------------------------------------------------------------+
string NoticiasProxima()
  {
   if(g_newsNext==0) return("");
   long faltam=(long)(g_newsNext-TimeCurrent());
   if(faltam<0) return("");
   if(faltam>6*3600) return("");          // longe de mais para interessar
   int h=(int)(faltam/3600), m=(int)((faltam%3600)/60);
   string q=(h>0)? StringFormat("%dh%02d",h,m) : StringFormat("%dmin",m);
   string n=g_newsNextName;
   if(StringLen(n)>22) n=StringSubstr(n,0,21)+".";
   return(n+" em "+q);
  }

//+------------------------------------------------------------------+
//| Fecha tudo quando entra a janela. Chamada a cada tick.            |
//| Devolve true se a EA deve ficar quieta agora.                     |
//+------------------------------------------------------------------+
bool NoticiasTravam(const bool fecharPosicoes)
  {
   if(!NewsBlocked()) return(false);
   if(fecharPosicoes)
     {
      static datetime ultimoFecho=0;
      if(TimeCurrent()-ultimoFecho>60)
        {
         ultimoFecho=TimeCurrent();
         FecharTudo("janela de noticias: "+g_newsCurrent);
        }
     }
   return(true);
  }

#endif // MTMSC_NOTICIAS_MQH
