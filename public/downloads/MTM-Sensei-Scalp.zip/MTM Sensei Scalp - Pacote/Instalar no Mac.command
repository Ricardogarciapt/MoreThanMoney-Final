#!/bin/zsh
#
#  MTM Sensei Scalp — instalador para macOS
#  MoreThanMoney · morethanmoney.pt
#
#  O MetaTrader 5 no Mac corre dentro do Wine, e cada instalacao poe a pasta de
#  dados num sitio diferente conforme veio da MetaQuotes ou da corretora. Este
#  script procura em todos os sitios conhecidos em vez de assumir um: assumir
#  era o que mandava metade das pessoas para o suporte.
#

set -u
cd "$(dirname "$0")"

VERDE=$'\e[32m'; VERM=$'\e[31m'; AMAR=$'\e[33m'; FIM=$'\e[0m'
ok()    { echo "${VERDE}  ok${FIM}  $1" }
aviso() { echo "${AMAR}  !${FIM}   $1" }
erro()  { echo "${VERM}  x${FIM}   $1" }

echo
echo "================================================================"
echo "  MTM SENSEI SCALP  ·  instalacao no MetaTrader 5  ·  macOS"
echo "================================================================"
echo

# ── 1. Encontrar o MetaTrader ──────────────────────────────────────────────
# Os prefixos Wine conhecidos: o da MetaQuotes e os que as corretoras criam com
# o nome delas. O primeiro que tiver uma pasta MQL5 e o que vale.
PREFIXOS=(
  "$HOME/Library/Application Support/net.metaquotes.wine.metatrader5"
  "$HOME/Library/Application Support/net.metatrader5.wine"
)
# Qualquer outro prefixo Wine com um MetaTrader la dentro (corretoras).
for p in "$HOME/Library/Application Support/"*.wine* "$HOME/Library/Application Support/"*wine*metatrader*; do
  [[ -d "$p" ]] && PREFIXOS+=("$p")
done

BASE=""
for pref in "${PREFIXOS[@]}"; do
  for cand in "$pref/drive_c/Program Files/MetaTrader 5" "$pref/drive_c/Program Files"/*MetaTrader*; do
    if [[ -d "$cand/MQL5" ]]; then BASE="$cand"; PREFIXO="$pref"; break 2; fi
  done
done

if [[ -z "$BASE" ]]; then
  erro "Nao encontrei o MetaTrader 5 instalado."
  echo
  echo "  Instala-o primeiro em:  https://www.metatrader5.com/en/download"
  echo "  Abre-o uma vez (para criar as pastas) e volta a correr este ficheiro."
  echo
  read -k1 "?Carrega numa tecla para fechar."
  exit 1
fi

ok "MetaTrader encontrado"
echo "      $BASE"

# ── 2. Copiar o EA, o indicador e os presets ───────────────────────────────
if [[ ! -d "MQL5" ]]; then
  erro "Este ficheiro tem de ficar DENTRO da pasta do pacote, ao lado da pasta MQL5."
  read -k1 "?Carrega numa tecla para fechar."
  exit 1
fi

# `cp -R origem/. destino/` junta em vez de substituir — nao apaga nada que ja
# la esteja de outros indicadores ou robos.
if cp -R MQL5/. "$BASE/MQL5/" 2>/dev/null; then
  ok "EA, indicador, presets e scripts copiados"
else
  erro "Nao consegui copiar para a pasta do MetaTrader."
  echo "      Fecha o MetaTrader e tenta outra vez."
  read -k1 "?Carrega numa tecla para fechar."
  exit 1
fi

# ── 3. Ficheiro de noticias (pasta Common, partilhada por todos os terminais) ─
COMMON=""
# ── 3. Calendario de noticias ──────────────────────────────────────────────
# A Scalp tem filtro de noticias e usa o calendario do proprio MetaTrader. Ha
# corretoras cujo servidor nao o serve — para essas vai este CSV, na pasta
# Common, que e partilhada por todos os terminais e que o tester tambem le.
COMMON=""
for c in "$PREFIXO/drive_c/users/"*/AppData/Roaming/MetaQuotes/Terminal/Common; do
  [[ -d "$(dirname "$c")" ]] && COMMON="$c" && break
done
if [[ -n "$COMMON" && -d "Common/Files" ]]; then
  mkdir -p "$COMMON/Files"
  cp -R Common/Files/. "$COMMON/Files/" 2>/dev/null && ok "Calendario de noticias instalado"
else
  aviso "Nao instalei o calendario (a EA usa o do MetaTrader, que chega quase sempre)"
fi

# ── 4. O guia ──────────────────────────────────────────────────────────────
for g in *.pdf; do
  [[ -f "$g" ]] && open "$g" 2>/dev/null && ok "Guia de instrucoes aberto" && break
done

# ── 5. O que falta, que so a pessoa pode fazer ─────────────────────────────
echo
echo "----------------------------------------------------------------"
echo "  FALTAM 3 PASSOS NO METATRADER"
echo "----------------------------------------------------------------"
echo
echo "  1. COMPILAR"
echo "     Abre o MetaEditor (tecla F4) e compila por esta ordem, com F7:"
echo "       Indicadores > MTM > MTM_Sensei_v3"
echo ""
echo "       Consultores > MTM > MTM_Sensei_Scalp"
echo
echo "  2. PERMITIR O ENDERECO DA LICENCA"
echo "     Ferramentas > Opcoes > Consultores"
echo "     Liga \"Permitir WebRequest para os seguintes URLs\" e acrescenta:"
echo "       https://www.morethanmoney.pt"
echo "     Sem isto o EA nao valida a licenca e nao abre ordens."
echo
echo "  3. POR NO GRAFICO"
echo "     Arrasta Consultores > MTM > MTM_Sensei_Scalp para um grafico,"
echo "     escreve a tua chave no campo \"Licenca\" e carrega um preset."
echo
echo "  Duvidas? O guia que abriu tem tudo com imagens."
echo
read -k1 "?Carrega numa tecla para fechar."
